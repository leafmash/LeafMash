# Progress

## Status
- Phase 0: done
- Phase 1: done (not yet build-verified)
- Phase 2: done (not yet build-verified)
- Phase 3: done (not yet build-verified)
- Phase 4: done (not yet build-verified)
- Phase 5: not started
- Phase 6: not started
- Phase 7: not started

## Current versionCode / versionName
104 / 2.0.0-alpha.4

## Decisions
- Session gate lives in AppViewModel: Loading, SignedOut, NeedsProfile, Ready, Error
- Cached profile (DataStore) gives fast start and offline use; resolve-profile refreshes in background
- Email sign-up creates the profile in the same form via create-profile; account is deleted if create-profile fails
- Google first sign-in gets profileIncomplete and goes to the finish-setup form, saved with update-profile
- Google sign-in uses Credential Manager; web client id read at runtime from default_web_client_id
- Avatar: Photo Picker, native crop dialog (640px JPEG), Cloudinary folder leafmash/avatars through sign-upload
- Cloudinary uploads use a separate OkHttp client so the Firebase token is never sent to Cloudinary
- Presence: lastActive written every 25s while the app is in the foreground
- Added Coil 2.7.0, Credentials 1.3.0, googleid 1.1.1
- Wall feed uses one realtime listener whose limit grows by 20 per page, so older posts stay live too
- Posts are sent by PostPublisher in an app-wide scope; the feed shows a pending card with Retry and Discard
- Reactions, votes, pin and bookmarks are direct Firestore writes; the local cache gives instant UI and rollback on denial
- Author avatars and names come from UserRepository (per-user fetch cache); mention picker loads the users list once
- Multiple photos use one sign-upload call (the API rate-limits sign-upload to 800 ms)
- PushTrigger retries 2s, 5s, 10s on 429, 5xx and network errors
- Saved screen shows bookmarked posts live and notes as link rows (full notes UI comes in Phase 5)
- Messaging reads conversations and messages straight from Firestore snapshot listeners with retry and backoff
- DM and class text go through send-dm-message and send-classchat-message; MessageSender serializes sends 1.65 s apart and keeps failed ones for tap-to-retry
- Voice: MediaRecorder m4a (max 60 s) uploaded to Cloudinary leafmash/voice as raw, then sent as audioUrl; class voice is written to classChat directly and pushed with PushTrigger
- Playback uses Media3 ExoPlayer, one voice at a time, speed 1x/1.5x/2x
- Unread: a DM is unread when the last sender is the other person and lastMessageAt is after lastReadAt; class unread counts messages after classChatReads
- Bottom bar Messages badge is the sum of unread DMs plus class unread
- Presence: online when lastActive is under 240 s old
- Push: LeafMashMessagingService handles every data-only payload from send-push; token saved to users/{uid}/fcmTokens/{token} with revoked=false on login and refresh, revoked=true on sign-out (before auth.signOut)
- Four channels: messages (DM and Department Chat, custom sound), social, announcements, reminders; small icon ic_stat_notify and sound leafmash_message copied from resources/android
- DM and class chat use MessagingStyle with circular avatars (Coil), long-lived shortcuts, Reply (RemoteInput then WorkManager ReplyWorker calling send-dm-message or send-classchat-message) and Mark as read actions; swipe-away clears the stored history
- A chat notification is skipped while that thread is open (setActiveChat from the thread screens); duplicate deliveries are dropped by messageId
- Other types are single notifications grouped per channel with a summary when two or more are active
- Deep links: notification tap puts extras on MainActivity; DeepLinkParser maps the web hash urls to a DeepLinkTarget; the target waits in DeepLinkHandler until the nav host exists (cold start safe)
- Notifications screen (bell on the Wall top bar) shows notices and the activity feed with the same public plus personal queries, visibility rules and 60 item cap as the web; read and dismissed ids sync through users/{uid}/readState
- Permission flow: rationale dialog then POST_NOTIFICATIONS, then battery optimization prompt, then OEM autostart prompt; each shown once, also reachable from Settings
- Added WorkManager 2.10.0
- Typing indicator uses conversations.typing; sent at most every 2.5 s and cleared after 3 s idle

## Backend/web changes (outside android-native)
- none

## Known issues / TODO
- Not compiled locally; first GitHub Actions run may reveal compile errors
- Google sign-in needs release and Play signing SHA-1 registered in Firebase
- Avatar tap-to-view and Posts/Notes tabs on profile come in later phases
- Tapping an author, @mention or chat header does not open a profile yet (user profile screen is Phase 6)
- Full-screen photo viewer has no pinch zoom yet
- Pending posts and messages live in memory only: closing the app before they send drops them
- Class chat voice is written directly to Firestore, so it needs the classChat rules to allow audioUrl
- Deadline, routine, report and resource notifications open the closest existing screen (Notices, Wall or Resources) until Phases 5 and 6 add their screens
- Tapping a deadline or routine row in the activity feed only marks it read for now
- Notice posting, editing and deleting by admin comes in Phase 5
- The unread badge counts DMs plus class chat on the Messages tab and notices plus activity on the Wall bell
- Push payload has no sent time, so the old "already read on another device" check is not ported; Mark as read and opening the chat clear the notification

## Test checklist for the last delivered phase
- First launch after login: rationale dialog, then the Android notification permission, then the battery dialog
- Send a DM from another phone: notification shows the sender photo and name with Reply and Mark as read
- Type a reply in the notification: the other phone receives it; turn on airplane mode first and it sends when the network returns
- Mark as read clears the notification and the unread dot in Messages
- With the DM thread open, a new DM from that person makes no notification
- Class chat message gives a Department Chat notification; tap opens the chat
- Post, comment, reaction, mention, notice from another account: each gives a notification in its channel; tap opens the post or the Notices screen
- Notifications screen: unread dot, tap marks read and opens the target, three-dot Delete, Mark all as read, badge on the Wall bell
- Sign out then sign in on the same phone: notifications work again
- Settings has Notification settings and Battery optimization rows

## In progress
- none
