# Progress

## Status
- Phase 0: done
- Phase 1: done (not yet build-verified)
- Phase 2: done (not yet build-verified)
- Phase 3: not started
- Phase 4: not started
- Phase 5: not started
- Phase 6: not started
- Phase 7: not started

## Current versionCode / versionName
102 / 2.0.0-alpha.2

## Decisions
- Session gate lives in AppViewModel: Loading, SignedOut, NeedsProfile, Ready, Error
- Cached profile (DataStore) gives fast start and offline use; resolve-profile refreshes in background
- Email sign-up creates the profile in the same form via create-profile; account is deleted if create-profile fails
- Google first sign-in gets profileIncomplete and goes to the finish-setup form, saved with update-profile
- Google sign-in uses Credential Manager; web client id read at runtime from default_web_client_id
- Avatar: Photo Picker, native crop dialog (640px JPEG), Cloudinary folder leafmash/avatars through sign-upload
- Cloudinary uploads use a separate OkHttp client so the Firebase token is never sent to Cloudinary
- Presence: lastActive written every 25s while the app is in the foreground
- Added Coil 2.7.0, Credentials 1.3.0, googleid 1.1.1
- Wall feed uses one realtime listener whose limit grows by 20 per page, so older posts stay live too
- Posts are sent by PostPublisher in an app-wide scope; the feed shows a pending card with Retry and Discard
- Reactions, votes, pin and bookmarks are direct Firestore writes; the local cache gives instant UI and rollback on denial
- Author avatars and names come from UserRepository (per-user fetch cache); mention picker loads the users list once
- Multiple photos use one sign-upload call (the API rate-limits sign-upload to 800 ms)
- PushTrigger retries 2s, 5s, 10s on 429, 5xx and network errors
- Saved screen shows bookmarked posts live and notes as link rows (full notes UI comes in Phase 5)

## Backend/web changes (outside android-native)
- none

## Known issues / TODO
- Not compiled locally; first GitHub Actions run may reveal compile errors
- Google sign-in needs release and Play signing SHA-1 registered in Firebase
- Avatar tap-to-view and Posts/Notes tabs on profile come in later phases
- Tapping an author or @mention does not open a profile yet (user profile screen is Phase 6)
- Full-screen photo viewer has no pinch zoom yet
- Pending posts live in memory only: closing the app before they send drops them (offline queue comes in Phase 3)
- Quick links for Routine, Deadlines, Notices, Reports, Admin come in Phases 5 and 6

## Test checklist for the last delivered phase
- Wall opens with posts, pull down to refresh, scroll to the end loads more
- Tap the prompt row, write a post with a photo and with @mention, post it; a Sending card appears then the post
- Add a poll with 2 options, vote on it, tap again to remove the vote
- Tap Like, long press Like to pick another reaction; tap the reactions count to see who reacted
- Open a post, write a comment, reply to a comment, react to a comment
- Long press your comment: edit and delete work; copy works
- Menu on your post: edit, delete; on others: report; admin: pin
- Bookmark a post, open Profile tab then Saved
- Tap a #hashtag to see posts with that tag
- Turn off internet and post: the card shows Couldn't send with Retry

## In progress
- none
