# Progress

## Status
- Phase 0: done
- Phase 1: done (not yet build-verified)
- Phase 2: not started
- Phase 3: not started
- Phase 4: not started
- Phase 5: not started
- Phase 6: not started
- Phase 7: not started

## Current versionCode / versionName
101 / 2.0.0-alpha.1

## Decisions
- Session gate lives in AppViewModel: Loading, SignedOut, NeedsProfile, Ready, Error
- Cached profile (DataStore) gives fast start and offline use; resolve-profile refreshes in background
- Email sign-up creates the profile in the same form via create-profile; account is deleted if create-profile fails
- Google first sign-in gets profileIncomplete and goes to the finish-setup form, saved with update-profile
- Google sign-in uses Credential Manager; web client id read at runtime from default_web_client_id
- Avatar: Photo Picker, native crop dialog (640px JPEG), Cloudinary folder leafmash/avatars through sign-upload
- Cloudinary uploads use a separate OkHttp client so the Firebase token is never sent to Cloudinary
- Presence: lastActive written every 25s while the app is in the foreground
- Added Coil 2.7.0, Credentials 1.3.0, googleid 1.1.1

## Backend/web changes (outside android-native)
- none

## Known issues / TODO
- Not compiled locally; first GitHub Actions run may reveal compile errors
- Google sign-in needs release and Play signing SHA-1 registered in Firebase
- Avatar tap-to-view and Posts/Notes/Saved tabs on profile come in later phases
- Quick links for Routine, Deadlines, Notices, Reports, Admin come in Phases 5 and 6

## Test checklist for the last delivered phase
- Sign up with a new email, finish, see profile
- Sign out from Settings, sign in again
- Wrong password shows a friendly error
- Disposable email is rejected
- Forgot password sends the reset mail
- Continue with Google signs in; new Google user sees finish-setup form
- Edit profile, change photo with crop, save
- Name change is blocked for 7 days after a change
- Close and reopen the app: profile appears instantly

## In progress
- none
