# Progress

## Status
- Phase 0: done
- Phase 1: done (not yet build-verified)
- Phase 2: done (not yet build-verified)
- Phase 3: done (not yet build-verified)
- Phase 4: done (not yet build-verified)
- Phase 5: done (not yet build-verified)
- Phase 6: not started
- Phase 7: not started

## Current versionCode / versionName
105 / 2.0.0-alpha.5

## Decisions
- Session gate lives in AppViewModel: Loading, SignedOut, NeedsProfile, Ready, Error
- Cached profile (DataStore) gives fast start and offline use; resolve-profile refreshes in background
- Email sign-up creates the profile in the same form via create-profile; account is deleted if create-profile fails
- Google first sign-in gets profileIncomplete and goes to the finish-setup form, saved with update-profile
- Google sign-in uses Credential Manager; web client id read at runtime from default_web_client_id
- Avatar: Photo Picker, native crop dialog (640px JPEG), Cloudinary folder leafmash/avatars through sign-upload
- Cloudinary uploads use a separate OkHttp client so the Firebase token is never sent to Cloudinary
- Presence: lastActive written every 25s while the app is in the foreground
- Added Coil 2.7.0, Credentials 1.3.0, googleid 1.1.1
- Wall feed uses one realtime listener whose limit grows by 20 per page, so older posts stay live too
- Posts are sent by PostPublisher in an app-wide scope; the feed shows a pending card with Retry and Discard
- Reactions, votes, pin and bookmarks are direct Firestore writes; the local cache gives instant UI and rollback on denial
- Author avatars and names come from UserRepository (per-user fetch cache); mention picker loads the users list once
- Multiple photos use one sign-upload call (the API rate-limits sign-upload to 800 ms)
- PushTrigger retries 2s, 5s, 10s on 429, 5xx and network errors
- Saved screen shows bookmarked posts live and notes as link rows (full notes UI comes in Phase 5)
- Messaging reads conversations and messages straight from Firestore snapshot listeners with retry and backoff
- DM and class text go through send-dm-message and send-classchat-message; MessageSender serializes sends 1.65 s apart and keeps failed ones for tap-to-retry
- Voice: MediaRecorder m4a (max 60 s) uploaded to Cloudinary leafmash/voice as raw, then sent as audioUrl; class voice is written to classChat directly and pushed with PushTrigger
- Playback uses Media3 ExoPlayer, one voice at a time, speed 1x/1.5x/2x
- Unread: a DM is unread when the last sender is the other person and lastMessageAt is after lastReadAt; class unread counts messages after classChatReads
- Bottom bar Messages badge is the sum of unread DMs plus class unread
- Presence: online when lastActive is under 240 s old
- Push: LeafMashMessagingService handles every data-only payload from send-push; token saved to users/{uid}/fcmTokens/{token} with revoked=false on login and refresh, revoked=true on sign-out (before auth.signOut)
- Four channels: messages (DM and Department Chat, custom sound), social, announcements, reminders; small icon ic_stat_notify and sound leafmash_message copied from resources/android
- DM and class chat use MessagingStyle with circular avatars (Coil), long-lived shortcuts, Reply (RemoteInput then WorkManager ReplyWorker calling send-dm-message or send-classchat-message) and Mark as read actions; swipe-away clears the stored history
- A chat notification is skipped while that thread is open (setActiveChat from the thread screens); duplicate deliveries are dropped by messageId
- Other types are single notifications grouped per channel with a summary when two or more are active
- Deep links: notification tap puts extras on MainActivity; DeepLinkParser maps the web hash urls to a DeepLinkTarget; the target waits in DeepLinkHandler until the nav host exists (cold start safe)
- Notifications screen (bell on the Wall top bar) shows notices and the activity feed with the same public plus personal queries, visibility rules and 60 item cap as the web; read and dismissed ids sync through users/{uid}/readState
- Permission flow: rationale dialog then POST_NOTIFICATIONS, then battery optimization prompt, then OEM autostart prompt; each shown once, also reachable from Settings
- Added WorkManager 2.10.0
- Typing indicator uses conversations.typing; sent at most every 2.5 s and cleared after 3 s idle

## Backend/web changes (outside android-native)
- none

## Known issues / TODO
- Not compiled locally; first GitHub Actions run may reveal compile errors
- Google sign-in needs release and Play signing SHA-1 registered in Firebase
- Avatar tap-to-view and Posts/Notes tabs on profile come in later phases
- Tapping an author, @mention or chat header does not open a profile yet (user profile screen is Phase 6)
- Full-screen photo viewer has no pinch zoom yet
- Pending posts and messages live in memory only: closing the app before they send drops them
- Class chat voice is written directly to Firestore, so it needs the classChat rules to allow audioUrl
- Report notifications open the Wall until Phase 6 adds the reports screen
- Day names and deadline types are shown in English only for the routine; full localization is Phase 7
- No unseen dot for deadlines yet
- Admin panel tiles come in Phase 6; Routine, Deadlines and Notices are reached from Profile quick links
- Resource open and download use the browser; uploaded files are raw Cloudinary uploads
- Saved resources open from the Saved chip in Resources; the older Saved screen still lists them as notes
- The unread badge counts DMs plus class chat on the Messages tab and notices plus activity on the Wall bell
- Push payload has no sent time, so the old "already read on another device" check is not ported; Mark as read and opening the chat clear the notification

## Phase 5 notes
- Routine: reads routine/weekly, today highlighted, admin editor saves the whole document then logs activity and sends the routine push
- Deadlines: realtime list split into Upcoming and Past with day countdown; admin add, edit, delete with date and time pickers; create logs activity and sends the deadline push; changing the due time clears remindedAt
- Notices: admin floating button on the Notices tab to post (urgent switch), edit and delete from the notice detail; post logs activity and sends the notice push
- Resources: paged realtime list (30 per page), search, category and Saved chips, link or file upload (Cloudinary leafmash/resources, max 20MB) created and edited through create-resource and edit-resource, owner delete, bookmark, open count increment on open
- Deep link types deadline and deadline-reminder open Deadlines; routine opens Routine
- ActivityLogger and PushTrigger now carry resourceId, noticeId, deadlineId and urgent

## Test checklist for the last delivered phase
- Profile has Routine, Deadlines and Notices rows
- Routine shows the saved week with today highlighted; as admin the pencil edits classes and Save updates it
- Deadlines: Upcoming and Past chips, countdown text; as admin add one with date and time, edit it, delete it
- Notices tab: as admin post an urgent notice, then edit and delete it from its detail
- Resources: add a link, add an uploaded PDF, open both, search by title, filter by category
- Bookmark a resource, see it under the Saved chip, remove it
- Edit and delete your own resource; others show no edit or delete
- A second account gets pushes for a new deadline, notice and resource

## In progress
- none
