# Progress

## Status
- Phase 0: done
- Phase 1: done (not yet build-verified)
- Phase 2: done (not yet build-verified)
- Phase 3: done (not yet build-verified)
- Phase 4: not started
- Phase 5: not started
- Phase 6: not started
- Phase 7: not started

## Current versionCode / versionName
103 / 2.0.0-alpha.3

## Decisions
- Session gate lives in AppViewModel: Loading, SignedOut, NeedsProfile, Ready, Error
- Cached profile (DataStore) gives fast start and offline use; resolve-profile refreshes in background
- Email sign-up creates the profile in the same form via create-profile; account is deleted if create-profile fails
- Google first sign-in gets profileIncomplete and goes to the finish-setup form, saved with update-profile
- Google sign-in uses Credential Manager; web client id read at runtime from default_web_client_id
- Avatar: Photo Picker, native crop dialog (640px JPEG), Cloudinary folder leafmash/avatars through sign-upload
- Cloudinary uploads use a separate OkHttp client so the Firebase token is never sent to Cloudinary
- Presence: lastActive written every 25s while the app is in the foreground
- Added Coil 2.7.0, Credentials 1.3.0, googleid 1.1.1
- Wall feed uses one realtime listener whose limit grows by 20 per page, so older posts stay live too
- Posts are sent by PostPublisher in an app-wide scope; the feed shows a pending card with Retry and Discard
- Reactions, votes, pin and bookmarks are direct Firestore writes; the local cache gives instant UI and rollback on denial
- Author avatars and names come from UserRepository (per-user fetch cache); mention picker loads the users list once
- Multiple photos use one sign-upload call (the API rate-limits sign-upload to 800 ms)
- PushTrigger retries 2s, 5s, 10s on 429, 5xx and network errors
- Saved screen shows bookmarked posts live and notes as link rows (full notes UI comes in Phase 5)
- Messaging reads conversations and messages straight from Firestore snapshot listeners with retry and backoff
- DM and class text go through send-dm-message and send-classchat-message; MessageSender serializes sends 1.65 s apart and keeps failed ones for tap-to-retry
- Voice: MediaRecorder m4a (max 60 s) uploaded to Cloudinary leafmash/voice as raw, then sent as audioUrl; class voice is written to classChat directly and pushed with PushTrigger
- Playback uses Media3 ExoPlayer, one voice at a time, speed 1x/1.5x/2x
- Unread: a DM is unread when the last sender is the other person and lastMessageAt is after lastReadAt; class unread counts messages after classChatReads
- Bottom bar Messages badge is the sum of unread DMs plus class unread
- Presence: online when lastActive is under 240 s old
- Typing indicator uses conversations.typing; sent at most every 2.5 s and cleared after 3 s idle

## Backend/web changes (outside android-native)
- none

## Known issues / TODO
- Not compiled locally; first GitHub Actions run may reveal compile errors
- Google sign-in needs release and Play signing SHA-1 registered in Firebase
- Avatar tap-to-view and Posts/Notes tabs on profile come in later phases
- Tapping an author, @mention or chat header does not open a profile yet (user profile screen is Phase 6)
- Full-screen photo viewer has no pinch zoom yet
- Pending posts and messages live in memory only: closing the app before they send drops them
- Class chat voice is written directly to Firestore, so it needs the classChat rules to allow audioUrl
- Quick links for Routine, Deadlines, Notices, Reports, Admin come in Phases 5 and 6

## Test checklist for the last delivered phase
- Messages tab shows Department Chat; the pencil opens a classmate search and starts a chat
- Two accounts: send text in a DM, it appears live on the other phone with read ticks
- Send a voice message (allow the mic): timer and waveform show, it plays, speed chip changes 1x/1.5x/2x
- Deny the mic permission: a message appears and the app does not crash
- Open Department Chat on both phones: messages arrive live; long press your message to edit or delete
- Unread dot in the list and the badge on the Messages tab appear and clear after opening
- Turn off internet and send: the bubble says Failed, tap to retry sends it when back online
- Block a user from the thread menu: the composer is replaced by an Unblock bar; typing shows on the other side

## In progress
- none
