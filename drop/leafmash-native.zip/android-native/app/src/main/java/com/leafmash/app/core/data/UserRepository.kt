package com.leafmash.app.core.data

import com.google.firebase.firestore.FirebaseFirestore
import com.leafmash.app.core.profile.ProfileRepository
import com.leafmash.app.core.util.AppScope
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await

@Singleton
class UserRepository @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val appScope: AppScope,
    profiles: ProfileRepository
) {
    private val cache = MutableStateFlow<Map<String, UserSummary>>(emptyMap())
    val users: StateFlow<Map<String, UserSummary>> = cache.asStateFlow()

    private val studentsState = MutableStateFlow<List<UserSummary>>(emptyList())
    val students: StateFlow<List<UserSummary>> = studentsState.asStateFlow()

    private val inFlight = ConcurrentHashMap.newKeySet<String>()
    private val loadMutex = Mutex()

    init {
        appScope.scope.launch {
            profiles.current.filterNotNull().collect { profile -> put(profile.toSummary()) }
        }
    }

    fun ensure(uids: Collection<String>) {
        uids.asSequence()
            .filter { it.isNotEmpty() && !cache.value.containsKey(it) }
            .distinct()
            .filter { inFlight.add(it) }
            .forEach { uid ->
                appScope.scope.launch {
                    try {
                        val snapshot = firestore.collection("users").document(uid).get().await()
                        if (snapshot.exists()) put(snapshot.toUserSummary())
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        Unit
                    } finally {
                        inFlight.remove(uid)
                    }
                }
            }
    }

    suspend fun loadStudents(): List<UserSummary> {
        if (studentsState.value.isNotEmpty()) return studentsState.value
        return loadMutex.withLock {
            if (studentsState.value.isNotEmpty()) return@withLock studentsState.value
            val snapshot = firestore.collection("users").limit(STUDENT_LIMIT).get().await()
            val list = snapshot.documents.map { it.toUserSummary() }.filter { it.name.isNotBlank() }
            cache.update { current -> current + list.associateBy { it.uid } }
            studentsState.value = list
            list
        }
    }

    private fun put(summary: UserSummary) {
        cache.update { it + (summary.uid to summary) }
    }

    private companion object {
        const val STUDENT_LIMIT = 500L
    }
}
