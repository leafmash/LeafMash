package com.leafmash.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

private const val SHIMMER_MILLIS = 1300
private const val SHIMMER_BAND = 0.55f

@Composable
fun ShimmerBox(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(6.dp)
) {
    val base = MaterialTheme.colorScheme.surfaceVariant
    val dark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
    val highlight = if (dark) lerp(base, Color.White, 0.14f) else lerp(base, Color.White, 0.75f)
    val transition = rememberInfiniteTransition(label = "shimmer")
    val progress = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(SHIMMER_MILLIS, easing = LinearEasing), RepeatMode.Restart),
        label = "shimmerProgress"
    )
    Box(
        modifier = modifier
            .clip(shape)
            .background(base)
            .drawWithContent {
                drawContent()
                val band = size.width * SHIMMER_BAND
                val start = -band + progress.value * (size.width + band * 2f)
                drawRect(
                    brush = Brush.linearGradient(
                        colors = listOf(Color.Transparent, highlight, Color.Transparent),
                        start = Offset(start, 0f),
                        end = Offset(start + band, size.height * 0.25f)
                    )
                )
            }
    )
}

@Composable
fun SkeletonPost(modifier: Modifier = Modifier) {
    SocialCard(modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Row {
                ShimmerBox(Modifier.size(44.dp), CircleShape)
                Spacer(Modifier.width(12.dp))
                Column {
                    ShimmerBox(Modifier.width(140.dp).height(12.dp))
                    Spacer(Modifier.height(8.dp))
                    ShimmerBox(Modifier.width(80.dp).height(10.dp))
                }
            }
            Spacer(Modifier.height(16.dp))
            ShimmerBox(Modifier.fillMaxWidth().height(12.dp))
            Spacer(Modifier.height(8.dp))
            ShimmerBox(Modifier.fillMaxWidth(0.7f).height(12.dp))
            Spacer(Modifier.height(16.dp))
            ShimmerBox(Modifier.fillMaxWidth().height(140.dp), RoundedCornerShape(12.dp))
        }
    }
}

@Composable
fun SkeletonStories(modifier: Modifier = Modifier, avatarSize: Dp = 64.dp) {
    LazyRow(
        modifier = modifier.fillMaxWidth(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(14.dp),
        userScrollEnabled = false
    ) {
        items(6) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                ShimmerBox(Modifier.size(avatarSize + 12.dp), CircleShape)
                Spacer(Modifier.height(6.dp))
                ShimmerBox(Modifier.width(48.dp).height(10.dp))
            }
        }
    }
}
