package com.leafmash.app.core.upload

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.leafmash.app.core.network.ApiClient
import com.leafmash.app.core.network.ApiException
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody

data class PickedFile(val uri: Uri, val name: String, val sizeBytes: Long, val mime: String)

data class UploadedFile(val url: String, val name: String, val ext: String)

@Singleton
class FileUploader @Inject constructor(
    @ApplicationContext private val context: Context,
    private val api: ApiClient,
    private val json: Json
) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .writeTimeout(180, TimeUnit.SECONDS)
        .build()

    fun describe(uri: Uri): PickedFile {
        var name = ""
        var size = -1L
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex >= 0) name = cursor.getString(nameIndex).orEmpty()
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
            }
        }
        if (name.isEmpty()) name = uri.lastPathSegment.orEmpty().substringAfterLast('/').ifEmpty { "file" }
        val mime = context.contentResolver.getType(uri).orEmpty().ifEmpty { "application/octet-stream" }
        return PickedFile(uri, name, size, mime)
    }

    suspend fun upload(picked: PickedFile, folder: String): Result<UploadedFile> {
        if (picked.sizeBytes > MAX_BYTES) {
            return Result.failure(ApiException("That file is too large (max 20MB)."))
        }
        val signature = api.call(
            "sign-upload",
            buildJsonObject { put("folder", folder) },
            skipClientCooldown = true
        ).getOrElse { return Result.failure(it) }
        return withContext(Dispatchers.IO) {
            val temp = File.createTempFile("upload", ".bin", context.cacheDir)
            try {
                val input = context.contentResolver.openInputStream(picked.uri)
                    ?: return@withContext Result.failure(ApiException("Couldn't read that file."))
                input.use { source -> temp.outputStream().use { sink -> source.copyTo(sink) } }
                if (temp.length() > MAX_BYTES) {
                    return@withContext Result.failure(ApiException("That file is too large (max 20MB)."))
                }
                send(temp, picked, signature)
            } catch (e: IOException) {
                Result.failure(ApiException("Couldn't read that file."))
            } finally {
                temp.delete()
            }
        }
    }

    private fun send(file: File, picked: PickedFile, signature: JsonObject): Result<UploadedFile> {
        val cloudName = signature.text("cloudName")
        val apiKey = signature.text("apiKey")
        val sigValue = signature.text("signature")
        val timestamp = signature.text("timestamp")
        if (cloudName.isEmpty() || apiKey.isEmpty() || sigValue.isEmpty() || timestamp.isEmpty()) {
            return Result.failure(ApiException("Upload isn't available right now."))
        }
        val body = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", picked.name, file.asRequestBody(picked.mime.toMediaTypeOrNull()))
            .addFormDataPart("api_key", apiKey)
            .addFormDataPart("timestamp", timestamp)
            .addFormDataPart("signature", sigValue)
            .addFormDataPart("upload_preset", signature.text("uploadPreset"))
            .addFormDataPart("folder", signature.text("folder"))
            .addFormDataPart("unique_filename", "true")
            .addFormDataPart("use_filename", "true")
            .build()
        val request = Request.Builder()
            .url("https://api.cloudinary.com/v1_1/$cloudName/raw/upload")
            .post(body)
            .build()
        return try {
            client.newCall(request).execute().use { response ->
                val text = response.body?.string().orEmpty()
                val parsed = runCatching { json.parseToJsonElement(text).jsonObject }.getOrNull()
                if (!response.isSuccessful) {
                    val message = (parsed?.get("error") as? JsonObject)?.text("message").orEmpty()
                    Result.failure(ApiException(message.ifEmpty { "Upload failed." }))
                } else {
                    val url = parsed?.text("secure_url").orEmpty()
                    if (url.isEmpty()) {
                        Result.failure(ApiException("Upload failed."))
                    } else {
                        Result.success(UploadedFile(url, picked.name, extensionOf(picked.name)))
                    }
                }
            }
        } catch (e: IOException) {
            Result.failure(ApiException("Network error. Check your connection and try again."))
        }
    }

    private fun extensionOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return if (ext.length in 2..5 && ext.all { it.isLetterOrDigit() }) ext else ""
    }

    private fun JsonObject.text(key: String): String = (this[key] as? JsonPrimitive)?.contentOrNull.orEmpty()

    private companion object {
        const val MAX_BYTES = 20L * 1024L * 1024L
    }
}
