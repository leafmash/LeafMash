package com.leafmash.app.core.push

object PushChannels {
    const val MESSAGES = "leafmash_messages_v1"
    const val SOCIAL = "leafmash_social_v1"
    const val ANNOUNCEMENTS = "leafmash_announcements_v1"
    const val REMINDERS = "leafmash_reminders_v1"
}

object PushExtras {
    const val URL = "leafmash_url"
    const val TYPE = "leafmash_type"
    const val CHAT_KEY = "leafmash_chat_key"
    const val TARGET_UID = "leafmash_target_uid"
    const val CONVERSATION_ID = "leafmash_conversation_id"
    const val NOTIFICATION_ID = "leafmash_notification_id"
    const val REPLY_TEXT = "leafmash_reply_text"
}

object PushActions {
    const val REPLY = "com.leafmash.app.action.REPLY"
    const val MARK_READ = "com.leafmash.app.action.MARK_READ"
    const val DISMISS = "com.leafmash.app.action.DISMISS"
}

object ChatKeys {
    const val CLASS_CHAT = "classChat"
    fun dm(conversationId: String): String = "dm:$conversationId"
}
