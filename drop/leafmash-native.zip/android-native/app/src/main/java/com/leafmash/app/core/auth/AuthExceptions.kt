package com.leafmash.app.core.auth

class DisposableEmailException : Exception("Disposable email address.")

class GoogleOnlyAccountException : Exception("This account uses Google sign-in.")

class GoogleSignInException(val reason: Reason) : Exception("Google sign-in failed.") {
    enum class Reason { CANCELLED, NO_ACCOUNT, NOT_CONFIGURED, FAILED }
}
