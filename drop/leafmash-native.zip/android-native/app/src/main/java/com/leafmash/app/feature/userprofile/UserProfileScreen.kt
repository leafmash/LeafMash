package com.leafmash.app.feature.userprofile

import com.leafmash.app.ui.theme.LeafPalette
import com.leafmash.app.ui.components.LeafCard
import com.leafmash.app.ui.components.GradientButton
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.background
import com.leafmash.app.ui.components.LeafTopAppBar
import android.content.Intent
import android.net.Uri
import android.text.format.DateUtils
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.leafmash.app.R
import com.leafmash.app.core.data.ProfileBadge
import com.leafmash.app.core.data.UserProfile
import com.leafmash.app.core.data.badge
import com.leafmash.app.core.data.displayName
import com.leafmash.app.ui.components.CollectSnackbars
import com.leafmash.app.ui.components.ProfileBadgeIcon
import com.leafmash.app.ui.components.UserAvatar
import com.leafmash.app.ui.components.rememberTimeAgo

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserProfileScreen(
    onBack: () -> Unit,
    onMessage: (String) -> Unit,
    onOpenPost: (String) -> Unit,
    viewModel: UserProfileViewModel = hiltViewModel()
) {
    val snackbar = remember { SnackbarHostState() }
    val profile = viewModel.profile
    var menuOpen by remember { mutableStateOf(false) }
    var confirmBlock by remember { mutableStateOf(false) }
    val isSelf = viewModel.uid == viewModel.myUid

    CollectSnackbars(viewModel.events, snackbar)

    Scaffold(
        topBar = {
            LeafTopAppBar(
                title = { Text(profile?.displayName ?: stringResource(R.string.user_profile_title), maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                },
                actions = {
                    if (profile != null && !isSelf) {
                        Box {
                            IconButton(onClick = { menuOpen = true }) {
                                Icon(Icons.Filled.MoreVert, contentDescription = stringResource(R.string.post_more))
                            }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            stringResource(
                                                if (viewModel.blockedByMe) R.string.user_unblock else R.string.user_block
                                            )
                                        )
                                    },
                                    onClick = {
                                        menuOpen = false
                                        if (viewModel.blockedByMe) viewModel.toggleBlock() else confirmBlock = true
                                    }
                                )
                            }
                        }
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { inner ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(inner)
        ) {
            when {
                viewModel.loading && profile == null -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                profile == null -> Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(32.dp)
                ) {
                    Text(stringResource(R.string.user_not_found), textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = viewModel::load) { Text(stringResource(R.string.action_retry)) }
                }
                else -> ProfileBody(profile, viewModel, isSelf, onMessage, onOpenPost)
            }
        }
    }

    if (confirmBlock) {
        AlertDialog(
            onDismissRequest = { confirmBlock = false },
            title = { Text(stringResource(R.string.user_block_title)) },
            text = { Text(stringResource(R.string.user_block_text, profile?.displayName.orEmpty())) },
            confirmButton = {
                TextButton(
                    onClick = {
                        confirmBlock = false
                        viewModel.toggleBlock()
                    }
                ) { Text(stringResource(R.string.user_block_confirm)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmBlock = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ProfileBody(
    profile: UserProfile,
    viewModel: UserProfileViewModel,
    isSelf: Boolean,
    onMessage: (String) -> Unit,
    onOpenPost: (String) -> Unit
) {
    val context = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }

    LaunchedEffect(tab) {
        if (tab == 1) viewModel.loadPosts()
        if (tab == 2) viewModel.loadNotes()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 34.dp, bottomEnd = 34.dp))
                .background(LeafPalette.HeroBrush)
                .padding(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 28.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(112.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    UserAvatar(name = profile.displayName, seed = profile.uid, photoUrl = profile.photoUrl, size = 100.dp)
                }
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = profile.displayName,
                        style = MaterialTheme.typography.headlineSmall,
                        color = Color.White,
                        textAlign = TextAlign.Center,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    ProfileBadgeIcon(profile.badge, Modifier.padding(start = 6.dp), 22.dp)
                }
                Spacer(Modifier.height(10.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (profile.session.isNotBlank()) HeroChip(profile.session)
                    if (profile.badge == ProfileBadge.ADMIN) {
                        HeroChip(stringResource(R.string.profile_admin_chip))
                    }
                }
                if (profile.bio.isNotBlank()) {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = profile.bio,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.85f),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
        Column(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
        if (!isSelf) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                GradientButton(
                    text = stringResource(R.string.directory_message),
                    onClick = { onMessage(profile.uid) },
                    leadingIcon = Icons.AutoMirrored.Filled.Message,
                    modifier = Modifier.weight(1f)
                )
                if (profile.hidePhone) {
                    FilledTonalIconButton(onClick = viewModel::showHiddenPhoneNotice) {
                        Icon(Icons.Filled.Lock, contentDescription = stringResource(R.string.directory_hidden))
                    }
                } else if (profile.phone.isNotBlank()) {
                    FilledTonalIconButton(
                        onClick = {
                            runCatching {
                                context.startActivity(
                                    Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + profile.phone))
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            }
                        }
                    ) {
                        Icon(Icons.Filled.Call, contentDescription = stringResource(R.string.directory_call))
                    }
                }
            }
            if (viewModel.blockedByMe) {
                Text(
                    text = stringResource(R.string.user_blocked_note),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text(stringResource(R.string.user_tab_info)) })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text(stringResource(R.string.user_tab_posts)) })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text(stringResource(R.string.user_tab_notes)) })
        }
        Spacer(Modifier.height(8.dp))
        when (tab) {
            0 -> InfoCard(profile)
            1 -> PostsTab(viewModel, onOpenPost)
            else -> NotesTab(viewModel)
        }
        Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun HeroChip(text: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Color.White.copy(alpha = 0.16f))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(text = text, style = MaterialTheme.typography.labelMedium, color = Color.White)
    }
}

@Composable
private fun InfoCard(profile: UserProfile) {
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current
    val notSet = stringResource(R.string.profile_not_set)
    val hidden = stringResource(R.string.profile_hidden)
    val gender = when (profile.gender) {
        "male" -> stringResource(R.string.gender_male)
        "female" -> stringResource(R.string.gender_female)
        "other" -> stringResource(R.string.gender_other)
        else -> notSet
    }
    LeafCard(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(vertical = 4.dp)) {
            InfoRow(stringResource(R.string.profile_label_roll), profile.roll.ifBlank { notSet })
            InfoRow(stringResource(R.string.profile_label_year), profile.year.ifBlank { notSet })
            InfoRow(stringResource(R.string.profile_label_blood), profile.bloodGroup.ifBlank { notSet })
            InfoRow(stringResource(R.string.profile_label_gender), gender)
            InfoRow(stringResource(R.string.profile_label_session), profile.session.ifBlank { notSet })
            InfoRow(stringResource(R.string.profile_label_hometown), profile.hometown.ifBlank { notSet })
            InfoRow(stringResource(R.string.profile_label_address), profile.address.ifBlank { notSet })
            profile.socialLinks.forEach { link ->
                InfoRow(
                    label = stringResource(R.string.profile_label_social),
                    value = link,
                    onClick = { runCatching { uriHandler.openUri(link) } }
                )
            }
            InfoRow(
                stringResource(R.string.profile_label_email),
                if (profile.hideEmail) hidden else profile.email.ifBlank { notSet }
            )
            if (profile.phone.isNotBlank() || profile.hidePhone) {
                InfoRow(
                    stringResource(R.string.profile_label_phone),
                    if (profile.hidePhone) hidden else profile.phone
                )
            }
            InfoRow(stringResource(R.string.profile_label_college), stringResource(R.string.profile_college_name))
            if (profile.createdAtMs > 0L) {
                InfoRow(
                    stringResource(R.string.profile_label_joined),
                    DateUtils.formatDateTime(
                        context,
                        profile.createdAtMs,
                        DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_YEAR
                    )
                )
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String, onClick: (() -> Unit)? = null) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(0.4f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.End,
            color = if (onClick != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(0.6f)
        )
    }
}

@Composable
private fun PostsTab(viewModel: UserProfileViewModel, onOpenPost: (String) -> Unit) {
    when (val load = viewModel.posts) {
        ListLoad.Idle, ListLoad.Loading -> CircularProgressIndicator(Modifier.padding(24.dp))
        ListLoad.Failed -> TabMessage(stringResource(R.string.user_posts_failed))
        is ListLoad.Loaded -> if (load.items.isEmpty()) {
            TabMessage(stringResource(R.string.user_posts_empty))
        } else {
            Column(Modifier.fillMaxWidth()) {
                load.items.forEach { post ->
                    LeafCard(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                        onClick = { onOpenPost(post.id) }
                    ) {
                      Column(Modifier.fillMaxWidth().padding(14.dp)) {
                        Text(
                            text = post.text.ifBlank { stringResource(R.string.user_post_photo_only) },
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = rememberTimeAgo(post.createdAtMs),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                      }
                    }
                }
            }
        }
    }
}

@Composable
private fun NotesTab(viewModel: UserProfileViewModel) {
    val context = LocalContext.current
    when (val load = viewModel.notes) {
        ListLoad.Idle, ListLoad.Loading -> CircularProgressIndicator(Modifier.padding(24.dp))
        ListLoad.Failed -> TabMessage(stringResource(R.string.user_notes_failed))
        is ListLoad.Loaded -> if (load.items.isEmpty()) {
            TabMessage(stringResource(R.string.user_notes_empty))
        } else {
            Column(Modifier.fillMaxWidth()) {
                load.items.forEach { note ->
                    LeafCard(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                        onClick = {
                            runCatching {
                                context.startActivity(
                                    Intent(Intent.ACTION_VIEW, Uri.parse(note.link))
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            }
                        }
                    ) {
                      Column(Modifier.fillMaxWidth().padding(14.dp)) {
                        Text(note.title, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(
                            text = note.category,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                      }
                    }
                }
            }
        }
    }
}

@Composable
private fun TabMessage(text: String) {
    Text(
        text = text,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp)
    )
}
