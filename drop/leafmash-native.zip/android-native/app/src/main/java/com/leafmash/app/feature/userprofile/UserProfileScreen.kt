package com.leafmash.app.feature.userprofile

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leafmash.app.R
import com.leafmash.app.core.data.UserProfile
import com.leafmash.app.core.data.displayName
import com.leafmash.app.feature.profile.ProfileHero
import com.leafmash.app.feature.profile.ProfileInfoCard
import com.leafmash.app.feature.profile.ProfileMessage
import com.leafmash.app.feature.profile.ProfileStatRow
import com.leafmash.app.feature.profile.ProfileTabPills
import com.leafmash.app.feature.profile.profileNoteItems
import com.leafmash.app.feature.profile.profilePostItems
import com.leafmash.app.feature.wall.ReactionsSheet
import com.leafmash.app.ui.components.CollectSnackbars
import com.leafmash.app.ui.components.GradientButton
import com.leafmash.app.ui.components.LeafTopAppBar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserProfileScreen(
    onBack: () -> Unit,
    onMessage: (String) -> Unit,
    onOpenPost: (String, Boolean) -> Unit,
    onEditPost: (String) -> Unit,
    onOpenHashtag: (String) -> Unit,
    viewModel: UserProfileViewModel = hiltViewModel()
) {
    val snackbar = remember { SnackbarHostState() }
    val profile = viewModel.profile
    var confirmBlock by remember { mutableStateOf(false) }

    CollectSnackbars(viewModel.events, snackbar)

    Scaffold(
        topBar = {
            LeafTopAppBar(
                title = {
                    Text(
                        profile?.displayName ?: stringResource(R.string.user_profile_title),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { inner ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(inner)
        ) {
            when {
                viewModel.loading && profile == null -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                profile == null -> Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(32.dp)
                ) {
                    Text(stringResource(R.string.user_not_found), textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = viewModel::load) { Text(stringResource(R.string.action_retry)) }
                }
                else -> ProfileBody(
                    profile = profile,
                    viewModel = viewModel,
                    onMessage = onMessage,
                    onOpenPost = onOpenPost,
                    onEditPost = onEditPost,
                    onOpenHashtag = onOpenHashtag,
                    onRequestBlock = { confirmBlock = true }
                )
            }
        }
    }

    if (confirmBlock) {
        AlertDialog(
            onDismissRequest = { confirmBlock = false },
            title = { Text(stringResource(R.string.user_block_title)) },
            text = { Text(stringResource(R.string.user_block_text, profile?.displayName.orEmpty())) },
            confirmButton = {
                TextButton(
                    onClick = {
                        confirmBlock = false
                        viewModel.toggleBlock()
                    }
                ) { Text(stringResource(R.string.user_block_confirm)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmBlock = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
}

@Composable
private fun ProfileBody(
    profile: UserProfile,
    viewModel: UserProfileViewModel,
    onMessage: (String) -> Unit,
    onOpenPost: (String, Boolean) -> Unit,
    onEditPost: (String) -> Unit,
    onOpenHashtag: (String) -> Unit,
    onRequestBlock: () -> Unit
) {
    val context = LocalContext.current
    val isSelf = viewModel.uid == viewModel.myUid
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var reactionsFor by remember { mutableStateOf<Map<String, String>?>(null) }
    val posts by viewModel.posts.collectAsStateWithLifecycle()
    val users by viewModel.users.collectAsStateWithLifecycle()
    val savedIds by viewModel.savedIds.collectAsStateWithLifecycle()
    val postsEmptyText = stringResource(R.string.user_posts_empty)
    val notesEmptyText = stringResource(R.string.user_notes_empty)
    val notesFailedText = stringResource(R.string.user_notes_failed)

    LaunchedEffect(tab) {
        if (tab == 1) viewModel.loadPosts()
        if (tab == 2) viewModel.loadNotes()
    }

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        item(key = "hero") { ProfileHero(profile, showDepartment = false) }
        item(key = "actions") {
            Column(Modifier.padding(horizontal = 14.dp, vertical = 14.dp)) {
                ProfileStatRow(profile)
                Spacer(Modifier.height(14.dp))
                if (!isSelf) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        GradientButton(
                            text = stringResource(R.string.directory_message),
                            onClick = { onMessage(profile.uid) },
                            leadingIcon = Icons.AutoMirrored.Filled.Message,
                            modifier = Modifier.weight(1f)
                        )
                        if (profile.hidePhone) {
                            FilledTonalIconButton(onClick = viewModel::showHiddenPhoneNotice) {
                                Icon(Icons.Filled.Lock, contentDescription = stringResource(R.string.directory_hidden))
                            }
                        } else if (profile.phone.isNotBlank()) {
                            FilledTonalIconButton(
                                onClick = {
                                    runCatching {
                                        context.startActivity(
                                            Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + profile.phone))
                                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        )
                                    }
                                }
                            ) {
                                Icon(Icons.Filled.Call, contentDescription = stringResource(R.string.directory_call))
                            }
                        }
                        var menuOpen by remember { mutableStateOf(false) }
                        Box {
                            FilledTonalIconButton(onClick = { menuOpen = true }) {
                                Icon(Icons.Filled.MoreVert, contentDescription = stringResource(R.string.post_more))
                            }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            stringResource(
                                                if (viewModel.blockedByMe) R.string.user_unblock else R.string.user_block
                                            )
                                        )
                                    },
                                    onClick = {
                                        menuOpen = false
                                        if (viewModel.blockedByMe) viewModel.toggleBlock() else onRequestBlock()
                                    }
                                )
                            }
                        }
                    }
                    if (viewModel.blockedByMe) {
                        Text(
                            text = stringResource(R.string.user_blocked_note),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                }
                ProfileTabPills(
                    labels = listOf(
                        stringResource(R.string.user_tab_info),
                        stringResource(R.string.user_tab_posts),
                        stringResource(R.string.user_tab_notes)
                    ),
                    selected = tab,
                    onSelect = { tab = it }
                )
            }
        }
        when (tab) {
            0 -> item(key = "info") {
                Column(Modifier.padding(horizontal = 14.dp, vertical = 4.dp)) {
                    ProfileInfoCard(profile, self = false)
                    Spacer(Modifier.height(24.dp))
                }
            }
            1 -> profilePostItems(
                posts = posts,
                users = users,
                savedIds = savedIds,
                myUid = viewModel.myUid,
                isAdmin = viewModel.isAdmin,
                viewModel = viewModel,
                emptyText = postsEmptyText,
                onOpenPost = onOpenPost,
                onEditPost = onEditPost,
                onOpenHashtag = onOpenHashtag,
                onViewReactions = { post ->
                    viewModel.ensureUsers(post.reactions.keys)
                    reactionsFor = post.reactions
                }
            )
            else -> when (val load = viewModel.notes) {
                ListLoad.Idle, ListLoad.Loading -> profileNoteItems(null, notesEmptyText)
                ListLoad.Failed -> item(key = "notes_failed") { ProfileMessage(notesFailedText) }
                is ListLoad.Loaded -> profileNoteItems(load.items, notesEmptyText)
            }
        }
        item(key = "bottom") { Spacer(Modifier.height(16.dp)) }
    }

    val shown = reactionsFor
    if (shown != null) {
        ReactionsSheet(reactions = shown, users = users, onDismiss = { reactionsFor = null })
    }
}
