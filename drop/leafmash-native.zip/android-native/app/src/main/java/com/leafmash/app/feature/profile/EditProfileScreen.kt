package com.leafmash.app.feature.profile

import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leafmash.app.R
import com.leafmash.app.core.data.displayName
import com.leafmash.app.core.util.Validation
import com.leafmash.app.core.util.asString
import com.leafmash.app.ui.components.DropdownField
import com.leafmash.app.ui.components.DropdownOption
import com.leafmash.app.ui.components.LeafTextField
import com.leafmash.app.ui.components.UserAvatar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditProfileScreen(
    firstTime: Boolean,
    onBack: () -> Unit,
    onSignOut: () -> Unit = {},
    onSaved: () -> Unit = {},
    viewModel: EditProfileViewModel = hiltViewModel()
) {
    val profile by viewModel.profile.collectAsStateWithLifecycle()
    val current = profile
    val context = LocalContext.current

    LaunchedEffect(current?.uid) {
        current?.let { viewModel.start(it) }
    }
    LaunchedEffect(viewModel) {
        viewModel.saved.collect { onSaved() }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) viewModel.onPhotoPicked(uri)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        stringResource(if (firstTime) R.string.edit_first_time_title else R.string.edit_title)
                    )
                },
                navigationIcon = {
                    if (!firstTime) {
                        IconButton(onClick = onBack) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = stringResource(R.string.action_back)
                            )
                        }
                    }
                },
                actions = {
                    if (firstTime) {
                        TextButton(onClick = onSignOut) { Text(stringResource(R.string.action_sign_out)) }
                    }
                }
            )
        }
    ) { padding ->
        if (current == null) return@Scaffold
        val form = viewModel.form
        val enabled = !viewModel.saving
        val daysLeft = current.nameChangeDaysRemaining()
        val nameEditable = enabled && (firstTime || daysLeft == 0)
        val preview = remember(viewModel.photoBytes) {
            viewModel.photoBytes?.let { bytes ->
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
            }
        }
        val bloodOptions = Validation.BLOOD_GROUPS.map { DropdownOption(it, it) }
        val genderOptions = listOf(
            DropdownOption("male", stringResource(R.string.gender_male)),
            DropdownOption("female", stringResource(R.string.gender_female)),
            DropdownOption("other", stringResource(R.string.gender_other))
        )
        val yearOptions = listOf(DropdownOption("", stringResource(R.string.profile_not_set))) +
            Validation.YEARS.map { DropdownOption(it, it) }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (firstTime) {
                Text(
                    text = stringResource(R.string.edit_first_time_hint),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (preview != null) {
                    Image(
                        bitmap = preview,
                        contentDescription = stringResource(R.string.profile_photo_cd),
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(96.dp)
                            .clip(CircleShape)
                    )
                } else {
                    UserAvatar(
                        name = form.name.ifBlank { current.displayName },
                        seed = current.uid,
                        photoUrl = current.photoUrl,
                        size = 96.dp,
                        contentDescription = stringResource(R.string.profile_photo_cd)
                    )
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    enabled = enabled
                ) {
                    Icon(Icons.Filled.PhotoCamera, contentDescription = null)
                    Text(
                        text = stringResource(R.string.edit_change_photo),
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
                Text(
                    text = stringResource(R.string.edit_photo_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            LeafTextField(
                label = stringResource(R.string.auth_full_name),
                value = form.name,
                onValueChange = { value -> viewModel.update { it.copy(name = value) } },
                capitalization = KeyboardCapitalization.Words,
                enabled = nameEditable,
                supportingText = if (firstTime) {
                    null
                } else if (daysLeft == 0) {
                    stringResource(R.string.edit_name_hint)
                } else {
                    context.resources.getQuantityString(R.plurals.edit_name_locked, daysLeft, daysLeft)
                }
            )
            LeafTextField(
                label = stringResource(R.string.auth_roll),
                value = form.roll,
                onValueChange = { value -> viewModel.update { it.copy(roll = value) } },
                enabled = enabled
            )
            DropdownField(
                label = stringResource(R.string.auth_blood_group),
                selectedValue = form.blood,
                options = bloodOptions,
                onSelect = { value -> viewModel.update { it.copy(blood = value) } },
                enabled = enabled
            )
            DropdownField(
                label = stringResource(R.string.auth_gender),
                selectedValue = form.gender,
                options = genderOptions,
                onSelect = { value -> viewModel.update { it.copy(gender = value) } },
                enabled = enabled
            )
            LeafTextField(
                label = stringResource(R.string.auth_phone),
                value = form.phone,
                onValueChange = { value -> viewModel.update { it.copy(phone = value) } },
                keyboardType = KeyboardType.Phone,
                enabled = enabled
            )
            DropdownField(
                label = stringResource(R.string.profile_label_year),
                selectedValue = form.year,
                options = yearOptions,
                onSelect = { value -> viewModel.update { it.copy(year = value) } },
                enabled = enabled
            )
            LeafTextField(
                label = stringResource(R.string.profile_label_session),
                value = form.session,
                onValueChange = { value -> viewModel.update { it.copy(session = value) } },
                placeholder = stringResource(R.string.edit_session_placeholder),
                enabled = enabled
            )
            LeafTextField(
                label = stringResource(R.string.profile_label_hometown),
                value = form.hometown,
                onValueChange = { value -> viewModel.update { it.copy(hometown = value) } },
                capitalization = KeyboardCapitalization.Words,
                enabled = enabled
            )
            LeafTextField(
                label = stringResource(R.string.profile_label_address),
                value = form.address,
                onValueChange = { value -> viewModel.update { it.copy(address = value) } },
                enabled = enabled
            )

            Text(
                text = stringResource(R.string.edit_social_links),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary
            )
            form.socialLinks.forEachIndexed { index, link ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = link,
                        onValueChange = { value -> viewModel.updateSocialLink(index, value) },
                        modifier = Modifier.weight(1f),
                        enabled = enabled,
                        singleLine = true,
                        placeholder = { Text(stringResource(R.string.edit_social_placeholder)) },
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                            keyboardType = KeyboardType.Uri,
                            imeAction = ImeAction.Next
                        )
                    )
                    IconButton(onClick = { viewModel.removeSocialLink(index) }, enabled = enabled) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = stringResource(R.string.edit_remove_link)
                        )
                    }
                }
            }
            if (form.socialLinks.size < Validation.MAX_SOCIAL_LINKS) {
                OutlinedButton(onClick = viewModel::addSocialLink, enabled = enabled) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Text(
                        text = stringResource(R.string.edit_add_link),
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
            }

            LeafTextField(
                label = stringResource(R.string.edit_bio),
                value = form.bio,
                onValueChange = { value -> viewModel.update { it.copy(bio = value.take(Validation.MAX_BIO)) } },
                imeAction = ImeAction.Done,
                enabled = enabled,
                supportingText = "${form.bio.length}/${Validation.MAX_BIO}"
            )

            HorizontalDivider()
            Text(
                text = stringResource(R.string.edit_privacy),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary
            )
            SwitchRow(
                title = stringResource(R.string.edit_hide_phone),
                description = stringResource(R.string.edit_hide_phone_hint),
                checked = form.hidePhone,
                enabled = enabled,
                onCheckedChange = { value -> viewModel.update { it.copy(hidePhone = value) } }
            )
            SwitchRow(
                title = stringResource(R.string.edit_hide_email),
                description = null,
                checked = form.hideEmail,
                enabled = enabled,
                onCheckedChange = { value -> viewModel.update { it.copy(hideEmail = value) } }
            )
            SwitchRow(
                title = stringResource(R.string.edit_photo_guard),
                description = stringResource(R.string.edit_photo_guard_hint),
                checked = form.photoGuard,
                enabled = enabled,
                onCheckedChange = { value -> viewModel.update { it.copy(photoGuard = value) } }
            )

            val error = viewModel.error
            if (error != null) {
                Text(
                    text = error.asString(),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.error
                )
            }

            Button(
                onClick = viewModel::save,
                enabled = enabled,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                if (viewModel.saving) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                    Text(
                        text = stringResource(
                            if (viewModel.uploading) R.string.edit_uploading else R.string.edit_saving
                        ),
                        modifier = Modifier.padding(start = 12.dp)
                    )
                } else {
                    Text(stringResource(R.string.edit_save))
                }
            }
            Spacer(Modifier.height(16.dp))
        }

        viewModel.cropSource?.let { bitmap ->
            AvatarCropperDialog(
                source = bitmap,
                onCancel = viewModel::onCropCancelled,
                onConfirm = viewModel::onCropped
            )
        }
    }
}

@Composable
private fun SwitchRow(
    title: String,
    description: String?,
    checked: Boolean,
    enabled: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .toggleable(
                value = checked,
                enabled = enabled,
                role = Role.Switch,
                onValueChange = onCheckedChange
            )
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.bodyLarge)
            if (description != null) {
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Switch(checked = checked, onCheckedChange = null, enabled = enabled, modifier = Modifier.padding(start = 12.dp))
    }
}
