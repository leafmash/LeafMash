package com.leafmash.app.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.leafmash.app.R

val PlusJakartaSans = FontFamily(
    Font(R.font.plus_jakarta_sans_regular, FontWeight.Normal),
    Font(R.font.plus_jakarta_sans_medium, FontWeight.Medium),
    Font(R.font.plus_jakarta_sans_semibold, FontWeight.SemiBold),
    Font(R.font.plus_jakarta_sans_bold, FontWeight.Bold),
    Font(R.font.plus_jakarta_sans_extrabold, FontWeight.ExtraBold)
)

val Sora = FontFamily(
    Font(R.font.sora_semibold, FontWeight.SemiBold),
    Font(R.font.sora_bold, FontWeight.Bold),
    Font(R.font.sora_extrabold, FontWeight.ExtraBold)
)

private val Base = Typography()

private fun TextStyle.body(weight: FontWeight? = null): TextStyle =
    copy(fontFamily = PlusJakartaSans, fontWeight = weight ?: fontWeight)

private fun TextStyle.display(weight: FontWeight): TextStyle =
    copy(fontFamily = Sora, fontWeight = weight)

val LeafMashTypography = Typography(
    displayLarge = Base.displayLarge.display(FontWeight.ExtraBold),
    displayMedium = Base.displayMedium.display(FontWeight.ExtraBold),
    displaySmall = Base.displaySmall.display(FontWeight.Bold),
    headlineLarge = Base.headlineLarge.display(FontWeight.ExtraBold),
    headlineMedium = Base.headlineMedium.display(FontWeight.ExtraBold),
    headlineSmall = Base.headlineSmall.display(FontWeight.Bold),
    titleLarge = Base.titleLarge.display(FontWeight.Bold),
    titleMedium = Base.titleMedium.body(FontWeight.Bold),
    titleSmall = Base.titleSmall.body(FontWeight.SemiBold),
    bodyLarge = Base.bodyLarge.body(),
    bodyMedium = Base.bodyMedium.body(),
    bodySmall = Base.bodySmall.body(),
    labelLarge = Base.labelLarge.body(FontWeight.Bold),
    labelMedium = Base.labelMedium.body(FontWeight.Bold),
    labelSmall = Base.labelSmall.body(FontWeight.Bold)
)
