package com.leafmash.app.core.data

import kotlin.math.ceil
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.longOrNull
import kotlinx.serialization.json.put

data class UserProfile(
    val uid: String,
    val name: String,
    val roll: String,
    val bloodGroup: String,
    val gender: String,
    val phone: String,
    val email: String,
    val photoUrl: String,
    val bio: String,
    val session: String,
    val year: String,
    val hometown: String,
    val address: String,
    val socialLinks: List<String>,
    val hidePhone: Boolean,
    val hideEmail: Boolean,
    val photoGuard: Boolean,
    val verified: Boolean,
    val profileIncomplete: Boolean,
    val nameChangedAtMs: Long,
    val createdAtMs: Long
) {

    fun nameChangeDaysRemaining(nowMs: Long = System.currentTimeMillis()): Int {
        if (nameChangedAtMs <= 0L) return 0
        val elapsed = nowMs - nameChangedAtMs
        if (elapsed >= NAME_CHANGE_COOLDOWN_MS) return 0
        return maxOf(1, ceil((NAME_CHANGE_COOLDOWN_MS - elapsed) / DAY_MS.toDouble()).toInt())
    }

    fun toJson(): JsonObject = buildJsonObject {
        put("uid", uid)
        put("name", name)
        put("roll", roll)
        put("bloodGroup", bloodGroup)
        put("gender", gender)
        put("phone", phone)
        put("email", email)
        put("photoURL", photoUrl)
        put("bio", bio)
        put("session", session)
        put("year", year)
        put("hometown", hometown)
        put("address", address)
        put("socialLinks", JsonArray(socialLinks.map { JsonPrimitive(it) }))
        put("hidePhone", hidePhone)
        put("hideEmail", hideEmail)
        put("photoGuard", photoGuard)
        put("verified", verified)
        put("profileIncomplete", profileIncomplete)
        put("nameChangedAt", nameChangedAtMs)
        put("createdAt", createdAtMs)
    }

    companion object {

        const val DAY_MS = 24L * 60L * 60L * 1000L
        const val NAME_CHANGE_COOLDOWN_MS = 7L * DAY_MS

        fun fromJson(obj: JsonObject, fallbackUid: String = ""): UserProfile {
            val links = (obj["socialLinks"] as? JsonArray)
                ?.mapNotNull { it.asText()?.takeIf { text -> text.isNotBlank() } }
                .orEmpty()
                .ifEmpty { listOfNotNull(obj.str("socialLink").takeIf { it.isNotBlank() }) }
            return UserProfile(
                uid = obj.str("uid").ifEmpty { fallbackUid },
                name = obj.str("name"),
                roll = obj.str("roll"),
                bloodGroup = obj.str("bloodGroup"),
                gender = obj.str("gender"),
                phone = obj.str("phone"),
                email = obj.str("email"),
                photoUrl = obj.str("photoURL"),
                bio = obj.str("bio"),
                session = obj.str("session"),
                year = obj.str("year"),
                hometown = obj.str("hometown"),
                address = obj.str("address"),
                socialLinks = links,
                hidePhone = obj.flag("hidePhone"),
                hideEmail = obj.flag("hideEmail"),
                photoGuard = obj.flag("photoGuard"),
                verified = obj.flag("verified"),
                profileIncomplete = obj.flag("profileIncomplete"),
                nameChangedAtMs = obj.millis("nameChangedAt"),
                createdAtMs = obj.millis("createdAt")
            )
        }
    }
}

private fun kotlinx.serialization.json.JsonElement.asText(): String? =
    if (this is JsonPrimitive && this !is JsonNull) content else null

private fun JsonObject.str(key: String): String = this[key]?.asText().orEmpty()

private fun JsonObject.flag(key: String): Boolean = (this[key] as? JsonPrimitive)?.booleanOrNull ?: false

private fun JsonObject.millis(key: String): Long {
    return when (val element = this[key]) {
        is JsonObject -> {
            val seconds = (element["_seconds"] ?: element["seconds"]) as? JsonPrimitive
            (seconds?.longOrNull ?: 0L) * 1000L
        }
        is JsonPrimitive -> element.longOrNull ?: 0L
        else -> 0L
    }
}
