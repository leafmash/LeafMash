package com.leafmash.app.ui.components

import android.content.Context
import android.text.format.DateFormat
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import com.leafmash.app.R
import java.util.Date

fun formatTimeAgo(context: Context, timeMs: Long): String {
    if (timeMs <= 0L) return context.getString(R.string.time_just_now)
    val seconds = (System.currentTimeMillis() - timeMs) / 1000L
    if (seconds < 60L) return context.getString(R.string.time_just_now)
    val minutes = seconds / 60L
    if (minutes < 60L) return context.getString(R.string.time_minutes_ago, minutes.toInt())
    val hours = minutes / 60L
    if (hours < 24L) return context.getString(R.string.time_hours_ago, hours.toInt())
    val days = hours / 24L
    if (days < 7L) return context.getString(R.string.time_days_ago, days.toInt())
    return DateFormat.getMediumDateFormat(context).format(Date(timeMs))
}

@Composable
fun rememberTimeAgo(timeMs: Long): String {
    val context = LocalContext.current
    return remember(timeMs) { formatTimeAgo(context, timeMs) }
}
