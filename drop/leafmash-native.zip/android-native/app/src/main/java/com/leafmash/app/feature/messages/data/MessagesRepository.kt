package com.leafmash.app.feature.messages.data

import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldPath
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.DocumentSnapshot.ServerTimestampBehavior
import com.leafmash.app.core.util.retryWithBackoff
import com.leafmash.app.core.util.snapshotFlow
import java.util.Date
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

@Singleton
class MessagesRepository @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth
) {

    private val myUid: String get() = auth.currentUser?.uid.orEmpty()

    fun conversationId(a: String, b: String): String = listOf(a, b).sorted().joinToString("_")

    fun conversations(): Flow<List<Conversation>> {
        val uid = myUid
        return firestore.collection("conversations")
            .whereArrayContains("participants", uid)
            .snapshotFlow()
            .map { snapshot ->
                snapshot.documents.mapNotNull { it.toConversation() }
                    .filter { !it.isHiddenFor(uid) }
            }
            .retryWithBackoff()
    }

    fun conversation(conversationId: String): Flow<Conversation?> =
        firestore.collection("conversations").document(conversationId)
            .snapshotFlow()
            .map { it.toConversation() }
            .retryWithBackoff()

    fun dmMessages(conversationId: String): Flow<List<ChatMessage>> =
        firestore.collection("conversations").document(conversationId).collection("messages")
            .orderBy("createdAt", Query.Direction.ASCENDING)
            .limitToLast(DM_LIMIT)
            .snapshotFlow()
            .map { snapshot -> snapshot.documents.map { it.toDmMessage() } }
            .retryWithBackoff()

    fun classMessages(): Flow<List<ChatMessage>> =
        firestore.collection("classChat")
            .orderBy("createdAt", Query.Direction.ASCENDING)
            .limitToLast(CLASS_LIMIT)
            .snapshotFlow()
            .map { snapshot -> snapshot.documents.map { it.toClassMessage() } }
            .retryWithBackoff()

    fun classChatLastRead(): Flow<Long> {
        val uid = myUid
        return firestore.collection("classChatReads").document(uid)
            .snapshotFlow()
            .map { it.getTimestamp("lastReadAt", ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0L }
            .retryWithBackoff()
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    fun unreadTotal(): Flow<Int> {
        val uid = myUid
        val dm = conversations().map { list -> list.count { it.isUnreadFor(uid) } }
        val group = classChatLastRead().flatMapLatest { lastRead -> unreadClassCount(uid, lastRead) }
        return combine(dm, group) { a, b -> a + b }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    fun classUnread(): Flow<Int> {
        val uid = myUid
        return classChatLastRead().flatMapLatest { lastRead -> unreadClassCount(uid, lastRead) }
    }

    private fun unreadClassCount(uid: String, lastReadMs: Long): Flow<Int> =
        firestore.collection("classChat")
            .whereGreaterThan("createdAt", Timestamp(Date(lastReadMs)))
            .orderBy("createdAt", Query.Direction.ASCENDING)
            .limit(UNREAD_LIMIT)
            .snapshotFlow()
            .map { snapshot -> snapshot.documents.count { it.getString("authorUid") != uid } }
            .retryWithBackoff()

    fun lastActive(uids: Collection<String>): Flow<Map<String, Long>> {
        val chunks = uids.filter { it.isNotEmpty() }.distinct().chunked(PRESENCE_CHUNK)
        if (chunks.isEmpty()) return flowOf(emptyMap())
        val flows = chunks.map { chunk ->
            firestore.collection("users")
                .whereIn(FieldPath.documentId(), chunk)
                .snapshotFlow()
                .map { snapshot ->
                    snapshot.documents.associate { doc ->
                        doc.id to (doc.getTimestamp("lastActive")?.toDate()?.time ?: 0L)
                    }
                }
        }
        return combine(flows) { parts -> parts.fold(emptyMap<String, Long>()) { acc, part -> acc + part } }
            .retryWithBackoff()
    }

    suspend fun ensureConversation(otherUid: String): String {
        val uid = myUid
        val id = conversationId(uid, otherUid)
        val ref = firestore.collection("conversations").document(id)
        val snapshot = ref.get().await()
        if (!snapshot.exists()) {
            ref.set(
                mapOf(
                    "participants" to listOf(uid, otherUid).sorted(),
                    "lastMessageText" to "",
                    "lastMessageAt" to FieldValue.serverTimestamp(),
                    "lastSenderUid" to null,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
        return id
    }

    suspend fun markDmRead(conversationId: String) {
        val uid = myUid
        if (uid.isEmpty()) return
        firestore.collection("conversations").document(conversationId)
            .update("lastReadAt.$uid", FieldValue.serverTimestamp())
            .await()
    }

    suspend fun markClassChatRead() {
        val uid = myUid
        if (uid.isEmpty()) return
        firestore.collection("classChatReads").document(uid)
            .set(mapOf("lastReadAt" to FieldValue.serverTimestamp()), SetOptions.merge())
            .await()
    }

    suspend fun setTyping(conversationId: String, typing: Boolean) {
        val uid = myUid
        if (uid.isEmpty()) return
        firestore.collection("conversations").document(conversationId)
            .update("typing.$uid", if (typing) FieldValue.serverTimestamp() else FieldValue.delete())
            .await()
    }

    suspend fun setBlocked(otherUid: String, blocked: Boolean) {
        val uid = myUid
        val id = ensureConversation(otherUid)
        firestore.collection("conversations").document(id)
            .update("blockedBy", if (blocked) FieldValue.arrayUnion(uid) else FieldValue.arrayRemove(uid))
            .await()
    }

    suspend fun deleteConversationForMe(conversationId: String) {
        val uid = myUid
        firestore.collection("conversations").document(conversationId)
            .update("deletedFor.$uid", FieldValue.serverTimestamp())
            .await()
    }

    suspend fun deleteDmMessage(conversationId: String, messageId: String) {
        firestore.collection("conversations").document(conversationId)
            .collection("messages").document(messageId)
            .delete()
            .await()
    }

    suspend fun deleteClassMessage(messageId: String) {
        firestore.collection("classChat").document(messageId).delete().await()
    }

    suspend fun editClassMessage(messageId: String, text: String) {
        firestore.collection("classChat").document(messageId)
            .update(mapOf("text" to text, "edited" to true))
            .await()
    }

    suspend fun addClassVoice(authorName: String, audioUrl: String, durationSec: Int): String {
        val reference = firestore.collection("classChat").add(
            mapOf(
                "authorUid" to myUid,
                "authorName" to authorName,
                "audioUrl" to audioUrl,
                "audioDurationSec" to durationSec,
                "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()
        return reference.id
    }

    private companion object {
        const val DM_LIMIT = 300L
        const val CLASS_LIMIT = 150L
        const val UNREAD_LIMIT = 100L
        const val PRESENCE_CHUNK = 10
    }
}
