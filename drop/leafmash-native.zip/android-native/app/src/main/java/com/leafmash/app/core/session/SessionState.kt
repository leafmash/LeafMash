package com.leafmash.app.core.session

import com.leafmash.app.core.data.UserProfile
import com.leafmash.app.core.util.UiText

sealed interface SessionState {
    data object Loading : SessionState
    data class SignedOut(val message: UiText?) : SessionState
    data class NeedsProfile(val profile: UserProfile) : SessionState
    data class Ready(val profile: UserProfile) : SessionState
    data class Error(val message: UiText) : SessionState
}
