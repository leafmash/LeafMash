package com.leafmash.app.feature.wall

import com.leafmash.app.core.data.badge
import com.leafmash.app.ui.components.FlatItem
import com.leafmash.app.ui.components.LeafCard
import com.leafmash.app.ui.components.EmptyCard
import androidx.compose.material.icons.filled.Search
import androidx.compose.foundation.layout.PaddingValues
import com.leafmash.app.ui.components.LeafTopAppBar
import androidx.compose.runtime.getValue
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leafmash.app.R
import com.leafmash.app.core.data.authorFallback
import com.leafmash.app.core.data.displayName
import com.leafmash.app.core.util.asString
import com.leafmash.app.ui.components.UserAvatar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HashtagScreen(
    onBack: () -> Unit,
    onOpenPost: (String, Boolean) -> Unit,
    viewModel: HashtagViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val users by viewModel.users.collectAsStateWithLifecycle()
    Scaffold(
        topBar = {
            LeafTopAppBar(
                title = { Text("#${viewModel.tag}") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { inner ->
        Column(Modifier.fillMaxSize().padding(inner), horizontalAlignment = Alignment.CenterHorizontally) {
            when {
                state.loading -> CircularProgressIndicator(Modifier.padding(32.dp))
                state.error != null -> {
                    Text(
                        text = state.error?.asString().orEmpty(),
                        style = MaterialTheme.typography.bodyLarge,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(32.dp)
                    )
                    Button(onClick = viewModel::load) { Text(stringResource(R.string.action_retry)) }
                }
                state.posts.isEmpty() -> EmptyCard(
                    title = stringResource(R.string.hashtag_empty),
                    icon = Icons.Filled.Search,
                    modifier = Modifier.padding(24.dp)
                )
                else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 8.dp)) {
                    items(state.posts, key = { it.id }) { post ->
                        val author = users[post.authorUid] ?: post.authorFallback()
                        FlatItem(
                            modifier = Modifier
                                .fillMaxWidth(),
                            onClick = { onOpenPost(post.id, false) }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 64.dp)
                                    .padding(horizontal = 16.dp, vertical = 14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                UserAvatar(name = author.displayName, seed = author.uid, photoUrl = author.photoUrl, size = 40.dp, badge = author.badge)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(text = author.displayName, style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        text = post.text.take(90),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 2
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
