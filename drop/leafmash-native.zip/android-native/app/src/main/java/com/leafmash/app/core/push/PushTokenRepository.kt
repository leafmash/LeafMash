package com.leafmash.app.core.push

import android.os.Build
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessaging
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull

@Singleton
class PushTokenRepository @Inject constructor(
    private val auth: FirebaseAuth,
    private val firestore: FirebaseFirestore
) {

    @Volatile
    private var registeredKey: String? = null

    suspend fun register(knownToken: String? = null) {
        val uid = auth.currentUser?.uid ?: return
        try {
            val token = knownToken ?: FirebaseMessaging.getInstance().token.await()
            if (token.isBlank()) return
            val key = "$uid:$token"
            if (registeredKey == key) return
            firestore.collection("users").document(uid).collection("fcmTokens").document(token)
                .set(
                    mapOf(
                        "createdAt" to FieldValue.serverTimestamp(),
                        "userAgent" to "LeafMash Android ${Build.VERSION.RELEASE}",
                        "revoked" to false
                    ),
                    com.google.firebase.firestore.SetOptions.merge()
                )
                .await()
            registeredKey = key
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Unit
        }
    }

    suspend fun revoke() {
        val uid = auth.currentUser?.uid ?: return
        registeredKey = null
        withTimeoutOrNull(REVOKE_TIMEOUT_MS) {
            try {
                val token = FirebaseMessaging.getInstance().token.await()
                firestore.collection("users").document(uid).collection("fcmTokens").document(token)
                    .set(
                        mapOf(
                            "revoked" to true,
                            "revokedAt" to FieldValue.serverTimestamp()
                        ),
                        com.google.firebase.firestore.SetOptions.merge()
                    )
                    .await()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Unit
            }
        }
    }

    private companion object {
        const val REVOKE_TIMEOUT_MS = 4_000L
    }
}
