package com.leafmash.app.feature.deadlines

import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.leafmash.app.core.notify.ActivityLogger
import com.leafmash.app.core.notify.PushTrigger
import com.leafmash.app.core.profile.ProfileRepository
import com.leafmash.app.core.util.retryWithBackoff
import com.leafmash.app.core.util.snapshotFlow
import java.util.Date
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

val DeadlineTypes = listOf("Assignment", "Quiz", "Exam", "Other")

data class Deadline(
    val id: String,
    val title: String,
    val type: String,
    val course: String,
    val notes: String,
    val dueAtMs: Long,
    val postedByName: String,
    val createdAtMs: Long
)

private fun DocumentSnapshot.toDeadline(): Deadline = Deadline(
    id = id,
    title = getString("title").orEmpty(),
    type = getString("type").orEmpty().ifEmpty { "Other" },
    course = getString("course").orEmpty(),
    notes = getString("notes").orEmpty(),
    dueAtMs = getTimestamp("dueAt")?.toDate()?.time ?: 0L,
    postedByName = getString("postedByName").orEmpty(),
    createdAtMs = getTimestamp("createdAt")?.toDate()?.time ?: 0L
)

@Singleton
class DeadlinesRepository @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth,
    private val profiles: ProfileRepository,
    private val activity: ActivityLogger,
    private val push: PushTrigger
) {

    fun observe(): Flow<List<Deadline>> =
        firestore.collection("deadlines")
            .orderBy("dueAt", Query.Direction.ASCENDING)
            .snapshotFlow()
            .map { snapshot -> snapshot.documents.map { it.toDeadline() } }
            .retryWithBackoff()

    suspend fun create(title: String, type: String, course: String, notes: String, dueAtMs: Long) {
        val uid = auth.currentUser?.uid ?: error("Not signed in")
        val ref = firestore.collection("deadlines").document()
        ref.set(
            mapOf(
                "title" to title,
                "type" to type,
                "course" to course,
                "notes" to notes,
                "dueAt" to Timestamp(Date(dueAtMs)),
                "postedByUid" to uid,
                "postedByName" to (profiles.current.value?.name ?: "Admin"),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
                "remindedAt" to null
            )
        ).await()
        activity.log("deadline", title, deadlineId = ref.id)
        push.send(type = "deadline", text = title, deadlineId = ref.id)
    }

    suspend fun update(existing: Deadline, title: String, type: String, course: String, notes: String, dueAtMs: Long) {
        val data = HashMap<String, Any?>()
        data["title"] = title
        data["type"] = type
        data["course"] = course
        data["notes"] = notes
        data["dueAt"] = Timestamp(Date(dueAtMs))
        data["updatedAt"] = FieldValue.serverTimestamp()
        if (existing.dueAtMs != dueAtMs) data["remindedAt"] = null
        firestore.collection("deadlines").document(existing.id).update(data).await()
    }

    suspend fun delete(id: String) {
        firestore.collection("deadlines").document(id).delete().await()
        activity.deleteForDeadline(id)
    }
}
