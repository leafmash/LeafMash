package com.leafmash.app.feature.auth

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.leafmash.app.R
import com.leafmash.app.core.util.UiText
import com.leafmash.app.core.util.Validation
import com.leafmash.app.core.util.asString
import com.leafmash.app.ui.components.DropdownField
import com.leafmash.app.ui.components.DropdownOption
import com.leafmash.app.ui.components.LeafTextField
import com.leafmash.app.ui.components.PasswordField

@Composable
fun AuthScreen(
    notice: UiText?,
    viewModel: AuthViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(viewModel) {
        viewModel.events.collect { message ->
            snackbarHostState.showSnackbar(message.resolve(context))
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(R.drawable.splash_icon),
                contentDescription = null,
                modifier = Modifier.size(72.dp)
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = stringResource(R.string.auth_tagline),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(20.dp))

            if (notice != null) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer,
                        contentColor = MaterialTheme.colorScheme.onErrorContainer
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = notice.asString(),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(12.dp)
                    )
                }
                Spacer(Modifier.height(12.dp))
            }

            TabRow(
                selectedTabIndex = viewModel.tab.ordinal,
                containerColor = MaterialTheme.colorScheme.background
            ) {
                Tab(
                    selected = viewModel.tab == AuthTab.SIGN_IN,
                    onClick = { viewModel.selectTab(AuthTab.SIGN_IN) },
                    text = { Text(stringResource(R.string.auth_tab_sign_in)) }
                )
                Tab(
                    selected = viewModel.tab == AuthTab.SIGN_UP,
                    onClick = { viewModel.selectTab(AuthTab.SIGN_UP) },
                    text = { Text(stringResource(R.string.auth_tab_sign_up)) }
                )
            }
            Spacer(Modifier.height(16.dp))

            when (viewModel.tab) {
                AuthTab.SIGN_IN -> SignInContent(viewModel)
                AuthTab.SIGN_UP -> SignUpContent(viewModel)
            }

            val error = viewModel.error
            if (error != null) {
                Spacer(Modifier.height(12.dp))
                Text(
                    text = error.asString(),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(Modifier.height(16.dp))
            HorizontalDivider()
            Spacer(Modifier.height(16.dp))

            OutlinedButton(
                onClick = { viewModel.signInWithGoogle(context) },
                enabled = !viewModel.loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(stringResource(R.string.auth_continue_google))
            }
        }
    }
}

@Composable
private fun SignInContent(viewModel: AuthViewModel) {
    val form = viewModel.signInForm
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        LeafTextField(
            label = stringResource(R.string.auth_email),
            value = form.email,
            onValueChange = { value -> viewModel.updateSignIn { it.copy(email = value) } },
            keyboardType = KeyboardType.Email,
            enabled = !viewModel.loading
        )
        PasswordField(
            label = stringResource(R.string.auth_password),
            value = form.password,
            onValueChange = { value -> viewModel.updateSignIn { it.copy(password = value) } },
            onDone = viewModel::submitSignIn
        )
        TextButton(
            onClick = viewModel::sendPasswordReset,
            enabled = !viewModel.loading,
            modifier = Modifier.align(Alignment.End)
        ) {
            Text(stringResource(R.string.auth_forgot_password))
        }
        SubmitButton(
            label = stringResource(R.string.auth_sign_in),
            loading = viewModel.loading,
            onClick = viewModel::submitSignIn
        )
    }
}

@Composable
private fun SignUpContent(viewModel: AuthViewModel) {
    val form = viewModel.signUpForm
    val enabled = !viewModel.loading
    val bloodOptions = Validation.BLOOD_GROUPS.map { DropdownOption(it, it) }
    val genderOptions = listOf(
        DropdownOption("male", stringResource(R.string.gender_male)),
        DropdownOption("female", stringResource(R.string.gender_female)),
        DropdownOption("other", stringResource(R.string.gender_other))
    )
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        LeafTextField(
            label = stringResource(R.string.auth_full_name),
            value = form.name,
            onValueChange = { value -> viewModel.updateSignUp { it.copy(name = value) } },
            capitalization = KeyboardCapitalization.Words,
            enabled = enabled
        )
        LeafTextField(
            label = stringResource(R.string.auth_roll),
            value = form.roll,
            onValueChange = { value -> viewModel.updateSignUp { it.copy(roll = value) } },
            enabled = enabled
        )
        DropdownField(
            label = stringResource(R.string.auth_blood_group),
            selectedValue = form.blood,
            options = bloodOptions,
            onSelect = { value -> viewModel.updateSignUp { it.copy(blood = value) } },
            enabled = enabled
        )
        DropdownField(
            label = stringResource(R.string.auth_gender),
            selectedValue = form.gender,
            options = genderOptions,
            onSelect = { value -> viewModel.updateSignUp { it.copy(gender = value) } },
            enabled = enabled
        )
        LeafTextField(
            label = stringResource(R.string.auth_phone),
            value = form.phone,
            onValueChange = { value -> viewModel.updateSignUp { it.copy(phone = value) } },
            keyboardType = KeyboardType.Phone,
            enabled = enabled
        )
        LeafTextField(
            label = stringResource(R.string.auth_email),
            value = form.email,
            onValueChange = { value -> viewModel.updateSignUp { it.copy(email = value) } },
            keyboardType = KeyboardType.Email,
            enabled = enabled
        )
        PasswordField(
            label = stringResource(R.string.auth_password),
            value = form.password,
            onValueChange = { value -> viewModel.updateSignUp { it.copy(password = value) } },
            supportingText = stringResource(R.string.auth_password_hint),
            imeAction = ImeAction.Done,
            onDone = viewModel::submitSignUp
        )
        SubmitButton(
            label = stringResource(R.string.auth_sign_up),
            loading = viewModel.loading,
            onClick = viewModel::submitSignUp
        )
    }
}

@Composable
private fun SubmitButton(label: String, loading: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = !loading,
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
    ) {
        if (loading) {
            CircularProgressIndicator(
                modifier = Modifier.size(22.dp),
                strokeWidth = 2.dp,
                color = MaterialTheme.colorScheme.onPrimary
            )
        } else {
            Text(label)
        }
    }
}
