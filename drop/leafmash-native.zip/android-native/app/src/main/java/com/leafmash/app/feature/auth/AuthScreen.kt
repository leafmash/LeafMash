package com.leafmash.app.feature.auth

import com.leafmash.app.ui.theme.LeafPalette
import com.leafmash.app.ui.components.GradientButton
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.material3.ButtonDefaults
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.leafmash.app.R
import com.leafmash.app.core.util.UiText
import com.leafmash.app.core.util.Validation
import com.leafmash.app.core.util.asString
import com.leafmash.app.ui.components.DropdownField
import com.leafmash.app.ui.components.DropdownOption
import com.leafmash.app.ui.components.LeafTextField
import com.leafmash.app.ui.components.PasswordField

@Composable
fun AuthScreen(
    notice: UiText?,
    viewModel: AuthViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(viewModel) {
        viewModel.events.collect { message ->
            snackbarHostState.showSnackbar(message.resolve(context))
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding()
                .verticalScroll(rememberScrollState())
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(bottomStart = 36.dp, bottomEnd = 36.dp))
                    .background(LeafPalette.HeroBrush)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.statusBars)
                        .padding(start = 24.dp, end = 24.dp, top = 28.dp, bottom = 36.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(88.dp)
                            .clip(RoundedCornerShape(28.dp))
                            .background(Color.White.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(R.drawable.splash_icon),
                            contentDescription = null,
                            modifier = Modifier.size(64.dp)
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                    Text(
                        text = stringResource(R.string.app_name),
                        style = MaterialTheme.typography.headlineMedium,
                        color = Color.White
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = stringResource(R.string.auth_tagline),
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.8f),
                        textAlign = TextAlign.Center
                    )
                }
            }

            Column(
                modifier = Modifier
                    .navigationBarsPadding()
                    .padding(horizontal = 22.dp, vertical = 22.dp)
            ) {
                if (notice != null) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer,
                            contentColor = MaterialTheme.colorScheme.onErrorContainer
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = notice.asString(),
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
                        .padding(5.dp)
                ) {
                    AuthToggleItem(
                        selected = viewModel.tab == AuthTab.SIGN_IN,
                        text = stringResource(R.string.auth_tab_sign_in),
                        onClick = { viewModel.selectTab(AuthTab.SIGN_IN) },
                        modifier = Modifier.weight(1f)
                    )
                    AuthToggleItem(
                        selected = viewModel.tab == AuthTab.SIGN_UP,
                        text = stringResource(R.string.auth_tab_sign_up),
                        onClick = { viewModel.selectTab(AuthTab.SIGN_UP) },
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(20.dp))

                when (viewModel.tab) {
                    AuthTab.SIGN_IN -> SignInContent(viewModel)
                    AuthTab.SIGN_UP -> SignUpContent(viewModel)
                }

                val error = viewModel.error
                if (error != null) {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = error.asString(),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    HorizontalDivider(modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.outlineVariant)
                    Text(
                        text = "•",
                        color = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    HorizontalDivider(modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.outlineVariant)
                }
                Spacer(Modifier.height(18.dp))

                OutlinedButton(
                    onClick = { viewModel.signInWithGoogle(context) },
                    enabled = !viewModel.loading,
                    shape = CircleShape,
                    border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outlineVariant),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerLowest
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                ) {
                    Text(
                        text = stringResource(R.string.auth_continue_google),
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}

@Composable
private fun AuthToggleItem(
    selected: Boolean,
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(CircleShape)
            .then(if (selected) Modifier.background(LeafPalette.ButtonBrush) else Modifier)
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun SignInContent(viewModel: AuthViewModel) {
    val form = viewModel.signInForm
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        LeafTextField(
            label = stringResource(R.string.auth_email),
            value = form.email,
            onValueChange = { value -> viewModel.updateSignIn { it.copy(email = value) } },
            keyboardType = KeyboardType.Email,
            enabled = !viewModel.loading
        )
        PasswordField(
            label = stringResource(R.string.auth_password),
            value = form.password,
            onValueChange = { value -> viewModel.updateSignIn { it.copy(password = value) } },
            onDone = viewModel::submitSignIn
        )
        TextButton(
            onClick = viewModel::sendPasswordReset,
            enabled = !viewModel.loading,
            modifier = Modifier.align(Alignment.End)
        ) {
            Text(stringResource(R.string.auth_forgot_password))
        }
        SubmitButton(
            label = stringResource(R.string.auth_sign_in),
            loading = viewModel.loading,
            onClick = viewModel::submitSignIn
        )
    }
}

@Composable
private fun SignUpContent(viewModel: AuthViewModel) {
    val form = viewModel.signUpForm
    val enabled = !viewModel.loading
    val bloodOptions = Validation.BLOOD_GROUPS.map { DropdownOption(it, it) }
    val genderOptions = listOf(
        DropdownOption("male", stringResource(R.string.gender_male)),
        DropdownOption("female", stringResource(R.string.gender_female)),
        DropdownOption("other", stringResource(R.string.gender_other))
    )
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        LeafTextField(
            label = stringResource(R.string.auth_full_name),
            value = form.name,
            onValueChange = { value -> viewModel.updateSignUp { it.copy(name = value) } },
            capitalization = KeyboardCapitalization.Words,
            enabled = enabled
        )
        LeafTextField(
            label = stringResource(R.string.auth_roll),
            value = form.roll,
            onValueChange = { value -> viewModel.updateSignUp { it.copy(roll = value) } },
            enabled = enabled
        )
        DropdownField(
            label = stringResource(R.string.auth_blood_group),
            selectedValue = form.blood,
            options = bloodOptions,
            onSelect = { value -> viewModel.updateSignUp { it.copy(blood = value) } },
            enabled = enabled
        )
        DropdownField(
            label = stringResource(R.string.auth_gender),
            selectedValue = form.gender,
            options = genderOptions,
            onSelect = { value -> viewModel.updateSignUp { it.copy(gender = value) } },
            enabled = enabled
        )
        LeafTextField(
            label = stringResource(R.string.auth_phone),
            value = form.phone,
            onValueChange = { value -> viewModel.updateSignUp { it.copy(phone = value) } },
            keyboardType = KeyboardType.Phone,
            enabled = enabled
        )
        LeafTextField(
            label = stringResource(R.string.auth_email),
            value = form.email,
            onValueChange = { value -> viewModel.updateSignUp { it.copy(email = value) } },
            keyboardType = KeyboardType.Email,
            enabled = enabled
        )
        PasswordField(
            label = stringResource(R.string.auth_password),
            value = form.password,
            onValueChange = { value -> viewModel.updateSignUp { it.copy(password = value) } },
            supportingText = stringResource(R.string.auth_password_hint),
            imeAction = ImeAction.Done,
            onDone = viewModel::submitSignUp
        )
        SubmitButton(
            label = stringResource(R.string.auth_sign_up),
            loading = viewModel.loading,
            onClick = viewModel::submitSignUp
        )
    }
}

@Composable
private fun SubmitButton(label: String, loading: Boolean, onClick: () -> Unit) {
    GradientButton(
        text = label,
        onClick = onClick,
        loading = loading,
        modifier = Modifier.fillMaxWidth()
    )
}
