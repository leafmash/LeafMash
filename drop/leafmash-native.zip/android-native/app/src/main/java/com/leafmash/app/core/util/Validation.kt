package com.leafmash.app.core.util

import com.leafmash.app.R

object Validation {

    val PHONE_REGEX = Regex("^[0-9+\\-\\s()]{6,20}$")

    val BLOOD_GROUPS = listOf("A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-")

    val YEARS = listOf("1st Year", "2nd Year", "3rd Year", "4th Year", "Honours Completed")

    val GENDERS = listOf("male", "female", "other")

    const val MAX_SOCIAL_LINKS = 5
    const val MAX_BIO = 150
    const val MAX_NAME = 60

    fun isPhoneValid(phone: String): Boolean = PHONE_REGEX.matches(phone.trim())

    fun passwordProblem(password: String): UiText? = when {
        password.length < 8 -> UiText.Res(R.string.err_password_short)
        !password.any { it in 'a'..'z' || it in 'A'..'Z' } -> UiText.Res(R.string.err_password_letter)
        !password.any { it in '0'..'9' } -> UiText.Res(R.string.err_password_number)
        else -> null
    }

    fun isEmailValid(email: String): Boolean =
        android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()
}
