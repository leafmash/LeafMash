package com.leafmash.app.feature.settings

import com.leafmash.app.ui.components.LeafCard
import androidx.compose.ui.graphics.Color
import androidx.compose.material3.ListItemDefaults
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Spacer
import com.leafmash.app.ui.components.LeafTopAppBar
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leafmash.app.BuildConfig
import com.leafmash.app.R
import com.leafmash.app.core.push.BatterySettings
import com.leafmash.app.core.settings.ThemePreference

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val selected by viewModel.themePreference.collectAsStateWithLifecycle()
    var confirmSignOut by rememberSaveable { mutableStateOf(false) }
    val context = LocalContext.current

    Scaffold(
        topBar = {
            LeafTopAppBar(
                title = { Text(stringResource(R.string.settings_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.action_back)
                        )
                    }
                }
            )
        }
    ) { padding ->
        if (confirmSignOut) {
            SignOutDialog(
                onConfirm = {
                    confirmSignOut = false
                    viewModel.signOut()
                },
                onDismiss = { confirmSignOut = false }
            )
        }
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            SectionHeader(stringResource(R.string.settings_appearance))
            LeafCard(Modifier.fillMaxWidth()) {
                ThemeOption(
                    label = stringResource(R.string.settings_theme_system),
                    selected = selected == ThemePreference.SYSTEM,
                    onSelect = { viewModel.setThemePreference(ThemePreference.SYSTEM) }
                )
                ThemeOption(
                    label = stringResource(R.string.settings_theme_light),
                    selected = selected == ThemePreference.LIGHT,
                    onSelect = { viewModel.setThemePreference(ThemePreference.LIGHT) }
                )
                ThemeOption(
                    label = stringResource(R.string.settings_theme_dark),
                    selected = selected == ThemePreference.DARK,
                    onSelect = { viewModel.setThemePreference(ThemePreference.DARK) }
                )
            }

            SectionHeader(stringResource(R.string.settings_notifications))
            LeafCard(Modifier.fillMaxWidth()) {
                ListItem(
                    colors = transparentItem(),
                    modifier = Modifier.clickable { BatterySettings.openNotificationSettings(context) },
                    headlineContent = { Text(stringResource(R.string.settings_notification_settings)) },
                    supportingContent = { Text(stringResource(R.string.settings_notification_settings_hint)) }
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                ListItem(
                    colors = transparentItem(),
                    modifier = Modifier.clickable { BatterySettings.openBatterySettings(context) },
                    headlineContent = { Text(stringResource(R.string.settings_battery)) },
                    supportingContent = { Text(stringResource(R.string.settings_battery_hint)) }
                )
            }

            SectionHeader(stringResource(R.string.settings_account))
            LeafCard(Modifier.fillMaxWidth()) {
                ListItem(
                    colors = transparentItem(),
                    headlineContent = { Text(stringResource(R.string.settings_signed_in_as)) },
                    supportingContent = { Text(viewModel.accountEmail) }
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                ListItem(
                    colors = transparentItem(),
                    modifier = Modifier.clickable { confirmSignOut = true },
                    leadingContent = {
                        Icon(
                            Icons.AutoMirrored.Filled.Logout,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error
                        )
                    },
                    headlineContent = {
                        Text(
                            text = stringResource(R.string.action_sign_out),
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                )
            }

            SectionHeader(stringResource(R.string.settings_about))
            LeafCard(Modifier.fillMaxWidth()) {
                ListItem(
                    colors = transparentItem(),
                    headlineContent = { Text(stringResource(R.string.settings_version)) },
                    supportingContent = { Text(BuildConfig.VERSION_NAME) }
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                ListItem(
                    colors = transparentItem(),
                    headlineContent = { Text(stringResource(R.string.settings_firebase_project)) },
                    supportingContent = { Text(viewModel.firebaseProjectId) }
                )
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun transparentItem() = ListItemDefaults.colors(containerColor = Color.Transparent)

@Composable
private fun SignOutDialog(onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.settings_sign_out_title)) },
        text = { Text(stringResource(R.string.settings_sign_out_text)) },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text(stringResource(R.string.action_sign_out)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) }
        }
    )
}

@Composable
private fun SectionHeader(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 6.dp, top = 16.dp, bottom = 8.dp)
    )
}

@Composable
private fun ThemeOption(
    label: String,
    selected: Boolean,
    onSelect: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .selectable(selected = selected, onClick = onSelect, role = Role.RadioButton)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = null)
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(start = 16.dp)
        )
    }
}
