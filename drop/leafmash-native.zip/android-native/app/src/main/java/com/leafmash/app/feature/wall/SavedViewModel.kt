package com.leafmash.app.feature.wall

import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.leafmash.app.core.data.Post
import com.leafmash.app.core.data.UserRepository
import com.leafmash.app.feature.wall.data.Bookmark
import com.leafmash.app.feature.wall.data.BookmarkRepository
import com.leafmash.app.feature.wall.data.PostActions
import com.leafmash.app.feature.wall.data.PostRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn

@HiltViewModel
class SavedViewModel @Inject constructor(
    bookmarks: BookmarkRepository,
    private val posts: PostRepository,
    actions: PostActions,
    userRepository: UserRepository,
    auth: FirebaseAuth
) : PostActionsViewModel(actions, userRepository, auth) {

    val bookmarkList: StateFlow<List<Bookmark>?> = bookmarks.observe()
        .map<List<Bookmark>, List<Bookmark>?> { it }
        .catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val savedPosts: StateFlow<List<Post>?> = bookmarkList
        .filterNotNull()
        .map { list -> list.filter { it.type == "post" && it.postId.isNotEmpty() }.map { it.postId } }
        .distinctUntilChanged()
        .flatMapLatest { ids ->
            if (ids.isEmpty()) {
                flowOf(emptyList<Post>())
            } else {
                combine(ids.map { id -> posts.observePost(id).catch { emit(null) } }) { array ->
                    array.filterNotNull()
                }
            }
        }
        .onEach { list -> ensureUsers(list.map { it.authorUid }) }
        .map<List<Post>, List<Post>?> { it }
        .catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
}
