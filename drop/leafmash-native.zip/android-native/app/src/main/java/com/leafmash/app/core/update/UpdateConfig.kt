package com.leafmash.app.core.update

import com.google.firebase.firestore.DocumentSnapshot

data class UpdateConfig(
    val minVersionCode: Long,
    val latestVersionCode: Long,
    val apkUrl: String,
    val changelog: String
)

enum class UpdateKind { NONE, OPTIONAL, FORCED }

fun DocumentSnapshot.toUpdateConfig(): UpdateConfig? {
    if (!exists()) return null
    val min = getDouble("minVersionCode")?.toLong() ?: 0L
    val latest = getDouble("latestVersionCode")?.toLong() ?: 0L
    return UpdateConfig(
        minVersionCode = min,
        latestVersionCode = latest,
        apkUrl = getString("apkUrl").orEmpty(),
        changelog = getString("changelog").orEmpty()
    )
}

fun UpdateConfig.kindFor(currentVersionCode: Int): UpdateKind = when {
    apkUrl.isBlank() -> UpdateKind.NONE
    minVersionCode > currentVersionCode -> UpdateKind.FORCED
    latestVersionCode > currentVersionCode -> UpdateKind.OPTIONAL
    else -> UpdateKind.NONE
}
