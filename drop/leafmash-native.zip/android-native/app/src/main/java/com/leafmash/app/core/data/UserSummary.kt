package com.leafmash.app.core.data

import com.google.firebase.firestore.DocumentSnapshot
import com.leafmash.app.core.config.AppConfig

data class UserSummary(
    val uid: String,
    val name: String,
    val email: String,
    val photoUrl: String,
    val verified: Boolean
)

val UserSummary.badge: ProfileBadge
    get() = when {
        AppConfig.isAdminEmail(email) -> ProfileBadge.ADMIN
        AppConfig.isOfficialVerifiedEmail(email) || verified -> ProfileBadge.VERIFIED
        else -> ProfileBadge.NONE
    }

val UserSummary.displayName: String
    get() = when {
        AppConfig.isAdminEmail(email) -> AppConfig.ADMIN_DISPLAY_NAME
        AppConfig.isOfficialVerifiedEmail(email) -> AppConfig.VERIFIED_DISPLAY_NAME
        else -> name.ifBlank { "Classmate" }
    }

fun UserProfile.toSummary(): UserSummary = UserSummary(
    uid = uid,
    name = name,
    email = email,
    photoUrl = photoUrl,
    verified = verified
)

fun DocumentSnapshot.toUserSummary(): UserSummary = UserSummary(
    uid = id,
    name = getString("name").orEmpty(),
    email = getString("email").orEmpty(),
    photoUrl = getString("photoURL").orEmpty(),
    verified = getBoolean("verified") == true
)

fun authorFallbackFor(uid: String): UserSummary = UserSummary(uid, "", "", "", false)
