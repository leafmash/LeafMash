package com.leafmash.app.feature.messages.voice

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import java.io.File
import java.io.IOException

class VoiceRecorder(private val context: Context) {

    private var recorder: MediaRecorder? = null
    private var file: File? = null
    private var startedAtMs = 0L

    val isRecording: Boolean get() = recorder != null

    fun start(): Boolean {
        stopQuietly()
        val directory = File(context.cacheDir, "voice").apply { mkdirs() }
        val target = File(directory, "rec-${System.currentTimeMillis()}.m4a")
        val instance = createRecorder()
        return try {
            instance.setAudioSource(MediaRecorder.AudioSource.MIC)
            instance.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            instance.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            instance.setAudioEncodingBitRate(BIT_RATE)
            instance.setAudioSamplingRate(SAMPLE_RATE)
            instance.setOutputFile(target.absolutePath)
            instance.prepare()
            instance.start()
            recorder = instance
            file = target
            startedAtMs = System.currentTimeMillis()
            true
        } catch (e: IOException) {
            release(instance)
            target.delete()
            false
        } catch (e: IllegalStateException) {
            release(instance)
            target.delete()
            false
        } catch (e: RuntimeException) {
            release(instance)
            target.delete()
            false
        }
    }

    fun amplitude(): Int = try {
        recorder?.maxAmplitude ?: 0
    } catch (e: IllegalStateException) {
        0
    }

    fun elapsedMs(): Long = if (recorder == null) 0L else System.currentTimeMillis() - startedAtMs

    fun finish(): Recording? {
        val active = recorder ?: return null
        val output = file
        val durationMs = elapsedMs()
        recorder = null
        file = null
        val stopped = try {
            active.stop()
            true
        } catch (e: RuntimeException) {
            false
        } finally {
            release(active)
        }
        if (!stopped || output == null || !output.exists() || output.length() <= 0L) {
            output?.delete()
            return null
        }
        return Recording(output, ((durationMs + 500L) / 1000L).toInt().coerceIn(1, MAX_SECONDS))
    }

    fun cancel() {
        val output = file
        stopQuietly()
        output?.delete()
    }

    private fun stopQuietly() {
        val active = recorder ?: return
        recorder = null
        file = null
        try {
            active.stop()
        } catch (e: RuntimeException) {
            Unit
        } finally {
            release(active)
        }
    }

    private fun release(instance: MediaRecorder) {
        try {
            instance.release()
        } catch (e: RuntimeException) {
            Unit
        }
    }

    @Suppress("DEPRECATION")
    private fun createRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(context) else MediaRecorder()

    data class Recording(val file: File, val durationSec: Int)

    companion object {
        const val MAX_SECONDS = 60
        private const val BIT_RATE = 64_000
        private const val SAMPLE_RATE = 44_100
    }
}
