package com.leafmash.app.feature.routine

import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.leafmash.app.core.notify.ActivityLogger
import com.leafmash.app.core.notify.PushTrigger
import com.leafmash.app.core.util.retryWithBackoff
import com.leafmash.app.core.util.snapshotFlow
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

data class RoutineSlot(val time: String, val subject: String, val room: String)

val RoutineDays = listOf("Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday")

private const val UPDATE_TEXT = "The weekly class routine was updated."

@Singleton
class RoutineRepository @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val activity: ActivityLogger,
    private val push: PushTrigger
) {

    fun observe(): Flow<Map<String, List<RoutineSlot>>?> =
        firestore.collection("routine").document("weekly")
            .snapshotFlow()
            .map { snapshot ->
                if (!snapshot.exists()) {
                    null
                } else {
                    val days = LinkedHashMap<String, List<RoutineSlot>>()
                    RoutineDays.forEach { day ->
                        val raw = snapshot.get(day) as? List<*> ?: return@forEach
                        val slots = raw.mapNotNull { item ->
                            val map = item as? Map<*, *> ?: return@mapNotNull null
                            RoutineSlot(
                                time = map["time"] as? String ?: "",
                                subject = map["subject"] as? String ?: "",
                                room = map["room"] as? String ?: ""
                            )
                        }
                        if (slots.isNotEmpty()) days[day] = slots
                    }
                    days
                }
            }
            .retryWithBackoff()

    suspend fun save(days: Map<String, List<RoutineSlot>>) {
        val payload = HashMap<String, Any>()
        payload["updatedAt"] = FieldValue.serverTimestamp()
        var hasAny = false
        days.forEach { (day, slots) ->
            if (slots.isNotEmpty()) {
                payload[day] = slots.map { mapOf("time" to it.time, "subject" to it.subject, "room" to it.room) }
                hasAny = true
            }
        }
        firestore.collection("routine").document("weekly").set(payload).await()
        if (hasAny) {
            activity.log("routine", UPDATE_TEXT)
            push.send(type = "routine", text = UPDATE_TEXT)
        }
    }
}
