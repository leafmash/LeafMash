package com.leafmash.app.feature.resources

import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leafmash.app.R
import com.leafmash.app.core.auth.AuthRepository
import com.leafmash.app.core.upload.FileUploader
import com.leafmash.app.core.upload.PickedFile
import com.leafmash.app.core.util.UiText
import com.leafmash.app.core.util.safeCall
import com.leafmash.app.core.util.toUiText
import com.leafmash.app.feature.resources.data.Resource
import com.leafmash.app.feature.resources.data.ResourceCategories
import com.leafmash.app.feature.resources.data.ResourceRepository
import com.leafmash.app.feature.wall.data.BookmarkRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

const val SAVED_FILTER = "__saved__"
const val ALL_FILTER = "All"
private const val PAGE_SIZE = 30L

data class ResourcesUiState(
    val loading: Boolean = true,
    val items: List<Resource> = emptyList(),
    val savedIds: Set<String> = emptySet(),
    val savedItems: List<Resource> = emptyList(),
    val canLoadMore: Boolean = false
)

data class ResourceForm(
    val editing: Resource? = null,
    val title: String = "",
    val category: String = ResourceCategories.first(),
    val upload: Boolean = false,
    val link: String = "",
    val file: PickedFile? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class ResourcesViewModel @Inject constructor(
    private val repository: ResourceRepository,
    private val bookmarks: BookmarkRepository,
    private val uploader: FileUploader,
    auth: AuthRepository
) : ViewModel() {

    val myUid: String = auth.currentUid.orEmpty()

    private val eventChannel = Channel<UiText>(Channel.BUFFERED)
    val events: Flow<UiText> = eventChannel.receiveAsFlow()

    private val limit = MutableStateFlow(PAGE_SIZE)

    val state: StateFlow<ResourcesUiState> = combine(
        limit.flatMapLatest { count ->
            repository.observe(count).map { count to it }
        },
        bookmarks.observe().onStart { emit(emptyList()) }
    ) { (count, list), saved ->
        val savedResources = saved.filter { it.type == "resource" }
        ResourcesUiState(
            loading = false,
            items = list,
            savedIds = savedResources.map { it.resourceId }.toSet(),
            savedItems = savedResources.map {
                Resource(
                    id = it.resourceId,
                    title = it.title,
                    category = it.category,
                    link = it.link,
                    sourceType = "link",
                    fileExt = "",
                    contributorName = it.contributorName,
                    contributorUid = "",
                    openCount = 0L,
                    createdAtMs = 0L
                )
            },
            canLoadMore = list.size.toLong() >= count
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ResourcesUiState())

    var query by mutableStateOf("")
        private set

    var filter by mutableStateOf(ALL_FILTER)
        private set

    var form by mutableStateOf<ResourceForm?>(null)
        private set

    var saving by mutableStateOf(false)
        private set

    var formError by mutableStateOf<UiText?>(null)
        private set

    var pendingDelete by mutableStateOf<Resource?>(null)
        private set

    fun updateQuery(value: String) {
        query = value
    }

    fun selectFilter(value: String) {
        filter = value
    }

    fun loadMore() {
        limit.update { it + PAGE_SIZE }
    }

    fun startAdd() {
        form = ResourceForm()
        formError = null
    }

    fun startEdit(item: Resource) {
        form = ResourceForm(
            editing = item,
            title = item.title,
            category = item.category.ifEmpty { ResourceCategories.first() },
            upload = item.sourceType == "upload",
            link = item.link
        )
        formError = null
    }

    fun dismissForm() {
        form = null
        formError = null
    }

    fun change(transform: (ResourceForm) -> ResourceForm) {
        form = form?.let(transform)
    }

    fun pickFile(uri: Uri?) {
        if (uri == null) return
        val picked = uploader.describe(uri)
        if (picked.sizeBytes > 20L * 1024L * 1024L) {
            formError = UiText.Res(R.string.resource_error_too_large)
            return
        }
        formError = null
        change { it.copy(file = picked) }
    }

    fun requestDelete(item: Resource?) {
        pendingDelete = item
    }

    fun toggleSaved(item: Resource) {
        val saved = item.id in state.value.savedIds
        viewModelScope.launch {
            bookmarks.setResourceSaved(
                resourceId = item.id,
                title = item.title,
                category = item.category,
                link = item.link,
                sourceType = item.sourceType,
                fileExt = item.fileExt,
                contributorName = item.contributorName,
                saved = !saved
            ).onFailure { eventChannel.send(it.toUiText()) }
        }
    }

    fun recordOpen(item: Resource) {
        if (item.contributorUid.isEmpty()) return
        viewModelScope.launch { repository.bumpOpenCount(item.id) }
    }

    fun submit() {
        val current = form ?: return
        val title = current.title.trim()
        val editing = current.editing
        if (title.isEmpty()) {
            formError = UiText.Res(R.string.resource_error_title)
            return
        }
        if (editing == null && current.upload && current.file == null) {
            formError = UiText.Res(R.string.resource_error_file)
            return
        }
        if ((!current.upload || editing != null) && current.link.trim().isEmpty()) {
            formError = UiText.Res(R.string.resource_error_link)
            return
        }
        formError = null
        saving = true
        viewModelScope.launch {
            val result = safeCall {
                if (editing != null) {
                    repository.edit(editing.id, title, current.category, current.link.trim())
                } else if (current.upload) {
                    val picked = current.file ?: error("No file")
                    val uploaded = uploader.upload(picked, "leafmash/resources").getOrThrow()
                    repository.create(title, current.category, uploaded.url, "upload", uploaded.ext, uploaded.name)
                } else {
                    repository.create(title, current.category, current.link.trim(), "link", null, null)
                }
            }
            result
                .onSuccess {
                    form = null
                    eventChannel.send(UiText.Res(if (editing == null) R.string.resource_shared else R.string.resource_updated))
                }
                .onFailure { formError = it.toUiText() }
            saving = false
        }
    }

    fun confirmDelete() {
        val target = pendingDelete ?: return
        pendingDelete = null
        viewModelScope.launch {
            safeCall { repository.delete(target.id) }
                .onSuccess { eventChannel.send(UiText.Res(R.string.resource_deleted)) }
                .onFailure { eventChannel.send(it.toUiText()) }
        }
    }
}
