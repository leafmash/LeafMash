package com.leafmash.app.feature.directory

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leafmash.app.core.auth.AuthRepository
import com.leafmash.app.feature.directory.data.Classmate
import com.leafmash.app.feature.directory.data.DirectoryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update

const val YEAR_ALL = "All"
private const val PAGE_SIZE = 60L

data class DirectoryUiState(
    val loading: Boolean = true,
    val all: List<Classmate> = emptyList(),
    val canLoadMore: Boolean = false
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class DirectoryViewModel @Inject constructor(
    repository: DirectoryRepository,
    auth: AuthRepository
) : ViewModel() {

    val myUid: String = auth.currentUid.orEmpty()

    private val limit = MutableStateFlow(PAGE_SIZE)

    val state: StateFlow<DirectoryUiState> = limit
        .flatMapLatest { count ->
            repository.observe(count).map { list ->
                DirectoryUiState(loading = false, all = list, canLoadMore = list.size.toLong() >= count)
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DirectoryUiState())

    private val queryState = MutableStateFlow("")
    private val yearState = MutableStateFlow(YEAR_ALL)

    val query: StateFlow<String> = queryState
    val year: StateFlow<String> = yearState

    fun updateQuery(value: String) {
        queryState.value = value
    }

    fun selectYear(value: String) {
        yearState.value = value
    }

    fun loadMore() {
        limit.update { it + PAGE_SIZE }
    }
}
