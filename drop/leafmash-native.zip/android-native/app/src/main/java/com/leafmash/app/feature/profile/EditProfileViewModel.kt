package com.leafmash.app.feature.profile

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leafmash.app.R
import com.leafmash.app.core.auth.toUiText
import com.leafmash.app.core.config.AppConfig
import com.leafmash.app.core.data.ProfileForm
import com.leafmash.app.core.data.UserProfile
import com.leafmash.app.core.profile.ProfileRepository
import com.leafmash.app.core.upload.ImageProcessor
import com.leafmash.app.core.upload.ImageUploader
import com.leafmash.app.core.util.UiText
import com.leafmash.app.core.util.Validation
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch

@HiltViewModel
class EditProfileViewModel @Inject constructor(
    private val profiles: ProfileRepository,
    private val uploader: ImageUploader,
    private val images: ImageProcessor
) : ViewModel() {

    var form by mutableStateOf(ProfileForm())
        private set

    var photoBytes by mutableStateOf<ByteArray?>(null)
        private set

    var cropSource by mutableStateOf<Bitmap?>(null)
        private set

    var saving by mutableStateOf(false)
        private set

    var uploading by mutableStateOf(false)
        private set

    var error by mutableStateOf<UiText?>(null)
        private set

    val profile: StateFlow<UserProfile?> = profiles.current

    private var startedFor: String? = null

    private val savedChannel = Channel<Unit>(Channel.BUFFERED)
    val saved: Flow<Unit> = savedChannel.receiveAsFlow()

    init {
        profiles.current.value?.let { start(it) }
    }

    fun start(profile: UserProfile) {
        if (startedFor == profile.uid) return
        startedFor = profile.uid
        form = ProfileForm.from(profile)
        photoBytes = null
        cropSource = null
        error = null
        saving = false
        uploading = false
    }

    fun update(transform: (ProfileForm) -> ProfileForm) {
        form = transform(form)
    }

    fun updateSocialLink(index: Int, value: String) {
        update { current ->
            current.copy(socialLinks = current.socialLinks.mapIndexed { i, link -> if (i == index) value else link })
        }
    }

    fun addSocialLink() {
        update { current ->
            if (current.socialLinks.size >= Validation.MAX_SOCIAL_LINKS) current
            else current.copy(socialLinks = current.socialLinks + "")
        }
    }

    fun removeSocialLink(index: Int) {
        update { current ->
            val remaining = current.socialLinks.filterIndexed { i, _ -> i != index }
            current.copy(socialLinks = remaining.ifEmpty { listOf("") })
        }
    }

    fun onPhotoPicked(uri: Uri) {
        viewModelScope.launch {
            val bitmap = images.decode(uri)
            if (bitmap == null) {
                error = UiText.Res(R.string.err_photo_load)
            } else {
                error = null
                cropSource = bitmap
            }
        }
    }

    fun onCropCancelled() {
        cropSource = null
    }

    fun onCropped(bitmap: Bitmap) {
        viewModelScope.launch {
            photoBytes = images.encodeJpeg(bitmap, AVATAR_QUALITY)
            cropSource = null
        }
    }

    fun clearError() {
        error = null
    }

    fun save() {
        if (saving) return
        val previous = profiles.current.value ?: return
        val problem = validate(form)
        if (problem != null) {
            error = problem
            return
        }
        val snapshot = form
        val bytes = photoBytes
        viewModelScope.launch {
            saving = true
            error = null
            var photoUrl: String? = null
            if (bytes != null) {
                uploading = true
                photoUrl = uploader.uploadJpeg(bytes, AppConfig.AVATAR_FOLDER, "avatar.jpg").getOrElse {
                    fail(it)
                    return@launch
                }
                uploading = false
            }
            profiles.update(previous, snapshot, photoUrl)
                .onSuccess {
                    saving = false
                    photoBytes = null
                    startedFor = null
                    savedChannel.send(Unit)
                }
                .onFailure { fail(it) }
        }
    }

    private fun validate(form: ProfileForm): UiText? = when {
        form.name.isBlank() || form.roll.isBlank() || form.blood.isEmpty() ||
            form.gender.isEmpty() || form.phone.isBlank() -> UiText.Res(R.string.err_required_core)
        form.name.trim().length > Validation.MAX_NAME -> UiText.Res(R.string.err_name_too_long)
        !Validation.isPhoneValid(form.phone) -> UiText.Res(R.string.err_invalid_phone)
        form.bio.trim().length > Validation.MAX_BIO -> UiText.Res(R.string.err_bio_too_long)
        form.socialLinks.any { link ->
            val trimmed = link.trim()
            trimmed.isNotEmpty() && !trimmed.startsWith("http://", true) && !trimmed.startsWith("https://", true)
        } -> UiText.Res(R.string.err_social_link_invalid)
        else -> null
    }

    private fun fail(throwable: Throwable) {
        saving = false
        uploading = false
        error = throwable.toUiText()
    }

    private companion object {
        const val AVATAR_QUALITY = 85
    }
}
