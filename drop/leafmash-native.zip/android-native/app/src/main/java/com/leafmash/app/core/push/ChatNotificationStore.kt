package com.leafmash.app.core.push

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import org.json.JSONArray
import org.json.JSONObject

data class StoredMessage(
    val text: String,
    val fromMe: Boolean,
    val senderUid: String,
    val senderName: String,
    val timestamp: Long
)

@Singleton
class ChatNotificationStore @Inject constructor(
    @ApplicationContext context: Context
) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    @Synchronized
    fun addMessage(chatKey: String, message: StoredMessage) {
        val array = JSONArray(prefs.getString(messagesKey(chatKey), null) ?: "[]")
        array.put(
            JSONObject().apply {
                put("text", message.text)
                put("fromMe", message.fromMe)
                put("senderUid", message.senderUid)
                put("senderName", message.senderName)
                put("timestamp", message.timestamp)
            }
        )
        val start = maxOf(0, array.length() - MAX_MESSAGES)
        val trimmed = JSONArray()
        for (index in start until array.length()) trimmed.put(array.getJSONObject(index))
        prefs.edit().putString(messagesKey(chatKey), trimmed.toString()).apply()
    }

    @Synchronized
    fun messages(chatKey: String): List<StoredMessage> {
        val array = JSONArray(prefs.getString(messagesKey(chatKey), null) ?: "[]")
        val result = ArrayList<StoredMessage>(array.length())
        for (index in 0 until array.length()) {
            val item = array.getJSONObject(index)
            result.add(
                StoredMessage(
                    text = item.optString("text"),
                    fromMe = item.optBoolean("fromMe"),
                    senderUid = item.optString("senderUid"),
                    senderName = item.optString("senderName"),
                    timestamp = item.optLong("timestamp")
                )
            )
        }
        return result
    }

    @Synchronized
    fun setPhoto(senderUid: String, url: String) {
        prefs.edit().putString("photo:$senderUid", url).apply()
    }

    @Synchronized
    fun photo(senderUid: String): String = prefs.getString("photo:$senderUid", "").orEmpty()

    @Synchronized
    fun setTitle(chatKey: String, title: String) {
        prefs.edit().putString("title:$chatKey", title).apply()
    }

    @Synchronized
    fun title(chatKey: String): String = prefs.getString("title:$chatKey", "").orEmpty()

    @Synchronized
    fun incrementUnread(chatKey: String): Int {
        val next = prefs.getInt("unread:$chatKey", 0) + 1
        prefs.edit().putInt("unread:$chatKey", next).apply()
        return next
    }

    @Synchronized
    fun unread(chatKey: String): Int = prefs.getInt("unread:$chatKey", 0)

    @Synchronized
    fun resetUnread(chatKey: String) {
        prefs.edit().remove("unread:$chatKey").apply()
    }

    @Synchronized
    fun clear(chatKey: String) {
        prefs.edit()
            .remove(messagesKey(chatKey))
            .remove("title:$chatKey")
            .remove("unread:$chatKey")
            .apply()
    }

    @Synchronized
    fun markSeen(messageId: String): Boolean {
        val array = JSONArray(prefs.getString(SEEN_KEY, null) ?: "[]")
        for (index in 0 until array.length()) {
            if (array.optString(index) == messageId) return false
        }
        array.put(messageId)
        val start = maxOf(0, array.length() - MAX_SEEN)
        val trimmed = JSONArray()
        for (index in start until array.length()) trimmed.put(array.getString(index))
        prefs.edit().putString(SEEN_KEY, trimmed.toString()).apply()
        return true
    }

    @Synchronized
    fun clearAll() {
        prefs.edit().clear().apply()
    }

    private fun messagesKey(chatKey: String) = "messages:$chatKey"

    private companion object {
        const val PREFS_NAME = "leafmash_push_chats"
        const val SEEN_KEY = "seen_message_ids"
        const val MAX_MESSAGES = 30
        const val MAX_SEEN = 80
    }
}
