package com.leafmash.app.feature.wall

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import android.net.Uri
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.leafmash.app.R
import com.leafmash.app.core.data.MentionRef
import com.leafmash.app.core.data.UserRepository
import com.leafmash.app.core.data.UserSummary
import com.leafmash.app.core.notify.ActivityLogger
import com.leafmash.app.core.notify.PushTrigger
import com.leafmash.app.core.util.UiText
import com.leafmash.app.core.util.safeCall
import com.leafmash.app.core.util.toUiText
import com.leafmash.app.feature.wall.data.PostImageUploader
import com.leafmash.app.feature.wall.data.PostPublisher
import com.leafmash.app.feature.wall.data.PostRepository
import com.leafmash.app.ui.components.MentionInputState
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch

sealed interface ComposerImage {
    data class Remote(val url: String) : ComposerImage
    data class Local(val uri: Uri) : ComposerImage
}

@HiltViewModel
class ComposerViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val posts: PostRepository,
    private val publisher: PostPublisher,
    private val imageUploader: PostImageUploader,
    private val activity: ActivityLogger,
    private val push: PushTrigger,
    private val userRepository: UserRepository,
    private val auth: FirebaseAuth
) : ViewModel() {

    private val postId: String? = savedStateHandle.get<String>("postId")?.takeIf { it.isNotEmpty() }

    val editing: Boolean = postId != null

    val input = MentionInputState(POST_LIMIT)

    var images by mutableStateOf<List<ComposerImage>>(emptyList())
        private set

    var pollEnabled by mutableStateOf(false)
        private set

    val pollOptions = mutableStateListOf("", "")

    var loading by mutableStateOf(editing)
        private set

    var loadFailed by mutableStateOf(false)
        private set

    var submitting by mutableStateOf(false)
        private set

    var error by mutableStateOf<UiText?>(null)
        private set

    val students: StateFlow<List<UserSummary>> = userRepository.students

    val users: StateFlow<Map<String, UserSummary>> = userRepository.users

    val myUid: String get() = auth.currentUser?.uid.orEmpty()

    private val doneChannel = Channel<Unit>(Channel.BUFFERED)
    val done: Flow<Unit> = doneChannel.receiveAsFlow()

    private var originalMentions: List<MentionRef> = emptyList()

    init {
        userRepository.ensure(listOf(myUid))
        if (postId != null) loadForEdit(postId)
    }

    private fun loadForEdit(id: String) {
        viewModelScope.launch {
            posts.getPost(id)
                .onSuccess { post ->
                    if (post == null || post.authorUid != myUid) {
                        loadFailed = true
                        error = UiText.Res(R.string.composer_cannot_edit)
                    } else {
                        input.setContent(post.text, post.mentions)
                        originalMentions = post.mentions
                        images = post.images.map { ComposerImage.Remote(it) }
                    }
                }
                .onFailure {
                    loadFailed = true
                    error = it.toUiText()
                }
            loading = false
        }
    }

    fun loadStudents() {
        viewModelScope.launch { safeCall { userRepository.loadStudents() } }
    }

    fun addImages(uris: List<Uri>) {
        val remaining = MAX_IMAGES - images.size
        if (remaining <= 0 || uris.isEmpty()) return
        images = images + uris.take(remaining).map { ComposerImage.Local(it) }
        error = if (uris.size > remaining) UiText.Res(R.string.composer_max_photos) else null
    }

    fun removeImage(index: Int) {
        images = images.filterIndexed { i, _ -> i != index }
    }

    fun togglePoll() {
        pollEnabled = !pollEnabled
    }

    fun setPollOption(index: Int, text: String) {
        if (index in pollOptions.indices && text.length <= POLL_OPTION_LIMIT) pollOptions[index] = text
    }

    fun addPollOption() {
        if (pollOptions.size < MAX_POLL_OPTIONS) pollOptions.add("")
    }

    fun removePollOption(index: Int) {
        if (pollOptions.size > MIN_POLL_OPTIONS && index in pollOptions.indices) pollOptions.removeAt(index)
    }

    fun submit() {
        if (submitting || loading || loadFailed) return
        val text = input.text.trim()
        if (text.isEmpty()) {
            error = UiText.Res(R.string.composer_empty)
            return
        }
        val mentions = input.mentions()
        if (postId != null) {
            submitEdit(postId, text, mentions)
            return
        }
        val options = if (pollEnabled) pollOptions.map { it.trim() }.filter { it.isNotEmpty() } else emptyList()
        if (pollEnabled && options.size < MIN_POLL_OPTIONS) {
            error = UiText.Res(R.string.composer_poll_min)
            return
        }
        val uris = images.filterIsInstance<ComposerImage.Local>().map { it.uri }
        publisher.submit(text, mentions, options, uris)
        doneChannel.trySend(Unit)
    }

    private fun submitEdit(id: String, text: String, mentions: List<MentionRef>) {
        submitting = true
        error = null
        viewModelScope.launch {
            val local = images.filterIsInstance<ComposerImage.Local>().map { it.uri }
            val uploaded = imageUploader.upload(local).getOrElse {
                error = it.toUiText()
                submitting = false
                return@launch
            }
            val kept = images.filterIsInstance<ComposerImage.Remote>().map { it.url }
            posts.editPost(id, text, kept + uploaded, mentions)
                .onSuccess {
                    val me = myUid
                    mentions
                        .filter { mention -> mention.uid != me && originalMentions.none { it.uid == mention.uid } }
                        .forEach { mention ->
                            activity.log("mention", text, mention.uid, id)
                            push.send("mention", text, mention.uid, id)
                        }
                    doneChannel.trySend(Unit)
                }
                .onFailure { error = it.toUiText() }
            submitting = false
        }
    }

    companion object {
        const val POST_LIMIT = 3000
        const val MAX_IMAGES = 6
        const val MIN_POLL_OPTIONS = 2
        const val MAX_POLL_OPTIONS = 6
        const val POLL_OPTION_LIMIT = 80
    }
}
