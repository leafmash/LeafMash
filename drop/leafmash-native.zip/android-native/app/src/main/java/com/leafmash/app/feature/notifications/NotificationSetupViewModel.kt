package com.leafmash.app.feature.notifications

import androidx.lifecycle.ViewModel
import com.leafmash.app.core.settings.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class NotificationSetupViewModel @Inject constructor(
    private val settings: SettingsRepository
) : ViewModel() {

    suspend fun rationaleShown(): Boolean = settings.isNotificationRationaleShown()

    suspend fun markRationaleShown() = settings.setNotificationRationaleShown()

    suspend fun batteryPrompted(): Boolean = settings.isBatteryPrompted()

    suspend fun markBatteryPrompted() = settings.setBatteryPrompted()

    suspend fun autostartPrompted(): Boolean = settings.isAutostartPrompted()

    suspend fun markAutostartPrompted() = settings.setAutostartPrompted()
}
