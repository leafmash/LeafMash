package com.leafmash.app.core.notify

import com.google.firebase.auth.FirebaseAuth
import com.leafmash.app.core.network.ApiClient
import com.leafmash.app.core.network.ApiException
import com.leafmash.app.core.profile.ProfileRepository
import com.leafmash.app.core.util.AppScope
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

@Singleton
class PushTrigger @Inject constructor(
    private val api: ApiClient,
    private val auth: FirebaseAuth,
    private val profiles: ProfileRepository,
    private val appScope: AppScope
) {

    fun send(
        type: String,
        text: String = "",
        targetUid: String? = null,
        postId: String? = null,
        commentId: String? = null,
        reportId: String? = null
    ) {
        if (auth.currentUser == null) return
        val actorName = profiles.current.value?.name.orEmpty()
        val payload = buildJsonObject {
            put("type", type)
            put("text", text)
            put("actorName", actorName)
            if (targetUid != null) put("targetUid", targetUid)
            if (postId != null) put("postId", postId)
            if (commentId != null) put("commentId", commentId)
            if (reportId != null) put("reportId", reportId)
        }
        appScope.scope.launch {
            for (attempt in 0..RETRY_DELAYS_MS.size) {
                val error = api.call("send-push", payload, skipClientCooldown = true).exceptionOrNull() ?: return@launch
                val status = (error as? ApiException)?.statusCode
                val retryable = status == null || status == 429 || status >= 500
                if (!retryable) return@launch
                if (attempt < RETRY_DELAYS_MS.size) delay(RETRY_DELAYS_MS[attempt])
            }
        }
    }

    private companion object {
        val RETRY_DELAYS_MS = longArrayOf(2_000L, 5_000L, 10_000L)
    }
}
