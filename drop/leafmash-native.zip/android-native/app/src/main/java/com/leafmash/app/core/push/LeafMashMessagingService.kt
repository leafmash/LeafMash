package com.leafmash.app.core.push

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull

@AndroidEntryPoint
class LeafMashMessagingService : FirebaseMessagingService() {

    @Inject
    lateinit var dispatcher: NotificationDispatcher

    @Inject
    lateinit var tokens: PushTokenRepository

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        runBlocking(Dispatchers.IO) {
            withTimeoutOrNull(WORK_TIMEOUT_MS) { tokens.register(token) }
        }
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        val data = message.data
        if (data.isEmpty()) return
        runBlocking(Dispatchers.IO) {
            withTimeoutOrNull(WORK_TIMEOUT_MS) { dispatcher.handle(data) }
        }
    }

    private companion object {
        const val WORK_TIMEOUT_MS = 15_000L
    }
}
