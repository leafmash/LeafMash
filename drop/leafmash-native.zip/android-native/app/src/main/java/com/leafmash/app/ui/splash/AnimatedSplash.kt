package com.leafmash.app.ui.splash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.leafmash.app.R
import com.leafmash.app.ui.components.LeafIcons
import com.leafmash.app.ui.components.LightStatusBarIcons
import com.leafmash.app.ui.theme.LeafPalette
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val INTRO_MILLIS = 1500L
private val LeafSize = 96.dp
private val StageSize = 300.dp
private val Mint = Color(0xFF6FD69B)
private val LeafFill = Brush.linearGradient(
    colors = listOf(Color(0xFF9BE8BC), Color(0xFF3FA66F)),
    start = Offset(4f, 20f),
    end = Offset(20f, 4f)
)

@Composable
fun AnimatedSplash(
    showLoader: Boolean,
    onIntroFinished: () -> Unit,
    modifier: Modifier = Modifier
) {
    LightStatusBarIcons()
    val finished by rememberUpdatedState(onIntroFinished)
    val glow = remember { Animatable(0f) }
    val leafAlpha = remember { Animatable(0f) }
    val leafScale = remember { Animatable(0.82f) }
    val leafTilt = remember { Animatable(-14f) }
    val ripple = remember { Animatable(0f) }
    val shine = remember { Animatable(0f) }
    val first = remember { Animatable(0f) }
    val second = remember { Animatable(0f) }
    val tagline = remember { Animatable(0f) }
    val pulse = rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulseValue"
    )
    val loaderAlpha by animateFloatAsState(
        targetValue = if (showLoader) 1f else 0f,
        animationSpec = tween(400),
        label = "loaderAlpha"
    )

    LaunchedEffect(Unit) {
        launch { glow.animateTo(1f, tween(900, easing = FastOutSlowInEasing)) }
        launch { leafAlpha.animateTo(1f, tween(220)) }
        launch { leafScale.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessLow)) }
        launch { leafTilt.animateTo(0f, spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessLow)) }
        launch {
            delay(260)
            ripple.animateTo(1f, tween(1100, easing = FastOutSlowInEasing))
        }
        launch {
            delay(560)
            shine.animateTo(1f, tween(750, easing = FastOutSlowInEasing))
        }
        launch {
            delay(520)
            first.animateTo(1f, tween(520, easing = FastOutSlowInEasing))
        }
        launch {
            delay(640)
            second.animateTo(1f, tween(520, easing = FastOutSlowInEasing))
        }
        launch {
            delay(900)
            tagline.animateTo(1f, tween(520, easing = FastOutSlowInEasing))
        }
        delay(INTRO_MILLIS)
        finished()
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.radialGradient(listOf(LeafPalette.Forest900, LeafPalette.Forest950)))
    ) {
        Canvas(Modifier.size(StageSize).align(Alignment.Center)) {
            val c = center
            val radius = size.minDimension / 2f * pulse.value
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF3FA66F).copy(alpha = 0.38f * glow.value), Color.Transparent),
                    center = c,
                    radius = radius
                ),
                radius = radius,
                center = c
            )
            val rings = listOf(ripple.value, (ripple.value - 0.25f) / 0.75f)
            rings.forEach { progress ->
                if (progress > 0.001f && progress < 0.999f) {
                    drawCircle(
                        color = Mint.copy(alpha = (1f - progress) * 0.4f),
                        radius = LeafSize.toPx() / 2f * (1f + progress * 1.9f),
                        center = c,
                        style = Stroke(width = 2.dp.toPx() * (1f - progress * 0.5f))
                    )
                }
            }
        }
        LeafMark(
            scale = leafScale,
            tilt = leafTilt,
            alpha = leafAlpha,
            shine = shine,
            modifier = Modifier.size(LeafSize).align(Alignment.Center)
        )
        Column(
            modifier = Modifier.align(Alignment.Center).offset(y = 114.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row {
                Text(
                    text = "Leaf",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontSize = 38.sp,
                        letterSpacing = (-0.5).sp
                    ),
                    color = Color.White,
                    modifier = Modifier.rise(first)
                )
                Text(
                    text = "Mash",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontSize = 38.sp,
                        letterSpacing = (-0.5).sp
                    ),
                    color = Mint,
                    modifier = Modifier.rise(second)
                )
            }
            Text(
                text = stringResource(R.string.splash_tagline),
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 0.6.sp
                ),
                color = Color.White.copy(alpha = 0.66f),
                modifier = Modifier.padding(top = 6.dp).rise(tagline)
            )
        }
        LoadingDots(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 48.dp)
                .graphicsLayer { alpha = loaderAlpha }
        )
    }
}

private fun Modifier.rise(progress: State<Float>): Modifier = graphicsLayer {
    alpha = progress.value
    translationY = (1f - progress.value) * 18.dp.toPx()
}

@Composable
private fun LeafMark(
    scale: State<Float>,
    tilt: State<Float>,
    alpha: State<Float>,
    shine: State<Float>,
    modifier: Modifier = Modifier
) {
    val path = remember { LeafIcons.leafPath() }
    Canvas(
        modifier = modifier.graphicsLayer {
            scaleX = scale.value
            scaleY = scale.value
            rotationZ = tilt.value
            this.alpha = alpha.value
        }
    ) {
        val unit = size.minDimension / 24f
        scale(unit, unit, pivot = Offset.Zero) {
            drawPath(path = path, brush = LeafFill)
            clipPath(path) {
                val p = -8f + shine.value * 36f
                drawRect(
                    brush = Brush.linearGradient(
                        colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.6f), Color.Transparent),
                        start = Offset(p, 24f - p),
                        end = Offset(p + 7f, 24f - p - 7f)
                    )
                )
            }
        }
    }
}

@Composable
private fun LoadingDots(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "dots")
    Row(modifier = modifier, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        repeat(3) { index ->
            val level = transition.animateFloat(
                initialValue = 0.25f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(600, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse,
                    initialStartOffset = StartOffset(index * 160)
                ),
                label = "dot$index"
            )
            Box(
                Modifier
                    .size(7.dp)
                    .graphicsLayer {
                        alpha = level.value
                        scaleX = 0.7f + 0.3f * level.value
                        scaleY = 0.7f + 0.3f * level.value
                    }
                    .background(Mint, CircleShape)
            )
        }
    }
}
