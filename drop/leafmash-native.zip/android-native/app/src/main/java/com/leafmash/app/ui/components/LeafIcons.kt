package com.leafmash.app.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.unit.dp

object LeafIcons {
    private const val LEAF_PATH =
        "M20 4c-8 0-16 4-16 13 0 1.5.3 2.6.8 3.4C6 15 11 9 18 6c-6 4-10 10-12.4 13.7.5.2 1 .3 1.4.3C16 20 20 12 20 4z"

    val Filled: ImageVector = ImageVector.Builder(
        name = "LeafFilled",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).addPath(
        pathData = addPathNodes(LEAF_PATH),
        fill = SolidColor(Color.Black)
    ).build()

    val Outline: ImageVector = ImageVector.Builder(
        name = "LeafOutline",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).addPath(
        pathData = addPathNodes(LEAF_PATH),
        stroke = SolidColor(Color.Black),
        strokeLineWidth = 2f,
        strokeLineJoin = StrokeJoin.Round
    ).build()
}
