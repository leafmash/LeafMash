package com.leafmash.app.feature.wall.data

import com.google.firebase.auth.FirebaseAuth
import com.leafmash.app.core.data.Comment
import com.leafmash.app.core.data.Post
import com.leafmash.app.core.network.ApiException
import com.leafmash.app.core.notify.ActivityLogger
import com.leafmash.app.core.notify.PushTrigger
import com.leafmash.app.core.profile.ProfileRepository
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PostActions @Inject constructor(
    private val posts: PostRepository,
    private val bookmarks: BookmarkRepository,
    private val activity: ActivityLogger,
    private val push: PushTrigger,
    private val auth: FirebaseAuth,
    private val profiles: ProfileRepository
) {

    private fun uidOrNull(): String? = auth.currentUser?.uid

    private fun notSignedIn(): Result<Unit> = Result.failure(ApiException("You're not signed in."))

    suspend fun reactToPost(post: Post, emoji: String?): Result<Unit> {
        val uid = uidOrNull() ?: return notSignedIn()
        val current = post.reactions[uid]
        val next = if (emoji != null && emoji != current) emoji else null
        return posts.setPostReaction(post.id, uid, next).onSuccess {
            if (next != null && current == null && post.authorUid.isNotEmpty() && post.authorUid != uid) {
                activity.log("like", targetUid = post.authorUid, postId = post.id)
                push.send("like", targetUid = post.authorUid, postId = post.id)
            }
        }
    }

    suspend fun reactToComment(postId: String, comment: Comment, emoji: String?): Result<Unit> {
        val uid = uidOrNull() ?: return notSignedIn()
        val current = comment.reactions[uid]
        val next = if (emoji != null && emoji != current) emoji else null
        return posts.setCommentReaction(postId, comment.id, uid, next).onSuccess {
            if (next != null && current == null && comment.authorUid.isNotEmpty() && comment.authorUid != uid) {
                activity.log("comment-like", comment.text, comment.authorUid, postId)
                push.send("comment-like", comment.text, comment.authorUid, postId, comment.id)
            }
        }
    }

    suspend fun vote(post: Post, optionId: String): Result<Unit> {
        val uid = uidOrNull() ?: return notSignedIn()
        val current = post.poll?.votes?.get(uid)
        val next = if (current == optionId) null else optionId
        return posts.setPollVote(post.id, uid, next)
    }

    suspend fun setPinned(post: Post, pinned: Boolean): Result<Unit> = posts.setPinned(post.id, pinned)

    suspend fun delete(postId: String): Result<Unit> = posts.deletePost(postId).onSuccess {
        activity.deleteForPost(postId)
    }

    suspend fun report(post: Post, reason: String): Result<Unit> {
        val uid = uidOrNull() ?: return notSignedIn()
        val reporter = profiles.current.value?.name?.ifBlank { null } ?: "A classmate"
        return posts.addReport(post.id, post.authorUid, post.text, reason.trim(), uid, reporter).map { reportId ->
            push.send("report", reason.trim(), reportId = reportId)
        }
    }

    suspend fun setSaved(postId: String, saved: Boolean): Result<Unit> = bookmarks.setPostSaved(postId, saved)
}
