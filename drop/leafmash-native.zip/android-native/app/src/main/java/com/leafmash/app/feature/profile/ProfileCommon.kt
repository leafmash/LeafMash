package com.leafmash.app.feature.profile

import android.content.Intent
import android.net.Uri
import android.text.format.DateUtils
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.leafmash.app.R
import com.leafmash.app.core.data.Post
import com.leafmash.app.core.data.ProfileBadge
import com.leafmash.app.core.data.UserProfile
import com.leafmash.app.core.data.UserSummary
import com.leafmash.app.core.data.authorFallback
import com.leafmash.app.core.data.badge
import com.leafmash.app.core.data.displayName
import com.leafmash.app.feature.resources.data.Resource
import com.leafmash.app.feature.wall.PostCard
import com.leafmash.app.feature.wall.PostActionsViewModel
import com.leafmash.app.feature.wall.postCallbacks
import com.leafmash.app.ui.components.LeafCard
import com.leafmash.app.ui.components.ProfileBadgeIcon
import com.leafmash.app.ui.components.SkeletonPost
import com.leafmash.app.ui.components.UserAvatar
import com.leafmash.app.ui.components.rememberTimeAgo
import com.leafmash.app.ui.theme.LeafPalette

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileHero(profile: UserProfile, showDepartment: Boolean) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 34.dp, bottomEnd = 34.dp))
            .background(LeafPalette.HeroBrush)
            .padding(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 26.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(112.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                UserAvatar(
                    name = profile.displayName,
                    seed = profile.uid,
                    photoUrl = profile.photoUrl,
                    size = 100.dp,
                    contentDescription = stringResource(R.string.profile_photo_cd)
                )
            }
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = profile.displayName,
                    style = MaterialTheme.typography.headlineSmall,
                    color = Color.White,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                ProfileBadgeIcon(profile.badge, modifier = Modifier.padding(start = 6.dp), size = 22.dp)
            }
            Spacer(Modifier.height(10.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (showDepartment) HeroChip(stringResource(R.string.profile_department))
                if (profile.session.isNotBlank()) HeroChip(profile.session)
                if (profile.badge == ProfileBadge.ADMIN) HeroChip(stringResource(R.string.profile_admin_chip))
            }
            if (profile.bio.isNotBlank()) {
                Spacer(Modifier.height(12.dp))
                Text(
                    text = profile.bio,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.85f),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun HeroChip(text: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Color.White.copy(alpha = 0.16f))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(text = text, style = MaterialTheme.typography.labelMedium, color = Color.White)
    }
}

@Composable
fun ProfileStatRow(profile: UserProfile, modifier: Modifier = Modifier) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        StatCard(profile.roll.ifBlank { "—" }, stringResource(R.string.profile_stat_roll), Modifier.weight(1f))
        StatCard(profile.bloodGroup.ifBlank { "—" }, stringResource(R.string.profile_stat_blood), Modifier.weight(1f))
        StatCard(
            profile.year.ifBlank { profile.session.ifBlank { "—" } },
            stringResource(R.string.profile_stat_year),
            Modifier.weight(1f)
        )
    }
}

@Composable
private fun StatCard(value: String, label: String, modifier: Modifier = Modifier) {
    LeafCard(modifier = modifier, shape = RoundedCornerShape(18.dp)) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun ProfileTabPills(
    labels: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
    ) {
        labels.forEachIndexed { index, label ->
            val active = index == selected
            Box(
                modifier = Modifier
                    .weight(1f, fill = false)
                    .clip(RoundedCornerShape(50))
                    .then(
                        if (active) Modifier.background(LeafPalette.ButtonBrush)
                        else Modifier.background(MaterialTheme.colorScheme.surfaceContainer)
                    )
                    .clickable { onSelect(index) }
                    .padding(horizontal = 20.dp, vertical = 9.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = if (active) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun ProfileInfoCard(profile: UserProfile, self: Boolean, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current
    val notSet = stringResource(R.string.profile_not_set)
    val hidden = stringResource(R.string.profile_hidden)
    val gender = when (profile.gender) {
        "male" -> stringResource(R.string.gender_male)
        "female" -> stringResource(R.string.gender_female)
        "other" -> stringResource(R.string.gender_other)
        else -> notSet
    }
    val rows = buildList<Pair<String, String>> {
        add(stringResource(R.string.profile_label_roll) to profile.roll.ifBlank { notSet })
        add(stringResource(R.string.profile_label_year) to profile.year.ifBlank { notSet })
        add(stringResource(R.string.profile_label_session) to profile.session.ifBlank { notSet })
        add(stringResource(R.string.profile_label_blood) to profile.bloodGroup.ifBlank { notSet })
        add(stringResource(R.string.profile_label_gender) to gender)
        add(stringResource(R.string.profile_label_hometown) to profile.hometown.ifBlank { notSet })
        add(stringResource(R.string.profile_label_address) to profile.address.ifBlank { notSet })
    }
    val joined = if (profile.createdAtMs > 0L) {
        DateUtils.formatDateTime(
            context,
            profile.createdAtMs,
            DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_YEAR
        )
    } else null
    val phoneValue = when {
        self -> profile.phone.ifBlank { notSet } + if (profile.hidePhone) " · $hidden" else ""
        profile.hidePhone -> hidden
        else -> profile.phone
    }
    val emailValue = when {
        self -> profile.email.ifBlank { notSet } + if (profile.hideEmail) " · $hidden" else ""
        profile.hideEmail -> hidden
        else -> profile.email.ifBlank { notSet }
    }
    LeafCard(modifier = modifier.fillMaxWidth()) {
        Column(Modifier.padding(vertical = 4.dp)) {
            rows.forEach { (label, value) -> InfoRow(label, value) }
            if (profile.socialLinks.isEmpty()) {
                if (self) InfoRow(stringResource(R.string.profile_label_social), notSet)
            } else {
                profile.socialLinks.forEach { link ->
                    InfoRow(
                        label = stringResource(R.string.profile_label_social),
                        value = link,
                        onClick = { runCatching { uriHandler.openUri(link) } }
                    )
                }
            }
            if (self || profile.hidePhone || profile.phone.isNotBlank()) {
                InfoRow(stringResource(R.string.profile_label_phone), phoneValue)
            }
            InfoRow(stringResource(R.string.profile_label_email), emailValue)
            InfoRow(stringResource(R.string.profile_label_college), stringResource(R.string.profile_college_name))
            if (joined != null) InfoRow(stringResource(R.string.profile_label_joined), joined)
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String, onClick: (() -> Unit)? = null) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(0.4f)
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium,
                color = if (onClick != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.End,
                modifier = Modifier.weight(0.6f)
            )
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
    }
}

@Composable
fun ProfileMessage(text: String) {
    Text(
        text = text,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp)
    )
}

fun LazyListScope.profilePostItems(
    posts: List<Post>?,
    users: Map<String, UserSummary>,
    savedIds: Set<String>,
    myUid: String,
    isAdmin: Boolean,
    viewModel: PostActionsViewModel,
    emptyText: String,
    onOpenPost: (String, Boolean) -> Unit,
    onEditPost: (String) -> Unit,
    onOpenHashtag: (String) -> Unit,
    onViewReactions: (Post) -> Unit
) {
    if (posts == null) {
        item(key = "posts_loading") {
            Column { repeat(2) { SkeletonPost() } }
        }
        return
    }
    if (posts.isEmpty()) {
        item(key = "posts_empty") { ProfileMessage(emptyText) }
        return
    }
    items(posts.size, key = { "post_${posts[it].id}" }) { index ->
        val post = posts[index]
        val saved = post.id in savedIds
        PostCard(
            post = post,
            author = users[post.authorUid] ?: post.authorFallback(),
            commentCount = post.commentCount,
            saved = saved,
            myUid = myUid,
            isAdmin = isAdmin,
            callbacks = postCallbacks(
                viewModel = viewModel,
                post = post,
                saved = saved,
                onOpenPost = onOpenPost,
                onEditPost = onEditPost,
                onOpenHashtag = onOpenHashtag,
                onViewReactions = onViewReactions
            )
        )
    }
}

fun LazyListScope.profileNoteItems(
    notes: List<Resource>?,
    emptyText: String
) {
    if (notes == null) {
        item(key = "notes_loading") { Column { repeat(2) { SkeletonPost() } } }
        return
    }
    if (notes.isEmpty()) {
        item(key = "notes_empty") { ProfileMessage(emptyText) }
        return
    }
    items(notes.size, key = { "note_${notes[it].id}" }) { index ->
        ProfileNoteCard(notes[index])
    }
}

@Composable
private fun ProfileNoteCard(item: Resource) {
    val context = LocalContext.current
    val isUpload = item.sourceType == "upload"
    val openLink: (() -> Unit)? = if (item.link.startsWith("http")) {
        val action: () -> Unit = {
            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.link))) }
        }
        action
    } else {
        null
    }
    com.leafmash.app.ui.components.FlatItem(
        modifier = Modifier.fillMaxWidth(),
        onClick = openLink
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                val badge = if (isUpload && item.fileExt.isNotEmpty()) item.fileExt.take(4).uppercase() else "LINK"
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer)
                        .padding(horizontal = 9.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = badge,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                Spacer(Modifier.size(10.dp))
                Text(
                    text = item.category,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(item.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            val parts = ArrayList<String>()
            if (item.createdAtMs > 0L) parts.add(rememberTimeAgo(item.createdAtMs))
            if (item.openCount > 0L) {
                parts.add(stringResource(if (isUpload) R.string.resource_downloads else R.string.resource_views, item.openCount))
            }
            if (parts.isNotEmpty()) {
                Text(
                    text = parts.joinToString(" · "),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            Text(
                text = stringResource(if (isUpload) R.string.resource_download else R.string.resource_open),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}
