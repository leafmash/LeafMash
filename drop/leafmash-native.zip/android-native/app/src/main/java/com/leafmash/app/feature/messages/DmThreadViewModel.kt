package com.leafmash.app.feature.messages

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.leafmash.app.R
import com.leafmash.app.core.auth.AuthRepository
import com.leafmash.app.core.data.UserRepository
import com.leafmash.app.core.data.UserSummary
import com.leafmash.app.core.data.authorFallbackFor
import com.leafmash.app.core.util.UiText
import com.leafmash.app.core.util.safeCall
import com.leafmash.app.core.util.toUiText
import com.leafmash.app.feature.messages.data.ChatMessage
import com.leafmash.app.feature.messages.data.ChatTarget
import com.leafmash.app.feature.messages.data.Conversation
import com.leafmash.app.feature.messages.data.MessageSender
import com.leafmash.app.feature.messages.data.MessagesRepository
import com.leafmash.app.feature.messages.data.PendingStatus
import com.leafmash.app.feature.messages.data.toChatMessage
import com.leafmash.app.feature.messages.voice.VoicePlayer
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DmUiState(
    val loading: Boolean = true,
    val other: UserSummary,
    val messages: List<ChatMessage> = emptyList(),
    val otherReadAtMs: Long = 0L,
    val iBlocked: Boolean = false,
    val blockedMe: Boolean = false,
    val otherTyping: Boolean = false,
    val lastActiveMs: Long = 0L
)

@HiltViewModel
class DmThreadViewModel @Inject constructor(
    @ApplicationContext context: Context,
    savedStateHandle: SavedStateHandle,
    private val repository: MessagesRepository,
    private val sender: MessageSender,
    private val userRepository: UserRepository,
    auth: AuthRepository,
    player: VoicePlayer
) : ChatViewModelBase(player) {

    val myUid: String = auth.currentUid.orEmpty()
    val otherUid: String = savedStateHandle.get<String>("uid").orEmpty()
    private val conversationId = repository.conversationId(myUid, otherUid)
    private val target = ChatTarget.Dm(otherUid)

    private val eventChannel = Channel<UiText>(Channel.BUFFERED)
    val events: Flow<UiText> = eventChannel.receiveAsFlow()

    val recorder = newRecorderController(context, viewModelScope, sender, target, eventChannel)

    var text by mutableStateOf("")
        private set

    private var typingJob: Job? = null
    private var lastTypingSentAt = 0L

    private val ticker: Flow<Long> = flow {
        while (true) {
            emit(System.currentTimeMillis())
            delay(TYPING_TICK_MS)
        }
    }

    private val conversation: Flow<Conversation?> = repository.conversation(conversationId).onStart { emit(null) }

    val state: StateFlow<DmUiState> = combine(
        conversation,
        repository.dmMessages(conversationId),
        sender.pending,
        userRepository.users,
        repository.lastActive(listOf(otherUid)).onStart { emit(emptyMap()) }
    ) { conv, remote, pending, users, active ->
        val remoteIds = remote.map { it.id }.toSet()
        val local = pending
            .filter { it.target == target }
            .filterNot { it.status == PendingStatus.SENT && it.realId != null && it.realId in remoteIds }
            .map { it.toChatMessage(myUid) }
        DmUiState(
            loading = false,
            other = users[otherUid] ?: authorFallbackFor(otherUid),
            messages = (remote + local).sortedByDescending { it.createdAtMs },
            otherReadAtMs = conv?.lastReadAtMs?.get(otherUid) ?: 0L,
            iBlocked = conv?.blockedBy?.contains(myUid) == true,
            blockedMe = conv?.blockedBy?.contains(otherUid) == true,
            otherTyping = (conv?.typingMs?.get(otherUid) ?: 0L) + TYPING_WINDOW_MS > System.currentTimeMillis(),
            lastActiveMs = active[otherUid] ?: 0L
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DmUiState(other = authorFallbackFor(otherUid)))

    val typingNow: StateFlow<Boolean> = combine(state, ticker) { current, now ->
        current.otherTyping && now > 0L
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    init {
        userRepository.ensure(listOf(otherUid))
        viewModelScope.launch {
            safeCall { repository.ensureConversation(otherUid) }
            conversation.collect { conv ->
                if (conv != null && conv.isUnreadFor(myUid)) {
                    safeCall { repository.markDmRead(conversationId) }
                }
            }
        }
    }

    fun onTextChange(value: String) {
        text = value.take(MessageSender.DM_TEXT_LIMIT)
        if (value.isEmpty()) {
            stopTyping()
            return
        }
        val now = System.currentTimeMillis()
        if (now - lastTypingSentAt > TYPING_SEND_GAP_MS) {
            lastTypingSentAt = now
            viewModelScope.launch { safeCall { repository.setTyping(conversationId, true) } }
        }
        typingJob?.cancel()
        typingJob = viewModelScope.launch {
            delay(TYPING_IDLE_MS)
            stopTyping()
        }
    }

    private fun stopTyping() {
        typingJob?.cancel()
        lastTypingSentAt = 0L
        viewModelScope.launch { safeCall { repository.setTyping(conversationId, false) } }
    }

    fun submit() {
        val clean = text.trim()
        if (clean.isEmpty()) return
        text = ""
        stopTyping()
        sender.sendText(target, clean)
    }

    fun delete(message: ChatMessage) {
        if (message.pending || message.failed) {
            sender.discard(message.id)
            return
        }
        viewModelScope.launch {
            safeCall { repository.deleteDmMessage(conversationId, message.id) }
                .onFailure { eventChannel.send(it.toUiText()) }
        }
    }

    fun setBlocked(blocked: Boolean) {
        viewModelScope.launch {
            safeCall { repository.setBlocked(otherUid, blocked) }
                .onSuccess {
                    eventChannel.send(UiText.Res(if (blocked) R.string.chat_blocked_done else R.string.chat_unblocked_done))
                }
                .onFailure { eventChannel.send(it.toUiText()) }
        }
    }

    fun retry(id: String) = sender.retry(id)

    fun permissionDenied() {
        eventChannel.trySend(UiText.Res(R.string.chat_mic_denied))
    }

    override fun onCleared() {
        recorder.release()
        super.onCleared()
    }

    private companion object {
        const val TYPING_TICK_MS = 2_000L
        const val TYPING_WINDOW_MS = 6_000L
        const val TYPING_SEND_GAP_MS = 2_500L
        const val TYPING_IDLE_MS = 3_000L
    }
}
