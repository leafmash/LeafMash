package com.leafmash.app.feature.profile

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.leafmash.app.ui.components.SecureScreenEffect
import androidx.compose.ui.window.DialogProperties
import com.leafmash.app.R
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private const val MIN_ZOOM = 1f
private const val MAX_ZOOM = 4f
private const val OUTPUT_SIZE = 640

private fun clampOffset(offset: Offset, zoom: Float, viewport: Float, imageWidth: Int, imageHeight: Int): Offset {
    val base = viewport / min(imageWidth, imageHeight)
    val maxX = max(0f, (imageWidth * base * zoom - viewport) / 2f)
    val maxY = max(0f, (imageHeight * base * zoom - viewport) / 2f)
    return Offset(offset.x.coerceIn(-maxX, maxX), offset.y.coerceIn(-maxY, maxY))
}

private fun cropBitmap(source: Bitmap, offset: Offset, zoom: Float, viewport: Float): Bitmap {
    val base = viewport / min(source.width, source.height)
    val scale = base * zoom
    val side = (viewport / scale).roundToInt().coerceIn(1, min(source.width, source.height))
    val centerX = source.width / 2f - offset.x / scale
    val centerY = source.height / 2f - offset.y / scale
    val left = (centerX - side / 2f).roundToInt().coerceIn(0, source.width - side)
    val top = (centerY - side / 2f).roundToInt().coerceIn(0, source.height - side)
    val cropped = Bitmap.createBitmap(source, left, top, side, side)
    return Bitmap.createScaledBitmap(cropped, OUTPUT_SIZE, OUTPUT_SIZE, true)
}

@Composable
fun AvatarCropperDialog(
    source: Bitmap,
    onCancel: () -> Unit,
    onConfirm: (Bitmap) -> Unit
) {
    Dialog(
        onDismissRequest = onCancel,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.surface
        ) {
            SecureScreenEffect()
            CropperContent(source = source, onCancel = onCancel, onConfirm = onConfirm)
        }
    }
}

@Composable
private fun CropperContent(
    source: Bitmap,
    onCancel: () -> Unit,
    onConfirm: (Bitmap) -> Unit
) {
    var zoom by remember { mutableFloatStateOf(MIN_ZOOM) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var viewportPx by remember { mutableFloatStateOf(0f) }
    val image = remember(source) { source.asImageBitmap() }
    val scrim = MaterialTheme.colorScheme.scrim.copy(alpha = 0.6f)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onCancel) { Text(stringResource(R.string.action_cancel)) }
            Text(
                text = stringResource(R.string.crop_title),
                style = MaterialTheme.typography.titleMedium
            )
            Button(
                onClick = { onConfirm(cropBitmap(source, offset, zoom, viewportPx)) },
                enabled = viewportPx > 0f
            ) {
                Text(stringResource(R.string.crop_use_photo))
            }
        }

        BoxWithConstraints(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            val side = if (maxWidth < maxHeight) maxWidth else maxHeight
            Canvas(
                modifier = Modifier
                    .size(side)
                    .clipToBounds()
                    .onSizeChanged { viewportPx = it.width.toFloat() }
                    .pointerInput(source) {
                        detectTransformGestures { _, pan, gestureZoom, _ ->
                            val viewport = size.width.toFloat()
                            val newZoom = (zoom * gestureZoom).coerceIn(MIN_ZOOM, MAX_ZOOM)
                            zoom = newZoom
                            offset = clampOffset(offset + pan, newZoom, viewport, source.width, source.height)
                        }
                    }
            ) {
                val viewport = size.width
                val base = viewport / min(source.width, source.height)
                val displayWidth = source.width * base * zoom
                val displayHeight = source.height * base * zoom
                val left = (viewport - displayWidth) / 2f + offset.x
                val top = (viewport - displayHeight) / 2f + offset.y
                drawImage(
                    image = image,
                    dstOffset = IntOffset(left.roundToInt(), top.roundToInt()),
                    dstSize = IntSize(displayWidth.roundToInt(), displayHeight.roundToInt())
                )
                val mask = Path().apply {
                    fillType = PathFillType.EvenOdd
                    addRect(Rect(Offset.Zero, size))
                    addOval(Rect(Offset.Zero, size))
                }
                drawPath(mask, scrim)
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 8.dp)
        ) {
            Slider(
                value = zoom,
                onValueChange = { value ->
                    zoom = value
                    offset = clampOffset(offset, value, viewportPx, source.width, source.height)
                },
                valueRange = MIN_ZOOM..MAX_ZOOM
            )
            Text(
                text = stringResource(R.string.crop_hint),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
