package com.leafmash.app.feature.deadlines

import com.leafmash.app.ui.components.FlatItem
import androidx.compose.material.icons.filled.Event
import com.leafmash.app.ui.components.LeafCard
import com.leafmash.app.ui.components.EmptyCard
import androidx.compose.ui.unit.sp
import androidx.compose.ui.draw.clip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.background
import com.leafmash.app.ui.components.LeafTopAppBar
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leafmash.app.R
import com.leafmash.app.ui.components.CollectSnackbars
import com.leafmash.app.ui.components.DropdownField
import com.leafmash.app.ui.components.DropdownOption
import com.leafmash.app.ui.components.rememberTimeAgo
import java.text.DateFormat
import java.util.Calendar
import java.util.Date
import java.util.TimeZone

private fun dayStart(ms: Long): Long {
    val c = Calendar.getInstance()
    c.timeInMillis = ms
    c.set(Calendar.HOUR_OF_DAY, 0)
    c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0)
    c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

private fun dayDiff(dueMs: Long): Int {
    val diff = dayStart(dueMs) - dayStart(System.currentTimeMillis())
    return Math.round(diff / 86_400_000.0).toInt()
}

private fun formatDue(ms: Long): String =
    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(ms))

private fun typeLabel(type: String): Int = when (type) {
    "Assignment" -> R.string.deadline_type_assignment
    "Quiz" -> R.string.deadline_type_quiz
    "Exam" -> R.string.deadline_type_exam
    else -> R.string.deadline_type_other
}

@Composable
private fun dueText(dueMs: Long): String {
    val context = LocalContext.current
    val diff = dayDiff(dueMs)
    return when {
        diff < 0 -> context.resources.getQuantityString(R.plurals.deadline_overdue_days, -diff, -diff)
        diff == 0 -> stringResource(R.string.deadline_due_today)
        diff == 1 -> stringResource(R.string.deadline_due_tomorrow)
        else -> context.resources.getQuantityString(R.plurals.deadline_due_in_days, diff, diff)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeadlinesScreen(
    onBack: () -> Unit,
    viewModel: DeadlinesViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val isAdmin by viewModel.isAdmin.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var showPast by remember { mutableStateOf(false) }
    val now = System.currentTimeMillis()
    val upcoming = state.items.filter { it.dueAtMs >= now }.sortedBy { it.dueAtMs }
    val past = state.items.filter { it.dueAtMs < now }.sortedByDescending { it.dueAtMs }
    val shown = if (showPast) past else upcoming

    CollectSnackbars(viewModel.events, snackbar)

    Scaffold(
        topBar = {
            LeafTopAppBar(
                title = { Text(stringResource(R.string.deadlines_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        },
        floatingActionButton = {
            if (isAdmin) {
                FloatingActionButton(
                    onClick = viewModel::startAdd,
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Icon(Icons.Filled.Add, contentDescription = stringResource(R.string.deadline_add))
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { inner ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(inner)
        ) {
            val chipColors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primary,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
            )
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
            ) {
                FilterChip(
                    selected = !showPast,
                    onClick = { showPast = false },
                    shape = RoundedCornerShape(50),
                    colors = chipColors,
                    label = { Text(stringResource(R.string.deadlines_upcoming, upcoming.size)) }
                )
                FilterChip(
                    selected = showPast,
                    onClick = { showPast = true },
                    shape = RoundedCornerShape(50),
                    colors = chipColors,
                    label = { Text(stringResource(R.string.deadlines_past, past.size)) }
                )
            }
            Box(modifier = Modifier.fillMaxSize()) {
                when {
                    state.loading -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                    shown.isEmpty() -> EmptyCard(
                        title = stringResource(if (showPast) R.string.deadlines_empty_past else R.string.deadlines_empty),
                        icon = Icons.Filled.Event,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(24.dp)
                    )
                    else -> LazyColumn(
                        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 0.dp, bottom = 20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(shown, key = { it.id }) { item ->
                            DeadlineRow(item, overdue = showPast) { viewModel.select(item) }
                        }
                    }
                }
            }
        }
    }

    viewModel.selected?.let { item ->
        DeadlineDetailDialog(
            item = item,
            isAdmin = isAdmin,
            onDismiss = { viewModel.select(null) },
            onEdit = { viewModel.startEdit(item) },
            onDelete = {
                viewModel.select(null)
                viewModel.requestDelete(item)
            }
        )
    }

    viewModel.form?.let { form ->
        DeadlineFormDialog(viewModel, form)
    }

    viewModel.pendingDelete?.let {
        AlertDialog(
            onDismissRequest = { viewModel.requestDelete(null) },
            title = { Text(stringResource(R.string.deadline_delete_title)) },
            text = { Text(stringResource(R.string.deadline_delete_text)) },
            confirmButton = {
                TextButton(onClick = viewModel::confirmDelete) { Text(stringResource(R.string.action_delete)) }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.requestDelete(null) }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
}

@Composable
private fun DeadlineRow(item: Deadline, overdue: Boolean, onClick: () -> Unit) {
    val isPast = item.dueAtMs < System.currentTimeMillis()
    FlatItem(
        modifier = Modifier.fillMaxWidth(),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(typeLabel(item.type)).uppercase(),
                    style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.sp),
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.height(2.dp))
                Text(item.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                val meta = if (item.course.isEmpty()) formatDue(item.dueAtMs) else item.course + " · " + formatDue(item.dueAtMs)
                Text(
                    text = meta,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
            Spacer(Modifier.width(10.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(
                        if (isPast) MaterialTheme.colorScheme.errorContainer
                        else MaterialTheme.colorScheme.primaryContainer
                    )
                    .padding(horizontal = 12.dp, vertical = 7.dp)
            ) {
                Text(
                    text = dueText(item.dueAtMs),
                    style = MaterialTheme.typography.labelMedium,
                    color = if (isPast) MaterialTheme.colorScheme.onErrorContainer
                    else MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }
    }
}

@Composable
private fun DeadlineDetailDialog(
    item: Deadline,
    isAdmin: Boolean,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(item.title) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                Text(
                    stringResource(typeLabel(item.type)) + if (item.course.isEmpty()) "" else " · " + item.course,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(formatDue(item.dueAtMs) + " — " + dueText(item.dueAtMs), fontWeight = FontWeight.Medium)
                if (item.notes.isNotEmpty()) Text(item.notes)
                val ago = rememberTimeAgo(item.createdAtMs)
                Text(
                    text = stringResource(R.string.deadline_posted_by, item.postedByName.ifEmpty { "Admin" }, ago),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            if (isAdmin) {
                Row {
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Filled.Edit, contentDescription = stringResource(R.string.deadline_edit))
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.action_delete))
                    }
                }
            } else {
                TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_close)) }
            }
        },
        dismissButton = {
            if (isAdmin) TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_close)) }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DeadlineFormDialog(viewModel: DeadlinesViewModel, form: DeadlineForm) {
    val context = LocalContext.current
    var pickDate by remember { mutableStateOf(false) }
    var pickTime by remember { mutableStateOf(false) }
    var pickedDay by remember { mutableStateOf<Long?>(null) }
    val labeled = DeadlineTypes.map { DropdownOption(it, context.getString(typeLabel(it))) }

    AlertDialog(
        onDismissRequest = { if (!viewModel.saving) viewModel.dismissForm() },
        title = {
            Text(stringResource(if (form.editing == null) R.string.deadline_add else R.string.deadline_edit))
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = form.title,
                    onValueChange = { v -> viewModel.change { it.copy(title = v.take(200)) } },
                    label = { Text(stringResource(R.string.deadline_field_title)) },
                    modifier = Modifier.fillMaxWidth()
                )
                DropdownField(
                    label = stringResource(R.string.deadline_field_type),
                    selectedValue = form.type,
                    options = labeled,
                    onSelect = { v -> viewModel.change { it.copy(type = v) } }
                )
                OutlinedTextField(
                    value = form.course,
                    onValueChange = { v -> viewModel.change { it.copy(course = v) } },
                    label = { Text(stringResource(R.string.deadline_field_course)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedButton(onClick = { pickDate = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(form.dueAtMs?.let { formatDue(it) } ?: stringResource(R.string.deadline_pick_due))
                }
                OutlinedTextField(
                    value = form.notes,
                    onValueChange = { v -> viewModel.change { it.copy(notes = v.take(1000)) } },
                    label = { Text(stringResource(R.string.deadline_field_notes)) },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                viewModel.formError?.let {
                    Text(it.resolve(context), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                }
            }
        },
        confirmButton = {
            Button(onClick = viewModel::submit, enabled = !viewModel.saving) {
                Text(
                    stringResource(
                        when {
                            viewModel.saving -> R.string.edit_saving
                            form.editing == null -> R.string.deadline_add_confirm
                            else -> R.string.deadline_save_confirm
                        }
                    )
                )
            }
        },
        dismissButton = {
            TextButton(onClick = viewModel::dismissForm, enabled = !viewModel.saving) {
                Text(stringResource(R.string.action_cancel))
            }
        }
    )

    if (pickDate) {
        val initial = form.dueAtMs ?: System.currentTimeMillis()
        val utcMidnight = remember(initial) {
            val local = Calendar.getInstance()
            local.timeInMillis = initial
            val utc = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
            utc.clear()
            utc.set(local.get(Calendar.YEAR), local.get(Calendar.MONTH), local.get(Calendar.DAY_OF_MONTH))
            utc.timeInMillis
        }
        val dateState = rememberDatePickerState(initialSelectedDateMillis = utcMidnight)
        DatePickerDialog(
            onDismissRequest = { pickDate = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        val picked = dateState.selectedDateMillis
                        pickDate = false
                        if (picked != null) {
                            pickedDay = picked
                            pickTime = true
                        }
                    }
                ) { Text(stringResource(R.string.action_next)) }
            },
            dismissButton = {
                TextButton(onClick = { pickDate = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        ) {
            DatePicker(state = dateState)
        }
    }

    if (pickTime) {
        val base = Calendar.getInstance()
        base.timeInMillis = form.dueAtMs ?: System.currentTimeMillis()
        val timeState = rememberTimePickerState(
            initialHour = base.get(Calendar.HOUR_OF_DAY),
            initialMinute = base.get(Calendar.MINUTE),
            is24Hour = false
        )
        AlertDialog(
            onDismissRequest = { pickTime = false },
            title = { Text(stringResource(R.string.deadline_pick_time)) },
            text = {
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    TimePicker(state = timeState)
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val day = pickedDay
                        pickTime = false
                        if (day != null) {
                            val utc = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
                            utc.timeInMillis = day
                            val local = Calendar.getInstance()
                            local.clear()
                            local.set(
                                utc.get(Calendar.YEAR),
                                utc.get(Calendar.MONTH),
                                utc.get(Calendar.DAY_OF_MONTH),
                                timeState.hour,
                                timeState.minute
                            )
                            val result = local.timeInMillis
                            viewModel.change { it.copy(dueAtMs = result) }
                        }
                    }
                ) { Text(stringResource(R.string.action_ok)) }
            },
            dismissButton = {
                TextButton(onClick = { pickTime = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
}
