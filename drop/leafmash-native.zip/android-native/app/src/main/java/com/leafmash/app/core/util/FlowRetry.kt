package com.leafmash.app.core.util

import kotlin.math.min
import kotlin.random.Random
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.retryWhen

fun <T> Flow<T>.retryWithBackoff(baseDelayMs: Long = 1_000L, maxDelayMs: Long = 30_000L): Flow<T> =
    retryWhen { _, attempt ->
        val exponent = min(attempt, 10L).toInt()
        val cap = min(maxDelayMs, baseDelayMs shl exponent)
        delay(Random.nextLong(baseDelayMs, cap + 1))
        true
    }
