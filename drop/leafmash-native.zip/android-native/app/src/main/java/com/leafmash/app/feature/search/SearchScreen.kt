package com.leafmash.app.feature.search

import com.leafmash.app.ui.components.LeafTopAppBar
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leafmash.app.R
import com.leafmash.app.feature.directory.data.badge
import com.leafmash.app.feature.directory.data.displayName
import com.leafmash.app.ui.components.ProfileBadgeIcon
import com.leafmash.app.ui.components.UserAvatar
import com.leafmash.app.ui.components.rememberTimeAgo

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    onBack: () -> Unit,
    onOpenPost: (String) -> Unit,
    onOpenProfile: (String) -> Unit,
    onOpenResources: () -> Unit,
    onOpenNotices: () -> Unit,
    onOpenDeadlines: () -> Unit,
    viewModel: SearchViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val recent by viewModel.recent.collectAsStateWithLifecycle()
    val focus = remember { FocusRequester() }

    LaunchedEffect(Unit) { focus.requestFocus() }

    val opened: (() -> Unit) -> () -> Unit = { action ->
        {
            viewModel.remember(viewModel.query)
            action()
        }
    }

    Scaffold(
        topBar = {
            LeafTopAppBar(
                title = {
                    OutlinedTextField(
                        value = viewModel.query,
                        onValueChange = viewModel::updateQuery,
                        placeholder = { Text(stringResource(R.string.search_hint)) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { viewModel.remember(viewModel.query) }),
                        trailingIcon = {
                            if (viewModel.query.isNotEmpty()) {
                                IconButton(onClick = { viewModel.updateQuery("") }) {
                                    Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.search_clear))
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(focus)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { inner ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(inner)
        ) {
            val results = state.results
            when {
                state.failed -> Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(32.dp)
                ) {
                    Text(stringResource(R.string.search_failed), textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = viewModel::load) { Text(stringResource(R.string.action_retry)) }
                }
                state.loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                viewModel.query.isBlank() -> RecentList(
                    recent = recent,
                    onPick = viewModel::useRecent,
                    onClear = viewModel::clearRecent
                )
                state.term.isNotEmpty() && results.total == 0 -> Text(
                    text = stringResource(R.string.search_no_results, state.term),
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(32.dp)
                )
                else -> LazyColumn(
                    contentPadding = PaddingValues(bottom = 24.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    if (results.posts.isNotEmpty()) {
                        item(key = "t_posts") { SectionTitle(stringResource(R.string.search_section_posts)) }
                        items(results.posts.size, key = { "p_" + results.posts[it].id }) { index ->
                            val post = results.posts[index]
                            ResultRow(
                                title = post.authorName.ifBlank { stringResource(R.string.search_someone) },
                                subtitle = post.text.take(100) + " · " + rememberTimeAgo(post.createdAtMs),
                                onClick = opened { onOpenPost(post.id) }
                            )
                        }
                    }
                    if (results.resources.isNotEmpty()) {
                        item(key = "t_res") { SectionTitle(stringResource(R.string.search_section_resources)) }
                        items(results.resources.size, key = { "r_" + results.resources[it].id }) { index ->
                            val resource = results.resources[index]
                            ResultRow(
                                title = resource.title,
                                subtitle = resource.category + " · " +
                                    stringResource(R.string.resource_shared_by, resource.contributorName.ifBlank { "—" }),
                                onClick = opened { onOpenResources() }
                            )
                        }
                    }
                    if (results.notices.isNotEmpty()) {
                        item(key = "t_notice") { SectionTitle(stringResource(R.string.search_section_notices)) }
                        items(results.notices.size, key = { "n_" + results.notices[it].id }) { index ->
                            val notice = results.notices[index]
                            ResultRow(
                                title = notice.text.take(60),
                                subtitle = rememberTimeAgo(notice.createdAtMs),
                                onClick = opened { onOpenNotices() }
                            )
                        }
                    }
                    if (results.deadlines.isNotEmpty()) {
                        item(key = "t_dl") { SectionTitle(stringResource(R.string.search_section_deadlines)) }
                        items(results.deadlines.size, key = { "d_" + results.deadlines[it].id }) { index ->
                            val deadline = results.deadlines[index]
                            ResultRow(
                                title = deadline.title,
                                subtitle = listOf(deadline.type, deadline.course).filter { it.isNotBlank() }.joinToString(" · "),
                                onClick = opened { onOpenDeadlines() }
                            )
                        }
                    }
                    if (results.classmates.isNotEmpty()) {
                        item(key = "t_people") { SectionTitle(stringResource(R.string.search_section_people)) }
                        items(results.classmates.size, key = { "c_" + results.classmates[it].uid }) { index ->
                            val classmate = results.classmates[index]
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable(onClick = opened { onOpenProfile(classmate.uid) })
                                    .padding(horizontal = 16.dp, vertical = 10.dp)
                            ) {
                                UserAvatar(
                                    name = classmate.displayName(),
                                    seed = classmate.uid,
                                    photoUrl = classmate.photoUrl,
                                    size = 40.dp,
                                    badge = classmate.badge()
                                )
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = classmate.displayName(),
                                            style = MaterialTheme.typography.titleSmall,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f, fill = false)
                                        )
                                        ProfileBadgeIcon(classmate.badge(), Modifier.padding(start = 4.dp), 16.dp)
                                    }
                                    Text(
                                        text = listOf(classmate.roll.ifBlank { "—" }, classmate.year)
                                            .filter { it.isNotBlank() }
                                            .joinToString(" · "),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 4.dp)
    )
}

@Composable
private fun ResultRow(title: String, subtitle: String, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Text(title, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (subtitle.isNotBlank()) {
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
        HorizontalDivider(
            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
            modifier = Modifier.padding(top = 10.dp)
        )
    }
}

@Composable
private fun RecentList(recent: List<String>, onPick: (String) -> Unit, onClear: () -> Unit) {
    if (recent.isEmpty()) {
        Box(Modifier.fillMaxSize()) {
            Text(
                text = stringResource(R.string.search_placeholder),
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(32.dp)
            )
        }
        return
    }
    Column(Modifier.fillMaxSize()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 8.dp, top = 8.dp)
        ) {
            Text(
                text = stringResource(R.string.search_recent),
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onClear) { Text(stringResource(R.string.search_clear_recent)) }
        }
        recent.forEach { term ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onPick(term) }
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Icon(Icons.Filled.History, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.width(12.dp))
                Text(term, style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}
