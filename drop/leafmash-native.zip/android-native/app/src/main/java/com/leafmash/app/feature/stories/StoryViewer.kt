package com.leafmash.app.feature.stories

import android.os.SystemClock
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import com.leafmash.app.ui.navigation.LocalOpenProfile
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.ui.draw.scale
import kotlinx.coroutines.delay
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalContext
import coil.imageLoader
import coil.request.ImageRequest
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.leafmash.app.R
import com.leafmash.app.core.data.Story
import com.leafmash.app.core.data.StoryGroup
import com.leafmash.app.core.data.UserSummary
import com.leafmash.app.core.data.authorFallbackFor
import com.leafmash.app.core.data.badge
import com.leafmash.app.core.data.displayName
import com.leafmash.app.ui.components.ProfileBadgeIcon
import com.leafmash.app.ui.components.UserAvatar
import com.leafmash.app.ui.components.rememberTimeAgo

data class StoryViewerRequest(val groups: List<StoryGroup>, val startIndex: Int)

private const val STORY_MILLIS = 5_000f
private const val TAP_MAX_MILLIS = 300L
private const val DISMISS_DRAG = 140f
private const val PREVIOUS_ZONE = 0.33f

@Composable
fun StoryViewer(
    request: StoryViewerRequest,
    liveGroups: List<StoryGroup>,
    myUid: String,
    users: Map<String, UserSummary>,
    onDismiss: () -> Unit,
    onViewed: (Story) -> Unit,
    onEnsureUsers: (Collection<String>) -> Unit,
    onToggleLike: (Story) -> Unit,
    onDelete: (Story) -> Unit
) {
    val groups = request.groups
    if (groups.isEmpty()) {
        LaunchedEffect(Unit) { onDismiss() }
        return
    }
    var groupIndex by remember { mutableIntStateOf(request.startIndex.coerceIn(0, groups.lastIndex)) }
    var storyIndex by remember { mutableIntStateOf(groups[groupIndex].firstUnseenIndex(myUid)) }
    var holding by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var viewersOpen by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val openProfile = LocalOpenProfile.current

    val group = groups[groupIndex]
    val story = group.stories[storyIndex.coerceIn(0, group.stories.lastIndex)]
    val author = users[group.authorUid] ?: authorFallbackFor(group.authorUid)
    val own = group.authorUid == myUid
    val progress = remember(story.id) { mutableStateOf(0f) }
    val timeAgo = rememberTimeAgo(story.createdAtMs)

    val goNext: () -> Unit = {
        if (storyIndex < group.stories.lastIndex) {
            storyIndex += 1
        } else if (groupIndex < groups.lastIndex) {
            groupIndex += 1
            storyIndex = groups[groupIndex].firstUnseenIndex(myUid)
        } else {
            onDismiss()
        }
    }
    val goPrevious: () -> Unit = {
        if (storyIndex > 0) {
            storyIndex -= 1
        } else if (groupIndex > 0) {
            groupIndex -= 1
            storyIndex = 0
        } else {
            progress.value = 0f
        }
    }
    val openAuthor: () -> Unit = {
        val uid = group.authorUid
        onDismiss()
        openProfile(uid)
    }
    val currentNext by rememberUpdatedState(goNext)
    val currentPrevious by rememberUpdatedState(goPrevious)
    var loaded by remember(story.id) { mutableStateOf(false) }
    val paused = holding || confirmDelete || viewersOpen || !loaded
    val chromeAlpha by animateFloatAsState(if (holding) 0f else 1f, label = "storyChrome")
    val viewerUids = remember(story.id, liveGroups) {
        val live = liveGroups.firstNotNullOfOrNull { g -> g.stories.firstOrNull { it.id == story.id } }
        (live?.viewedBy ?: story.viewedBy).toList().asReversed()
    }

    val likedBy = remember(story.id, liveGroups) {
        val live = liveGroups.firstNotNullOfOrNull { g -> g.stories.firstOrNull { it.id == story.id } }
        live?.likedBy ?: story.likedBy
    }
    val liked = myUid in likedBy
    var showBurst by remember { mutableStateOf(false) }
    LaunchedEffect(showBurst) {
        if (showBurst) {
            delay(700)
            showBurst = false
        }
    }

    LaunchedEffect(story.id) { onViewed(story) }

    LaunchedEffect(story.id) {
        val upcoming = when {
            storyIndex < group.stories.lastIndex -> group.stories[storyIndex + 1]
            groupIndex < groups.lastIndex -> groups[groupIndex + 1].let { it.stories[it.firstUnseenIndex(myUid)] }
            else -> null
        }
        if (upcoming != null) {
            context.imageLoader.enqueue(ImageRequest.Builder(context).data(upcoming.imageUrl).build())
        }
    }

    LaunchedEffect(viewerUids) { if (own) onEnsureUsers(viewerUids) }

    LaunchedEffect(story.id, paused) {
        if (paused) return@LaunchedEffect
        var last = withFrameNanos { it }
        while (progress.value < 1f) {
            val now = withFrameNanos { it }
            progress.value = (progress.value + (now - last) / 1_000_000f / STORY_MILLIS).coerceAtMost(1f)
            last = now
        }
        currentNext()
    }

    EdgeToEdgeDialog(onDismissRequest = onDismiss) { safe ->
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AsyncImage(
                model = story.imageUrl,
                contentDescription = stringResource(R.string.story_cd),
                contentScale = ContentScale.Fit,
                onSuccess = { loaded = true },
                onError = { loaded = true },
                modifier = Modifier.fillMaxSize()
            )
            if (!loaded) {
                CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.Center).size(36.dp),
                    strokeWidth = 3.dp,
                    color = Color.White
                )
            }
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .align(Alignment.TopCenter)
                    .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.65f), Color.Transparent)))
            )
            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(story.id) {
                        var pressedAt = 0L
                        detectTapGestures(
                            onPress = {
                                pressedAt = SystemClock.uptimeMillis()
                                holding = true
                                try {
                                    tryAwaitRelease()
                                } finally {
                                    holding = false
                                }
                            },
                            onTap = { offset ->
                                if (SystemClock.uptimeMillis() - pressedAt <= TAP_MAX_MILLIS) {
                                    if (offset.x < size.width * PREVIOUS_ZONE) currentPrevious() else currentNext()
                                }
                            }
                        )
                    }
                    .pointerInput(Unit) {
                        var total = 0f
                        detectVerticalDragGestures(
                            onDragStart = { total = 0f },
                            onDragEnd = {
                                if (total > DISMISS_DRAG) onDismiss()
                                else if (total < -DISMISS_DRAG && own) viewersOpen = true
                            },
                            onVerticalDrag = { _, delta -> total += delta }
                        )
                    }
            )
            Column(
                Modifier
                    .align(Alignment.TopCenter)
                    .alpha(chromeAlpha)
                    .padding(top = safe.calculateTopPadding())
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
                    group.stories.forEachIndexed { index, _ ->
                        StoryBar(
                            fraction = {
                                when {
                                    index < storyIndex -> 1f
                                    index == storyIndex -> progress.value
                                    else -> 0f
                                }
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    UserAvatar(
                        name = author.displayName,
                        seed = author.uid,
                        photoUrl = author.photoUrl,
                        size = 36.dp,
                        modifier = Modifier.clip(CircleShape).clickable(onClick = openAuthor),
                        badge = author.badge
                    )
                    Spacer(Modifier.width(10.dp))
                    Row(
                        Modifier.weight(1f).clip(RoundedCornerShape(8.dp)).clickable(onClick = openAuthor),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = author.displayName,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        ProfileBadgeIcon(author.badge, Modifier.padding(start = 4.dp), 14.dp)
                        Text(
                            text = timeAgo,
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.White.copy(alpha = 0.75f),
                            modifier = Modifier.padding(start = 8.dp)
                        )
                    }
                    if (own) {
                        IconButton(onClick = { confirmDelete = true }) {
                            Icon(
                                imageVector = Icons.Outlined.Delete,
                                contentDescription = stringResource(R.string.story_delete),
                                tint = Color.White
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = stringResource(R.string.action_close),
                            tint = Color.White
                        )
                    }
                }
            }
            AnimatedVisibility(
                visible = showBurst,
                modifier = Modifier.align(Alignment.Center),
                enter = scaleIn(spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)) + fadeIn(),
                exit = scaleOut(targetScale = 1.4f) + fadeOut()
            ) {
                Icon(
                    imageVector = Icons.Filled.Favorite,
                    contentDescription = null,
                    tint = LoveColor,
                    modifier = Modifier.size(112.dp)
                )
            }
            run {
                Column(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .alpha(chromeAlpha)
                        .fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f))))
                        .padding(bottom = safe.calculateBottomPadding())
                        .padding(horizontal = 18.dp, vertical = 20.dp)
                ) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Column(Modifier.weight(1f)) {
                            if (story.caption.isNotBlank()) {
                                Text(
                                    text = story.caption,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = Color.White
                                )
                            }
                            if (own) {
                                if (story.caption.isNotBlank()) Spacer(Modifier.height(14.dp))
                                ViewersPill(viewerUids, likedBy.size, users, onClick = { viewersOpen = true })
                            }
                        }
                        if (!own) {
                            LoveButton(
                                liked = liked,
                                onClick = {
                                    if (!liked) showBurst = true
                                    onToggleLike(story)
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    if (viewersOpen) {
        ViewersSheet(viewerUids, likedBy, users, onDismiss = { viewersOpen = false })
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(stringResource(R.string.story_delete_title)) },
            text = { Text(stringResource(R.string.story_delete_text)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    onDelete(story)
                    currentNext()
                }) {
                    Text(stringResource(R.string.action_delete), color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
}

@Composable
private fun StoryBar(fraction: () -> Float, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .height(3.dp)
            .clip(RoundedCornerShape(50))
            .background(Color.White.copy(alpha = 0.35f))
            .drawBehind {
                drawRoundRect(
                    color = Color.White,
                    size = Size(size.width * fraction().coerceIn(0f, 1f), size.height),
                    cornerRadius = CornerRadius(size.height / 2f)
                )
            }
    )
}

@Composable
private fun ViewersPill(
    viewerUids: List<String>,
    likeCount: Int,
    users: Map<String, UserSummary>,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Color.White.copy(alpha = 0.18f))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Outlined.Visibility,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(18.dp)
        )
        Spacer(Modifier.width(8.dp))
        val shown = viewerUids.take(3)
        if (shown.isNotEmpty()) {
            Box(Modifier.width((AVATAR_STACK_SIZE + (shown.size - 1) * AVATAR_STACK_STEP).dp).height(AVATAR_STACK_SIZE.dp)) {
                shown.forEachIndexed { index, uid ->
                    val user = users[uid] ?: authorFallbackFor(uid)
                    UserAvatar(
                        name = user.displayName,
                        seed = user.uid,
                        photoUrl = user.photoUrl,
                        size = AVATAR_STACK_SIZE.dp,
                        modifier = Modifier.offset(x = (index * AVATAR_STACK_STEP).dp),
                        badge = user.badge
                    )
                }
            }
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text = stringResource(R.string.story_views, viewerUids.size),
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        if (likeCount > 0) {
            Spacer(Modifier.width(10.dp))
            Icon(
                imageVector = Icons.Filled.Favorite,
                contentDescription = null,
                tint = LoveColor,
                modifier = Modifier.size(16.dp)
            )
            Spacer(Modifier.width(4.dp))
            Text(
                text = likeCount.toString(),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
        Icon(
            imageVector = Icons.Filled.KeyboardArrowUp,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.padding(start = 2.dp).size(18.dp)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ViewersSheet(
    viewerUids: List<String>,
    likedBy: Set<String>,
    users: Map<String, UserSummary>,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Text(
            text = stringResource(R.string.story_views, viewerUids.size),
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
        )
        if (viewerUids.isEmpty()) {
            Text(
                text = stringResource(R.string.story_no_views),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)
            )
        }
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            items(viewerUids, key = { it }) { uid ->
                val user = users[uid] ?: authorFallbackFor(uid)
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    UserAvatar(name = user.displayName, seed = user.uid, photoUrl = user.photoUrl, size = 40.dp, badge = user.badge)
                    Spacer(Modifier.width(12.dp))
                    Text(
                        text = user.displayName,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    ProfileBadgeIcon(user.badge, Modifier.padding(start = 4.dp), 16.dp)
                    if (uid in likedBy) {
                        Spacer(Modifier.weight(1f))
                        Icon(
                            imageVector = Icons.Filled.Favorite,
                            contentDescription = null,
                            tint = LoveColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LoveButton(liked: Boolean, onClick: () -> Unit) {
    val scale = remember { Animatable(1f) }
    LaunchedEffect(liked) {
        if (liked) {
            scale.snapTo(0.6f)
            scale.animateTo(1f, spring(dampingRatio = Spring.DampingRatioHighBouncy, stiffness = Spring.StiffnessMedium))
        }
    }
    IconButton(onClick = onClick, modifier = Modifier.size(52.dp)) {
        Icon(
            imageVector = if (liked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
            contentDescription = stringResource(if (liked) R.string.story_unlike else R.string.story_like),
            tint = if (liked) LoveColor else Color.White,
            modifier = Modifier.size(30.dp).scale(scale.value)
        )
    }
}

private val LoveColor = Color(0xFFFF3B5C)

private const val AVATAR_STACK_SIZE = 22
private const val AVATAR_STACK_STEP = 14
