package com.leafmash.app.feature.messages

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewModelScope
import com.leafmash.app.R
import com.leafmash.app.core.auth.AuthRepository
import com.leafmash.app.core.config.AppConfig
import com.leafmash.app.core.data.UserRepository
import com.leafmash.app.core.data.UserSummary
import com.leafmash.app.core.profile.ProfileRepository
import com.leafmash.app.core.util.UiText
import com.leafmash.app.core.util.safeCall
import com.leafmash.app.core.util.toUiText
import com.leafmash.app.feature.messages.data.ChatMessage
import com.leafmash.app.feature.messages.data.ChatTarget
import com.leafmash.app.feature.messages.data.MessageSender
import com.leafmash.app.feature.messages.data.MessagesRepository
import com.leafmash.app.feature.messages.data.PendingStatus
import com.leafmash.app.feature.messages.data.toChatMessage
import com.leafmash.app.feature.messages.voice.VoicePlayer
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ClassChatUiState(
    val loading: Boolean = true,
    val messages: List<ChatMessage> = emptyList()
)

@HiltViewModel
class ClassChatViewModel @Inject constructor(
    @ApplicationContext context: Context,
    private val repository: MessagesRepository,
    private val sender: MessageSender,
    private val userRepository: UserRepository,
    profiles: ProfileRepository,
    auth: AuthRepository,
    player: VoicePlayer
) : ChatViewModelBase(player) {

    val myUid: String = auth.currentUid.orEmpty()

    private val eventChannel = Channel<UiText>(Channel.BUFFERED)
    val events: Flow<UiText> = eventChannel.receiveAsFlow()

    val isAdmin: StateFlow<Boolean> = profiles.current
        .map { AppConfig.isAdminEmail(it?.email) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    val users: StateFlow<Map<String, UserSummary>> = userRepository.users

    val recorder = newRecorderController(context, viewModelScope, sender, ChatTarget.ClassChat, eventChannel)

    var text by mutableStateOf("")
        private set

    var editingId by mutableStateOf<String?>(null)
        private set

    val state: StateFlow<ClassChatUiState> = combine(
        repository.classMessages().onEach { list -> userRepository.ensure(list.map { it.senderUid }) },
        sender.pending
    ) { remote, pending ->
        val remoteIds = remote.map { it.id }.toSet()
        val local = pending
            .filter { it.target == ChatTarget.ClassChat }
            .filterNot { it.status == PendingStatus.SENT && it.realId != null && it.realId in remoteIds }
            .map { it.toChatMessage(myUid) }
        ClassChatUiState(loading = false, messages = (remote + local).sortedByDescending { it.createdAtMs })
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ClassChatUiState())

    init {
        viewModelScope.launch {
            repository.classMessages()
                .map { list -> list.lastOrNull()?.id }
                .distinctUntilChanged()
                .collect { safeCall { repository.markClassChatRead() } }
        }
    }

    fun onTextChange(value: String) {
        text = value.take(MessageSender.CLASS_TEXT_LIMIT)
    }

    fun submit() {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val target = editingId
        text = ""
        editingId = null
        if (target == null) {
            sender.sendText(ChatTarget.ClassChat, clean)
        } else {
            viewModelScope.launch {
                safeCall { repository.editClassMessage(target, clean) }
                    .onFailure { eventChannel.send(it.toUiText()) }
            }
        }
    }

    fun startEdit(message: ChatMessage) {
        editingId = message.id
        text = message.text
    }

    fun cancelEdit() {
        editingId = null
        text = ""
    }

    fun delete(message: ChatMessage) {
        if (message.pending || message.failed) {
            sender.discard(message.id)
            return
        }
        viewModelScope.launch {
            safeCall { repository.deleteClassMessage(message.id) }
                .onFailure { eventChannel.send(it.toUiText()) }
        }
    }

    fun retry(id: String) = sender.retry(id)

    fun permissionDenied() {
        eventChannel.trySend(UiText.Res(R.string.chat_mic_denied))
    }

    override fun onCleared() {
        recorder.release()
        super.onCleared()
    }
}
