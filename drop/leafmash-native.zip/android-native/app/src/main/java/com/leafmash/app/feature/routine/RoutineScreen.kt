package com.leafmash.app.feature.routine

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leafmash.app.R
import com.leafmash.app.ui.components.CollectSnackbars
import com.leafmash.app.ui.components.EmptyCard
import com.leafmash.app.ui.components.GradientButton
import com.leafmash.app.ui.components.LeafCard
import com.leafmash.app.ui.components.LeafTopAppBar
import com.leafmash.app.ui.components.SectionLabel
import com.leafmash.app.ui.theme.LeafPalette
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val TimeSeparator = Regex("\\s*[–—−~-]\\s*|\\s+to\\s+", RegexOption.IGNORE_CASE)

private fun todayName(): String = when (Calendar.getInstance().get(Calendar.DAY_OF_WEEK)) {
    Calendar.SATURDAY -> "Saturday"
    Calendar.SUNDAY -> "Sunday"
    Calendar.MONDAY -> "Monday"
    Calendar.TUESDAY -> "Tuesday"
    Calendar.WEDNESDAY -> "Wednesday"
    Calendar.THURSDAY -> "Thursday"
    else -> "Friday"
}

private fun splitTime(raw: String): Pair<String, String?> {
    val parts = raw.trim().split(TimeSeparator, limit = 2)
    return if (parts.size == 2 && parts[0].isNotBlank() && parts[1].isNotBlank()) {
        parts[0].trim() to parts[1].trim()
    } else {
        raw.trim() to null
    }
}

@Composable
private fun classCountText(count: Int): String =
    if (count == 1) stringResource(R.string.routine_class_one)
    else stringResource(R.string.routine_class_other, count)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoutineScreen(
    onBack: () -> Unit,
    viewModel: RoutineViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val isAdmin by viewModel.isAdmin.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val draft = viewModel.draft

    CollectSnackbars(viewModel.events, snackbar)
    BackHandler(enabled = draft != null) { viewModel.cancelEdit() }

    Scaffold(
        topBar = {
            LeafTopAppBar(
                title = { Text(stringResource(if (draft != null) R.string.routine_edit_title else R.string.routine_title)) },
                navigationIcon = {
                    IconButton(onClick = { if (draft != null) viewModel.cancelEdit() else onBack() }) {
                        Icon(
                            if (draft != null) Icons.Filled.Close else Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.action_back)
                        )
                    }
                },
                actions = {
                    if (isAdmin && draft == null && !state.loading) {
                        IconButton(onClick = viewModel::startEdit) {
                            Icon(Icons.Filled.Edit, contentDescription = stringResource(R.string.routine_edit))
                        }
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
        containerColor = MaterialTheme.colorScheme.background
    ) { inner ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(inner)
        ) {
            when {
                draft != null -> RoutineEditor(viewModel, draft)
                state.loading -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                state.days.isNullOrEmpty() -> EmptyCard(
                    title = stringResource(R.string.routine_empty),
                    icon = Icons.Filled.Edit,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp)
                )
                else -> {
                    val days = state.days.orEmpty()
                    val today = todayName()
                    val others = RoutineDays.filter { it != today && it in days }
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 28.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        item(key = "today") {
                            TodayCard(day = today, slots = days[today].orEmpty())
                        }
                        if (others.isNotEmpty()) {
                            item(key = "week-label") {
                                SectionLabel(stringResource(R.string.routine_this_week))
                            }
                        }
                        items(others, key = { it }) { day ->
                            DayCard(day = day, slots = days.getValue(day))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TodayCard(day: String, slots: List<RoutineSlot>) {
    val shape = RoundedCornerShape(28.dp)
    val dateText = remember { SimpleDateFormat("d MMMM", Locale.getDefault()).format(Date()) }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(12.dp, shape, ambientColor = LeafPalette.Forest800, spotColor = LeafPalette.Forest800)
            .clip(shape)
            .background(LeafPalette.HeroBrush)
            .drawBehind {
                drawCircle(
                    color = Color.White.copy(alpha = 0.07f),
                    radius = size.width * 0.42f,
                    center = Offset(size.width * 0.96f, 0f)
                )
                drawCircle(
                    color = Color.White.copy(alpha = 0.05f),
                    radius = size.width * 0.28f,
                    center = Offset(0f, size.height)
                )
            }
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    TodayBadge()
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = day,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        maxLines = 1
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = if (slots.isEmpty()) dateText else dateText + " · " + classCountText(slots.size),
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.78f),
                        maxLines = 1
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            if (slots.isEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color.White.copy(alpha = 0.12f))
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.EventAvailable,
                        contentDescription = null,
                        tint = LeafPalette.GoldSoft,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        text = stringResource(R.string.routine_no_class_today),
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White
                    )
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    slots.forEachIndexed { index, slot ->
                        SlotRow(
                            slot = slot,
                            accent = LeafPalette.SlotAccentsOnDark[index % LeafPalette.SlotAccentsOnDark.size],
                            onHero = true
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TodayBadge() {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(LeafPalette.GoldSoft)
            .padding(horizontal = 11.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(LeafPalette.Forest900)
        )
        Spacer(Modifier.width(6.dp))
        Text(
            text = stringResource(R.string.routine_today).uppercase(),
            style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.2.sp, fontSize = 11.sp),
            color = LeafPalette.Forest900,
            maxLines = 1
        )
    }
}

@Composable
private fun DayCard(day: String, slots: List<RoutineSlot>) {
    LeafCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = day,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(MaterialTheme.colorScheme.primaryContainer)
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = classCountText(slots.size),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                slots.forEachIndexed { index, slot ->
                    SlotRow(
                        slot = slot,
                        accent = LeafPalette.SlotAccents[index % LeafPalette.SlotAccents.size],
                        onHero = false
                    )
                }
            }
        }
    }
}

@Composable
private fun SlotRow(slot: RoutineSlot, accent: Color, onHero: Boolean) {
    val scheme = MaterialTheme.colorScheme
    val titleColor = if (onHero) Color.White else scheme.onSurface
    val mutedColor = if (onHero) Color.White.copy(alpha = 0.72f) else scheme.onSurfaceVariant
    val container = if (onHero) Color.White.copy(alpha = 0.12f) else scheme.surfaceContainer
    val (start, end) = remember(slot.time) { splitTime(slot.time) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
            .clip(RoundedCornerShape(18.dp))
            .background(container)
    ) {
        Box(
            modifier = Modifier
                .width(5.dp)
                .fillMaxHeight()
                .background(accent)
        )
        Row(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.width(82.dp)) {
                Text(
                    text = start,
                    style = MaterialTheme.typography.labelLarge.copy(fontSize = 14.sp),
                    fontWeight = FontWeight.ExtraBold,
                    color = titleColor,
                    maxLines = 1,
                    softWrap = false
                )
                if (end != null) {
                    Text(
                        text = end,
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                        color = mutedColor,
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = slot.subject,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = titleColor,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
                if (slot.room.isNotEmpty()) {
                    Spacer(Modifier.height(6.dp))
                    RoomChip(room = slot.room, onHero = onHero)
                }
            }
        }
    }
}

@Composable
private fun RoomChip(room: String, onHero: Boolean) {
    val scheme = MaterialTheme.colorScheme
    val background = if (onHero) Color.White.copy(alpha = 0.18f) else scheme.primaryContainer
    val content = if (onHero) Color.White else scheme.onPrimaryContainer
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(background)
            .padding(horizontal = 9.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Filled.Place,
            contentDescription = null,
            tint = content,
            modifier = Modifier.size(12.dp)
        )
        Spacer(Modifier.width(4.dp))
        Text(
            text = room,
            style = MaterialTheme.typography.labelMedium.copy(fontSize = 12.sp),
            color = content,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false)
        )
    }
}

@Composable
private fun RoutineEditor(viewModel: RoutineViewModel, draft: Map<String, List<EditableSlot>>) {
    val context = LocalContext.current
    val fieldShape = RoundedCornerShape(14.dp)
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .imePadding(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = stringResource(R.string.routine_editor_hint),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
        }
        items(RoutineDays, key = { it }) { day ->
            LeafCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = day,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = { viewModel.addSlot(day) }) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(stringResource(R.string.routine_add_class))
                        }
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        draft[day].orEmpty().forEach { slot ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(end = 8.dp)
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(MaterialTheme.colorScheme.surfaceContainer)
                                    .padding(start = 12.dp, top = 8.dp, bottom = 12.dp, end = 4.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = slot.time,
                                        onValueChange = { viewModel.updateSlot(day, slot.key, time = it) },
                                        label = { Text(stringResource(R.string.routine_time)) },
                                        placeholder = { Text("9:00–10:20") },
                                        singleLine = true,
                                        shape = fieldShape,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    OutlinedTextField(
                                        value = slot.subject,
                                        onValueChange = { viewModel.updateSlot(day, slot.key, subject = it) },
                                        label = { Text(stringResource(R.string.routine_subject)) },
                                        singleLine = true,
                                        shape = fieldShape,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    OutlinedTextField(
                                        value = slot.room,
                                        onValueChange = { viewModel.updateSlot(day, slot.key, room = it) },
                                        label = { Text(stringResource(R.string.routine_room)) },
                                        singleLine = true,
                                        shape = fieldShape,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                                IconButton(onClick = { viewModel.removeSlot(day, slot.key) }) {
                                    Icon(
                                        imageVector = Icons.Filled.Close,
                                        contentDescription = stringResource(R.string.routine_remove_class),
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        item {
            viewModel.error?.let {
                Text(
                    text = it.resolve(context),
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }
            GradientButton(
                text = stringResource(if (viewModel.saving) R.string.edit_saving else R.string.routine_save),
                onClick = viewModel::save,
                enabled = !viewModel.saving,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
