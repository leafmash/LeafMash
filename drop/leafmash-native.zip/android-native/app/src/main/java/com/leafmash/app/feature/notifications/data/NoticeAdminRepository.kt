package com.leafmash.app.feature.notifications.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.leafmash.app.core.notify.ActivityLogger
import com.leafmash.app.core.notify.PushTrigger
import com.leafmash.app.core.profile.ProfileRepository
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.tasks.await

@Singleton
class NoticeAdminRepository @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth,
    private val profiles: ProfileRepository,
    private val activity: ActivityLogger,
    private val push: PushTrigger
) {

    suspend fun post(text: String, urgent: Boolean) {
        val user = auth.currentUser ?: error("Not signed in")
        val ref = firestore.collection("notices").document()
        ref.set(
            mapOf(
                "text" to text,
                "urgent" to urgent,
                "postedBy" to user.email.orEmpty(),
                "postedByUid" to user.uid,
                "postedByName" to (profiles.current.value?.name ?: "Admin"),
                "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()
        activity.log("notice", text, noticeId = ref.id)
        push.send(type = "notice", text = text, urgent = urgent, noticeId = ref.id)
    }

    suspend fun update(id: String, text: String, urgent: Boolean) {
        firestore.collection("notices").document(id)
            .update(mapOf("text" to text, "urgent" to urgent))
            .await()
    }

    suspend fun delete(id: String) {
        firestore.collection("notices").document(id).delete().await()
        activity.deleteForNotice(id)
    }
}
