package com.leafmash.app.feature.wall

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.leafmash.app.R
import com.leafmash.app.core.data.Poll
import kotlin.math.roundToInt

@Composable
private fun GridImage(url: String, onClick: () -> Unit, modifier: Modifier = Modifier, extra: Int = 0) {
    Box(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick)
    ) {
        AsyncImage(
            model = url,
            contentDescription = stringResource(R.string.post_photo_cd),
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        if (extra > 0) {
            Box(
                modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "+$extra",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun PostImageGrid(images: List<String>, onImageClick: (Int) -> Unit, modifier: Modifier = Modifier) {
    if (images.isEmpty()) return
    val shape = RoundedCornerShape(12.dp)
    val gap = 4.dp
    Box(modifier.fillMaxWidth().clip(shape)) {
        when (images.size) {
            1 -> GridImage(images[0], { onImageClick(0) }, Modifier.fillMaxWidth().aspectRatio(1.25f))
            2 -> Row(Modifier.fillMaxWidth().height(200.dp), horizontalArrangement = Arrangement.spacedBy(gap)) {
                GridImage(images[0], { onImageClick(0) }, Modifier.weight(1f).fillMaxHeight())
                GridImage(images[1], { onImageClick(1) }, Modifier.weight(1f).fillMaxHeight())
            }
            3 -> Row(Modifier.fillMaxWidth().height(240.dp), horizontalArrangement = Arrangement.spacedBy(gap)) {
                GridImage(images[0], { onImageClick(0) }, Modifier.weight(1f).fillMaxHeight())
                Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(gap)) {
                    GridImage(images[1], { onImageClick(1) }, Modifier.weight(1f).fillMaxWidth())
                    GridImage(images[2], { onImageClick(2) }, Modifier.weight(1f).fillMaxWidth())
                }
            }
            else -> Column(Modifier.fillMaxWidth().height(260.dp), verticalArrangement = Arrangement.spacedBy(gap)) {
                Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                    GridImage(images[0], { onImageClick(0) }, Modifier.weight(1f).fillMaxHeight())
                    GridImage(images[1], { onImageClick(1) }, Modifier.weight(1f).fillMaxHeight())
                }
                Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                    GridImage(images[2], { onImageClick(2) }, Modifier.weight(1f).fillMaxHeight())
                    GridImage(
                        images[3],
                        { onImageClick(3) },
                        Modifier.weight(1f).fillMaxHeight(),
                        extra = images.size - 4
                    )
                }
            }
        }
    }
}

@Composable
fun ImageViewerDialog(images: List<String>, startIndex: Int, onDismiss: () -> Unit) {
    val pagerState = rememberPagerState(initialPage = startIndex.coerceIn(0, images.lastIndex)) { images.size }
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { page ->
                AsyncImage(
                    model = images[page],
                    contentDescription = stringResource(R.string.post_photo_cd),
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = stringResource(R.string.action_close),
                        tint = Color.White
                    )
                }
                Spacer(Modifier.weight(1f))
                if (images.size > 1) {
                    Text(
                        text = "${pagerState.currentPage + 1}/${images.size}",
                        color = Color.White,
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier.padding(end = 12.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun PollBlock(poll: Poll, myUid: String, onVote: (String) -> Unit, modifier: Modifier = Modifier) {
    val votes = poll.votes
    val total = votes.size
    val counts = votes.values.groupingBy { it }.eachCount()
    val myVote = votes[myUid]
    val context = LocalContext.current
    val fillColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
    val shape = RoundedCornerShape(12.dp)
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        poll.options.forEach { option ->
            val count = counts[option.id] ?: 0
            val fraction = if (total > 0) count.toFloat() / total else 0f
            val mine = myVote == option.id
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .clip(shape)
                    .border(
                        width = if (mine) 2.dp else 1.dp,
                        color = if (mine) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                        shape = shape
                    )
                    .drawBehind {
                        drawRect(color = fillColor, size = Size(size.width * fraction, size.height))
                    }
                    .clickable { onVote(option.id) }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (mine) Icons.Filled.RadioButtonChecked else Icons.Filled.RadioButtonUnchecked,
                    contentDescription = null,
                    tint = if (mine) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = option.text,
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.weight(1f).padding(horizontal = 12.dp)
                )
                if (total > 0) {
                    Text(
                        text = "${(fraction * 100).roundToInt()}%",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        Text(
            text = context.resources.getQuantityString(R.plurals.votes_count, total, total),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
