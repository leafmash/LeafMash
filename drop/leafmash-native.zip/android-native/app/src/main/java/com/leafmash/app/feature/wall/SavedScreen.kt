package com.leafmash.app.feature.wall

import com.leafmash.app.ui.components.FlatItem
import com.leafmash.app.ui.components.LeafCard
import com.leafmash.app.ui.components.EmptyCard
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.PaddingValues
import com.leafmash.app.ui.components.LeafTopAppBar
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.OpenInNew
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leafmash.app.R
import com.leafmash.app.core.data.authorFallback
import com.leafmash.app.feature.wall.data.Bookmark
import com.leafmash.app.ui.components.CollectSnackbars
import com.leafmash.app.ui.components.SkeletonPost

private enum class SavedFilter { ALL, POSTS, NOTES }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavedScreen(
    onBack: () -> Unit,
    onOpenPost: (String, Boolean) -> Unit,
    onEditPost: (String) -> Unit,
    onOpenHashtag: (String) -> Unit,
    viewModel: SavedViewModel = hiltViewModel()
) {
    val bookmarks by viewModel.bookmarkList.collectAsStateWithLifecycle()
    val savedPosts by viewModel.savedPosts.collectAsStateWithLifecycle()
    val users by viewModel.users.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var filterName by rememberSaveable { mutableStateOf(SavedFilter.ALL.name) }
    var reactionsFor by remember { mutableStateOf<Map<String, String>?>(null) }
    val filter = SavedFilter.valueOf(filterName)
    val context = LocalContext.current
    val myUid = viewModel.myUid
    val isAdmin = viewModel.isAdmin

    CollectSnackbars(viewModel.events, snackbar)

    Scaffold(
        topBar = {
            LeafTopAppBar(
                title = { Text(stringResource(R.string.saved_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { inner ->
        Column(Modifier.fillMaxSize().padding(inner)) {
            val chipColors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primary,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
            )
            Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
                SavedFilter.entries.forEach { option ->
                    FilterChip(
                        selected = filter == option,
                        onClick = { filterName = option.name },
                        shape = RoundedCornerShape(50),
                        colors = chipColors,
                        label = {
                            Text(
                                stringResource(
                                    when (option) {
                                        SavedFilter.ALL -> R.string.saved_filter_all
                                        SavedFilter.POSTS -> R.string.saved_filter_posts
                                        SavedFilter.NOTES -> R.string.saved_filter_notes
                                    }
                                )
                            )
                        },
                        modifier = Modifier.padding(end = 8.dp)
                    )
                }
            }
            val postList = savedPosts
            val bookmarkItems = bookmarks
            if (postList == null || bookmarkItems == null) {
                Column { repeat(2) { SkeletonPost() } }
            } else {
                val showPosts = filter != SavedFilter.NOTES
                val showNotes = filter != SavedFilter.POSTS
                val notes = bookmarkItems.filter { it.type != "post" }
                val shownPosts = if (showPosts) postList else emptyList()
                val shownNotes = if (showNotes) notes else emptyList()
                if (shownPosts.isEmpty() && shownNotes.isEmpty()) {
                    EmptyCard(
                        title = stringResource(
                            when (filter) {
                                SavedFilter.ALL -> R.string.saved_empty_all
                                SavedFilter.POSTS -> R.string.saved_empty_posts
                                SavedFilter.NOTES -> R.string.saved_empty_notes
                            }
                        ),
                        icon = Icons.Outlined.BookmarkBorder,
                        modifier = Modifier.padding(24.dp)
                    )
                } else {
                    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 12.dp)) {
                        items(shownPosts, key = { "post_${it.id}" }) { post ->
                            PostCard(
                                post = post,
                                author = users[post.authorUid] ?: post.authorFallback(),
                                commentCount = post.commentCount,
                                saved = true,
                                myUid = myUid,
                                isAdmin = isAdmin,
                                callbacks = postCallbacks(
                                    viewModel = viewModel,
                                    post = post,
                                    saved = true,
                                    onOpenPost = onOpenPost,
                                    onEditPost = onEditPost,
                                    onOpenHashtag = onOpenHashtag,
                                    onViewReactions = { reactionsFor = it.reactions }
                                )
                            )
                        }
                        items(shownNotes, key = { "note_${it.id}" }) { note ->
                            NoteRow(note = note, onOpen = { openLink(context, note.link) })
                        }
                    }
                }
            }
        }
    }

    val shown = reactionsFor
    if (shown != null) {
        androidx.compose.runtime.LaunchedEffect(shown) { viewModel.ensureUsers(shown.keys) }
        ReactionsSheet(reactions = shown, users = users, onDismiss = { reactionsFor = null })
    }
}

@Composable
internal fun NoteRow(note: Bookmark, onOpen: () -> Unit) {
    FlatItem(
        modifier = Modifier
            .fillMaxWidth(),
        onClick = if (note.link.isNotEmpty()) onOpen else null
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 64.dp)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(text = note.title.ifEmpty { note.link }, style = MaterialTheme.typography.titleSmall, maxLines = 2)
                val meta = listOf(note.category, note.contributorName).filter { it.isNotEmpty() }.joinToString(" · ")
                if (meta.isNotEmpty()) {
                    Text(
                        text = meta,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            if (note.link.isNotEmpty()) {
                Spacer(Modifier.width(12.dp))
                Icon(Icons.AutoMirrored.Outlined.OpenInNew, contentDescription = stringResource(R.string.saved_open_note))
            }
        }
    }
}

internal fun openLink(context: android.content.Context, link: String) {
    if (!link.startsWith("http://") && !link.startsWith("https://")) return
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
    } catch (e: ActivityNotFoundException) {
        Unit
    }
}
