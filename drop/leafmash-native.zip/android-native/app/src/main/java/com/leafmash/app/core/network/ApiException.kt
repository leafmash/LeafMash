package com.leafmash.app.core.network

class ApiException(
    override val message: String,
    val statusCode: Int? = null
) : Exception(message)
