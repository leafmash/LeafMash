package com.leafmash.app.feature.admin

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leafmash.app.R
import com.leafmash.app.core.config.AppConfig
import com.leafmash.app.core.profile.ProfileRepository
import com.leafmash.app.core.util.UiText
import com.leafmash.app.core.util.safeCall
import com.leafmash.app.core.util.toUiText
import com.leafmash.app.feature.directory.data.Classmate
import com.leafmash.app.feature.directory.data.DirectoryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ReportsUiState(val loading: Boolean = true, val items: List<Report> = emptyList())

@HiltViewModel
class ReportsViewModel @Inject constructor(
    private val repository: ReportsRepository,
    profiles: ProfileRepository
) : ViewModel() {

    private val eventChannel = Channel<UiText>(Channel.BUFFERED)
    val events: Flow<UiText> = eventChannel.receiveAsFlow()

    val isAdmin: StateFlow<Boolean> = profiles.current
        .map { AppConfig.isAdminEmail(it?.email) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    val state: StateFlow<ReportsUiState> = repository.observeOpen()
        .map { ReportsUiState(loading = false, items = it) }
        .onStart { emit(ReportsUiState()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ReportsUiState())

    var pendingRemove by mutableStateOf<Report?>(null)
        private set

    var busyId by mutableStateOf<String?>(null)
        private set

    fun requestRemove(report: Report?) {
        pendingRemove = report
    }

    fun dismiss(report: Report) {
        execute(report.id) { repository.dismiss(report.id) }
    }

    fun confirmRemove() {
        val target = pendingRemove ?: return
        pendingRemove = null
        execute(target.id) { repository.removePost(target) }
    }

    private fun execute(id: String, block: suspend () -> Unit) {
        if (busyId != null) return
        busyId = id
        viewModelScope.launch {
            safeCall { block() }
                .onSuccess { eventChannel.send(UiText.Res(R.string.reports_done)) }
                .onFailure { eventChannel.send(it.toUiText()) }
            busyId = null
        }
    }
}

data class VerifiedUiState(
    val loading: Boolean = true,
    val failed: Boolean = false,
    val users: List<Classmate> = emptyList()
)

@HiltViewModel
class VerifiedViewModel @Inject constructor(
    private val directory: DirectoryRepository,
    profiles: ProfileRepository
) : ViewModel() {

    private val eventChannel = Channel<UiText>(Channel.BUFFERED)
    val events: Flow<UiText> = eventChannel.receiveAsFlow()

    val isAdmin: StateFlow<Boolean> = profiles.current
        .map { AppConfig.isAdminEmail(it?.email) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    private val stateFlow = MutableStateFlow(VerifiedUiState())
    val state: StateFlow<VerifiedUiState> = stateFlow

    var query by mutableStateOf("")
        private set

    var busyUid by mutableStateOf<String?>(null)
        private set

    init {
        load()
    }

    fun load() {
        stateFlow.value = VerifiedUiState()
        viewModelScope.launch {
            safeCall { directory.loadAll() }
                .onSuccess { stateFlow.value = VerifiedUiState(loading = false, users = it) }
                .onFailure { stateFlow.value = VerifiedUiState(loading = false, failed = true) }
        }
    }

    fun updateQuery(value: String) {
        query = value
    }

    fun setVerified(user: Classmate, verified: Boolean) {
        if (busyUid != null) return
        busyUid = user.uid
        viewModelScope.launch {
            safeCall { directory.setVerified(user.uid, verified) }
                .onSuccess {
                    stateFlow.update { current ->
                        current.copy(users = current.users.map { if (it.uid == user.uid) it.copy(verified = verified) else it })
                    }
                    eventChannel.send(UiText.Res(if (verified) R.string.verified_given else R.string.verified_removed))
                }
                .onFailure { eventChannel.send(it.toUiText()) }
            busyUid = null
        }
    }
}
