package com.leafmash.app.feature.resources

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.LibraryBooks
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.leafmash.app.R
import com.leafmash.app.ui.components.PlaceholderScreen

@Composable
fun ResourcesScreen() {
    PlaceholderScreen(
        title = stringResource(R.string.nav_resources),
        icon = Icons.AutoMirrored.Filled.LibraryBooks,
        phase = 5
    )
}
