package com.leafmash.app.feature.resources

import com.leafmash.app.ui.components.FlatItem
import com.leafmash.app.ui.components.LeafTopAppBar
import com.leafmash.app.ui.navigation.MenuAction
import com.leafmash.app.ui.components.LeafCard
import com.leafmash.app.ui.components.EmptyCard
import androidx.compose.ui.draw.clip
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leafmash.app.R
import com.leafmash.app.feature.resources.data.Resource
import com.leafmash.app.feature.resources.data.ResourceCategories
import com.leafmash.app.ui.components.CollectSnackbars
import com.leafmash.app.ui.components.DropdownField
import com.leafmash.app.ui.components.DropdownOption
import com.leafmash.app.ui.components.rememberTimeAgo

private fun openResource(context: Context, link: String) {
    val uri = runCatching { Uri.parse(link) }.getOrNull() ?: return
    if (uri.scheme != "http" && uri.scheme != "https") return
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: ActivityNotFoundException) {
        return
    }
}

@Composable
fun ResourcesScreen(viewModel: ResourcesViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val context = LocalContext.current
    val filter = viewModel.filter
    val query = viewModel.query.trim()

    CollectSnackbars(viewModel.events, snackbar)

    val base = if (filter == SAVED_FILTER) state.savedItems else state.items
    val shown = base.filter { item ->
        (filter == ALL_FILTER || filter == SAVED_FILTER || item.category == filter) &&
            (
                query.isEmpty() ||
                    item.title.contains(query, ignoreCase = true) ||
                    item.category.contains(query, ignoreCase = true) ||
                    item.contributorName.contains(query, ignoreCase = true)
                )
    }

    Scaffold(
        topBar = {
            LeafTopAppBar(title = { Text(stringResource(R.string.nav_resources)) }, actions = { MenuAction() })
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = viewModel::startAdd,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                shape = RoundedCornerShape(20.dp)
            ) {
                Icon(Icons.Filled.Add, contentDescription = stringResource(R.string.resource_add))
            }
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { inner ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(inner)
        ) {
            OutlinedTextField(
                value = viewModel.query,
                onValueChange = viewModel::updateQuery,
                placeholder = { Text(stringResource(R.string.resource_search)) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 8.dp)
            )
            val chipColors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primary,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
            )
            LazyRow(
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = filter == ALL_FILTER,
                        onClick = { viewModel.selectFilter(ALL_FILTER) },
                        shape = RoundedCornerShape(50),
                        colors = chipColors,
                        label = { Text(stringResource(R.string.resource_filter_all)) }
                    )
                }
                item {
                    FilterChip(
                        selected = filter == SAVED_FILTER,
                        onClick = { viewModel.selectFilter(SAVED_FILTER) },
                        shape = RoundedCornerShape(50),
                        colors = chipColors,
                        label = { Text(stringResource(R.string.resource_filter_saved)) }
                    )
                }
                items(ResourceCategories) { category ->
                    FilterChip(
                        selected = filter == category,
                        onClick = { viewModel.selectFilter(category) },
                        shape = RoundedCornerShape(50),
                        colors = chipColors,
                        label = { Text(category) }
                    )
                }
            }
            Box(modifier = Modifier.fillMaxSize()) {
                when {
                    state.loading -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                    shown.isEmpty() && !(state.canLoadMore && filter != SAVED_FILTER) -> EmptyCard(
                        title = stringResource(if (filter == SAVED_FILTER) R.string.resource_empty_saved else R.string.resource_empty),
                        icon = Icons.Filled.Search,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(24.dp)
                    )
                    else -> LazyColumn(
                        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(shown, key = { it.id }) { item ->
                            ResourceCard(
                                item = item,
                                saved = item.id in state.savedIds,
                                mine = item.contributorUid.isNotEmpty() && item.contributorUid == viewModel.myUid,
                                inSavedView = filter == SAVED_FILTER,
                                onOpen = {
                                    viewModel.recordOpen(item)
                                    openResource(context, item.link)
                                },
                                onToggleSaved = { viewModel.toggleSaved(item) },
                                onEdit = { viewModel.startEdit(item) },
                                onDelete = { viewModel.requestDelete(item) }
                            )
                        }
                        if (state.canLoadMore && filter != SAVED_FILTER) {
                            item {
                                OutlinedButton(onClick = viewModel::loadMore, modifier = Modifier.fillMaxWidth()) {
                                    Text(stringResource(R.string.resource_load_more))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    viewModel.form?.let { form -> ResourceFormDialog(viewModel, form) }

    viewModel.pendingDelete?.let {
        AlertDialog(
            onDismissRequest = { viewModel.requestDelete(null) },
            title = { Text(stringResource(R.string.resource_delete_title)) },
            text = { Text(stringResource(R.string.resource_delete_text)) },
            confirmButton = {
                TextButton(onClick = viewModel::confirmDelete) { Text(stringResource(R.string.action_delete)) }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.requestDelete(null) }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
}

@Composable
private fun ResourceCard(
    item: Resource,
    saved: Boolean,
    mine: Boolean,
    inSavedView: Boolean,
    onOpen: () -> Unit,
    onToggleSaved: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val isUpload = item.sourceType == "upload"
    FlatItem(
        modifier = Modifier.fillMaxWidth(),
        onClick = onOpen
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                val badge = if (isUpload && item.fileExt.isNotEmpty()) item.fileExt.take(4).uppercase() else "LINK"
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer)
                        .padding(horizontal = 9.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = badge,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                Spacer(Modifier.width(10.dp))
                Text(
                    text = item.category,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onToggleSaved) {
                    Icon(
                        if (saved) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                        contentDescription = stringResource(if (saved) R.string.resource_unsave else R.string.resource_save)
                    )
                }
                if (mine && !inSavedView) {
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Filled.Edit, contentDescription = stringResource(R.string.resource_edit))
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.action_delete))
                    }
                }
            }
            Text(item.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            val parts = ArrayList<String>()
            if (item.contributorName.isNotEmpty()) parts.add(stringResource(R.string.resource_shared_by, item.contributorName))
            if (item.createdAtMs > 0L) parts.add(rememberTimeAgo(item.createdAtMs))
            if (item.openCount > 0L) {
                parts.add(
                    stringResource(if (isUpload) R.string.resource_downloads else R.string.resource_views, item.openCount)
                )
            }
            if (parts.isNotEmpty()) {
                Text(
                    text = parts.joinToString(" · "),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            Text(
                text = stringResource(if (isUpload) R.string.resource_download else R.string.resource_open),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

@Composable
private fun ResourceFormDialog(viewModel: ResourcesViewModel, form: ResourceForm) {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { viewModel.pickFile(it) }
    val editing = form.editing
    val categories = ResourceCategories.map { DropdownOption(it, it) }

    AlertDialog(
        onDismissRequest = { if (!viewModel.saving) viewModel.dismissForm() },
        title = { Text(stringResource(if (editing == null) R.string.resource_add else R.string.resource_edit)) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = form.title,
                    onValueChange = { v -> viewModel.change { it.copy(title = v.take(150)) } },
                    label = { Text(stringResource(R.string.resource_field_title)) },
                    modifier = Modifier.fillMaxWidth()
                )
                DropdownField(
                    label = stringResource(R.string.resource_field_category),
                    selectedValue = form.category,
                    options = categories,
                    onSelect = { v -> viewModel.change { it.copy(category = v) } }
                )
                if (editing == null) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = !form.upload,
                            onClick = { viewModel.change { it.copy(upload = false) } },
                            label = { Text(stringResource(R.string.resource_source_link)) }
                        )
                        FilterChip(
                            selected = form.upload,
                            onClick = { viewModel.change { it.copy(upload = true) } },
                            label = { Text(stringResource(R.string.resource_source_upload)) }
                        )
                    }
                }
                if (form.upload && editing == null) {
                    OutlinedButton(onClick = { launcher.launch("*/*") }, modifier = Modifier.fillMaxWidth()) {
                        Text(form.file?.name ?: stringResource(R.string.resource_choose_file))
                    }
                    Text(
                        text = stringResource(R.string.resource_file_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else if (!form.upload || editing != null) {
                    OutlinedTextField(
                        value = form.link,
                        onValueChange = { v -> viewModel.change { it.copy(link = v) } },
                        label = { Text(stringResource(R.string.resource_field_link)) },
                        singleLine = true,
                        enabled = editing == null || editing.sourceType != "upload",
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                viewModel.formError?.let {
                    Text(it.resolve(context), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                }
            }
        },
        confirmButton = {
            Button(onClick = viewModel::submit, enabled = !viewModel.saving) {
                Text(
                    stringResource(
                        when {
                            viewModel.saving -> R.string.edit_saving
                            editing == null -> R.string.resource_publish
                            else -> R.string.deadline_save_confirm
                        }
                    )
                )
            }
        },
        dismissButton = {
            TextButton(onClick = viewModel::dismissForm, enabled = !viewModel.saving) {
                Text(stringResource(R.string.action_cancel))
            }
        }
    )
}
