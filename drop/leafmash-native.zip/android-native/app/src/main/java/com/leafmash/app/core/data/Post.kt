package com.leafmash.app.core.data

import com.google.firebase.firestore.DocumentSnapshot

data class MentionRef(val uid: String, val name: String)

data class PollOption(val id: String, val text: String)

data class Poll(val options: List<PollOption>, val votes: Map<String, String>)

data class ReplyRef(val id: String, val authorUid: String, val authorName: String)

data class Post(
    val id: String,
    val authorUid: String,
    val authorName: String,
    val authorEmail: String,
    val text: String,
    val images: List<String>,
    val mentions: List<MentionRef>,
    val reactions: Map<String, String>,
    val pinned: Boolean,
    val poll: Poll?,
    val commentCount: Int?,
    val createdAtMs: Long,
    val editedAtMs: Long
) {
    val edited: Boolean get() = editedAtMs > 0L
}

data class Comment(
    val id: String,
    val authorUid: String,
    val authorName: String,
    val authorEmail: String,
    val text: String,
    val mentions: List<MentionRef>,
    val replyTo: ReplyRef?,
    val reactions: Map<String, String>,
    val createdAtMs: Long,
    val editedAtMs: Long
) {
    val edited: Boolean get() = editedAtMs > 0L
}

data class PendingComment(val tempId: String, val text: String, val replyTo: ReplyRef?)

data class CommentResult(val id: String, val postAuthorUid: String, val replyTargetUid: String)

fun Post.authorFallback(): UserSummary = UserSummary(authorUid, authorName, authorEmail, "", false)

fun Comment.authorFallback(): UserSummary = UserSummary(authorUid, authorName, authorEmail, "", false)

private fun DocumentSnapshot.millis(field: String): Long =
    getTimestamp(field, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0L

private fun DocumentSnapshot.mentionList(): List<MentionRef> =
    (get("mentions") as? List<*>).orEmpty().mapNotNull { item ->
        val map = item as? Map<*, *> ?: return@mapNotNull null
        val uid = map["uid"] as? String
        val name = map["name"] as? String
        if (uid != null && name != null) MentionRef(uid, name) else null
    }

private fun DocumentSnapshot.reactionMap(): Map<String, String> {
    val raw = get("reactions") as? Map<*, *>
    if (raw != null) {
        val result = LinkedHashMap<String, String>()
        raw.forEach { (key, value) ->
            if (key is String && value is String) result[key] = value
        }
        return result
    }
    val likes = (get("likes") as? List<*>).orEmpty().filterIsInstance<String>()
    return likes.associateWith { Reactions.LEAF }
}

private fun DocumentSnapshot.pollOrNull(): Poll? {
    val raw = get("poll") as? Map<*, *> ?: return null
    val options = (raw["options"] as? List<*>).orEmpty().mapNotNull { item ->
        val map = item as? Map<*, *> ?: return@mapNotNull null
        val id = map["id"] as? String ?: return@mapNotNull null
        val text = map["text"] as? String ?: return@mapNotNull null
        PollOption(id, text)
    }
    if (options.isEmpty()) return null
    val votes = LinkedHashMap<String, String>()
    (raw["votes"] as? Map<*, *>)?.forEach { (key, value) ->
        if (key is String && value is String) votes[key] = value
    }
    return Poll(options, votes)
}

fun DocumentSnapshot.toPost(): Post? {
    if (!exists()) return null
    return Post(
        id = id,
        authorUid = getString("authorUid").orEmpty(),
        authorName = getString("authorName").orEmpty(),
        authorEmail = getString("authorEmail").orEmpty(),
        text = getString("text").orEmpty(),
        images = (get("images") as? List<*>).orEmpty().filterIsInstance<String>(),
        mentions = mentionList(),
        reactions = reactionMap(),
        pinned = getBoolean("pinned") == true,
        poll = pollOrNull(),
        commentCount = getLong("commentCount")?.toInt(),
        createdAtMs = millis("createdAt"),
        editedAtMs = millis("editedAt")
    )
}

fun DocumentSnapshot.toComment(): Comment? {
    if (!exists()) return null
    val reply = get("replyTo") as? Map<*, *>
    val replyRef = reply?.let {
        val replyId = it["id"] as? String
        if (replyId.isNullOrEmpty()) null else ReplyRef(
            id = replyId,
            authorUid = it["authorUid"] as? String ?: "",
            authorName = it["authorName"] as? String ?: ""
        )
    }
    val reactions = LinkedHashMap<String, String>()
    (get("reactions") as? Map<*, *>)?.forEach { (key, value) ->
        if (key is String && value is String) reactions[key] = value
    }
    return Comment(
        id = id,
        authorUid = getString("authorUid").orEmpty(),
        authorName = getString("authorName").orEmpty(),
        authorEmail = getString("authorEmail").orEmpty(),
        text = getString("text").orEmpty(),
        mentions = mentionList(),
        replyTo = replyRef,
        reactions = reactions,
        createdAtMs = millis("createdAt"),
        editedAtMs = millis("editedAt")
    )
}
