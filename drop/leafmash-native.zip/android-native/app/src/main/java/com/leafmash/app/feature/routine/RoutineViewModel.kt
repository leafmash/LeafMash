package com.leafmash.app.feature.routine

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leafmash.app.R
import com.leafmash.app.core.config.AppConfig
import com.leafmash.app.core.profile.ProfileRepository
import com.leafmash.app.core.util.UiText
import com.leafmash.app.core.util.safeCall
import com.leafmash.app.core.util.toUiText
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class EditableSlot(val key: Long, val time: String, val subject: String, val room: String)

data class RoutineUiState(
    val loading: Boolean = true,
    val days: Map<String, List<RoutineSlot>>? = null
)

@HiltViewModel
class RoutineViewModel @Inject constructor(
    private val repository: RoutineRepository,
    profiles: ProfileRepository
) : ViewModel() {

    private val eventChannel = Channel<UiText>(Channel.BUFFERED)
    val events: Flow<UiText> = eventChannel.receiveAsFlow()

    val isAdmin: StateFlow<Boolean> = profiles.current
        .map { AppConfig.isAdminEmail(it?.email) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    val state: StateFlow<RoutineUiState> = repository.observe()
        .map { RoutineUiState(loading = false, days = it) }
        .onStart { emit(RoutineUiState()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), RoutineUiState())

    var draft by mutableStateOf<Map<String, List<EditableSlot>>?>(null)
        private set

    var saving by mutableStateOf(false)
        private set

    var error by mutableStateOf<UiText?>(null)
        private set

    private var nextKey = 1L

    fun startEdit() {
        val current = state.value.days.orEmpty()
        draft = RoutineDays.associateWith { day ->
            current[day].orEmpty().map { EditableSlot(nextKey++, it.time, it.subject, it.room) }
        }
        error = null
    }

    fun cancelEdit() {
        draft = null
        error = null
    }

    fun addSlot(day: String) {
        val current = draft ?: return
        draft = current + (day to current[day].orEmpty() + EditableSlot(nextKey++, "", "", ""))
    }

    fun removeSlot(day: String, key: Long) {
        val current = draft ?: return
        draft = current + (day to current[day].orEmpty().filter { it.key != key })
    }

    fun updateSlot(day: String, key: Long, time: String? = null, subject: String? = null, room: String? = null) {
        val current = draft ?: return
        draft = current + (
            day to current[day].orEmpty().map { slot ->
                if (slot.key != key) {
                    slot
                } else {
                    slot.copy(
                        time = time ?: slot.time,
                        subject = subject ?: slot.subject,
                        room = room ?: slot.room
                    )
                }
            }
            )
    }

    fun save() {
        val current = draft ?: return
        val result = LinkedHashMap<String, List<RoutineSlot>>()
        for (day in RoutineDays) {
            val slots = ArrayList<RoutineSlot>()
            for (slot in current[day].orEmpty()) {
                val time = slot.time.trim()
                val subject = slot.subject.trim()
                val room = slot.room.trim()
                if (time.isEmpty() && subject.isEmpty() && room.isEmpty()) continue
                if (time.isEmpty() || subject.isEmpty()) {
                    error = UiText.Res(R.string.routine_error_incomplete)
                    return
                }
                slots.add(RoutineSlot(time, subject, room))
            }
            result[day] = slots
        }
        error = null
        saving = true
        viewModelScope.launch {
            safeCall { repository.save(result) }
                .onSuccess {
                    draft = null
                    eventChannel.send(UiText.Res(R.string.routine_saved))
                }
                .onFailure { error = it.toUiText() }
            saving = false
        }
    }
}
