package com.leafmash.app.core.upload

import com.leafmash.app.core.network.ApiClient
import com.leafmash.app.core.network.ApiException
import java.io.IOException
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

@Singleton
class ImageUploader @Inject constructor(
    private val api: ApiClient,
    private val json: Json
) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun uploadJpeg(bytes: ByteArray, folder: String, fileName: String): Result<String> {
        val signature = api.call(
            "sign-upload",
            buildJsonObject { put("folder", folder) },
            skipClientCooldown = true
        ).getOrElse { return Result.failure(it) }
        return withContext(Dispatchers.IO) { send(bytes, fileName, signature) }
    }

    suspend fun uploadJpegs(images: List<ByteArray>, folder: String, namePrefix: String): Result<List<String>> {
        if (images.isEmpty()) return Result.success(emptyList())
        val signature = api.call(
            "sign-upload",
            buildJsonObject { put("folder", folder) },
            skipClientCooldown = true
        ).getOrElse { return Result.failure(it) }
        return withContext(Dispatchers.IO) {
            val urls = ArrayList<String>(images.size)
            for ((index, bytes) in images.withIndex()) {
                val url = send(bytes, "$namePrefix-$index.jpg", signature).getOrElse { return@withContext Result.failure<List<String>>(it) }
                urls.add(url)
            }
            Result.success<List<String>>(urls)
        }
    }

    private fun send(bytes: ByteArray, fileName: String, signature: JsonObject): Result<String> {
        val cloudName = signature.text("cloudName")
        val apiKey = signature.text("apiKey")
        val sigValue = signature.text("signature")
        val timestamp = signature.text("timestamp")
        val preset = signature.text("uploadPreset")
        val folder = signature.text("folder")
        if (cloudName.isEmpty() || apiKey.isEmpty() || sigValue.isEmpty() || timestamp.isEmpty()) {
            return Result.failure(ApiException("Upload isn't available right now."))
        }
        val body = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", fileName, bytes.toRequestBody("image/jpeg".toMediaType()))
            .addFormDataPart("api_key", apiKey)
            .addFormDataPart("timestamp", timestamp)
            .addFormDataPart("signature", sigValue)
            .addFormDataPart("upload_preset", preset)
            .addFormDataPart("folder", folder)
            .addFormDataPart("unique_filename", "true")
            .addFormDataPart("use_filename", "true")
            .build()
        val request = Request.Builder()
            .url("https://api.cloudinary.com/v1_1/$cloudName/image/upload")
            .post(body)
            .build()
        return try {
            client.newCall(request).execute().use { response ->
                val text = response.body?.string().orEmpty()
                val parsed = runCatching { json.parseToJsonElement(text).jsonObject }.getOrNull()
                if (!response.isSuccessful) {
                    val message = (parsed?.get("error") as? JsonObject)?.text("message").orEmpty()
                    Result.failure(ApiException(message.ifEmpty { "Upload failed." }))
                } else {
                    val url = parsed?.text("secure_url").orEmpty()
                    if (url.isEmpty()) {
                        Result.failure(ApiException("Upload failed."))
                    } else {
                        Result.success(url)
                    }
                }
            }
        } catch (e: IOException) {
            Result.failure(ApiException("Network error. Check your connection and try again."))
        }
    }

    private fun JsonObject.text(key: String): String = (this[key] as? JsonPrimitive)?.contentOrNull.orEmpty()
}
