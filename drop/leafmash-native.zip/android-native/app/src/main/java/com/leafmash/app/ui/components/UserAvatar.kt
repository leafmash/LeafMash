package com.leafmash.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.leafmash.app.core.data.ProfileBadge
import com.leafmash.app.ui.theme.AvatarPalette
import com.leafmash.app.ui.theme.LeafPalette
import kotlin.math.abs

fun initialsOf(name: String): String {
    val letters = name.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.take(2)
        .joinToString("") { it.first().uppercase() }
    return letters.ifEmpty { "?" }
}

fun avatarColorFor(seed: String): Color {
    var hash = 0
    for (ch in seed) hash = hash * 31 + ch.code
    return AvatarPalette[abs(hash % AvatarPalette.size)]
}

fun Modifier.dottedRing(color: Color, stroke: Dp): Modifier = drawBehind {
    val width = stroke.toPx()
    val radius = (size.minDimension - width) / 2f
    val circumference = (2.0 * Math.PI * radius).toFloat()
    val count = (circumference / (width * 1.1f)).toInt().coerceAtLeast(12)
    val interval = circumference / count
    drawCircle(
        color = color,
        radius = radius,
        style = Stroke(
            width = width,
            cap = StrokeCap.Round,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(0.01f, interval - 0.01f), 0f)
        )
    )
}

@Composable
private fun AvatarFace(name: String, photoUrl: String, contentDescription: String?, size: Dp) {
    if (photoUrl.isNotEmpty()) {
        AsyncImage(
            model = photoUrl,
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(size)
        )
    } else {
        Text(
            text = initialsOf(name),
            color = Color.White,
            style = MaterialTheme.typography.titleMedium.copy(fontSize = (size.value * 0.36f).sp)
        )
    }
}

@Composable
fun UserAvatar(
    name: String,
    seed: String,
    photoUrl: String,
    modifier: Modifier = Modifier,
    size: Dp = 40.dp,
    contentDescription: String? = null,
    badge: ProfileBadge = ProfileBadge.NONE
) {
    val background = remember(seed) { avatarColorFor(seed.ifEmpty { name }) }
    val ringColor = badgeColor(badge)
    if (ringColor == null) {
        Box(
            modifier = modifier
                .size(size)
                .clip(CircleShape)
                .background(background),
            contentAlignment = Alignment.Center
        ) {
            AvatarFace(name, photoUrl, contentDescription, size)
        }
    } else {
        val stroke = (size.value * 0.045f).coerceAtLeast(1.5f).dp
        val inner = size - stroke * 4f
        Box(
            modifier = modifier
                .size(size)
                .dottedRing(ringColor, stroke),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(inner)
                    .clip(CircleShape)
                    .background(background),
                contentAlignment = Alignment.Center
            ) {
                AvatarFace(name, photoUrl, contentDescription, inner)
            }
        }
    }
}

@Composable
fun RingAvatar(
    name: String,
    seed: String,
    photoUrl: String,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    ring: Boolean = true,
    onlineDot: Boolean = false,
    badge: ProfileBadge = ProfileBadge.NONE,
    dimWhenIdle: Boolean = false
) {
    val ringWidth = 2.5.dp
    val gap = 2.dp
    val total = size + (ringWidth + gap) * 2
    val brush = if (MaterialTheme.colorScheme.surface.luminance() < 0.5f) LeafPalette.RingBrushDark else LeafPalette.RingBrush
    val surface = MaterialTheme.colorScheme.surfaceContainerLowest
    val badgeRing = badgeColor(badge)?.let { if (dimWhenIdle && !ring) it.copy(alpha = 0.55f) else it }
    Box(modifier = modifier.size(total)) {
        Box(
            modifier = Modifier
                .size(total)
                .clip(CircleShape)
                .then(
                    when {
                        badgeRing != null -> Modifier.dottedRing(badgeRing, ringWidth)
                        ring -> Modifier.background(brush)
                        else -> Modifier.background(MaterialTheme.colorScheme.outlineVariant)
                    }
                )
                .padding(ringWidth)
                .clip(CircleShape)
                .background(surface)
                .padding(gap),
            contentAlignment = Alignment.Center
        ) {
            UserAvatar(name = name, seed = seed, photoUrl = photoUrl, size = size)
        }
        if (onlineDot) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(size * 0.3f)
                    .clip(CircleShape)
                    .background(surface)
                    .padding(2.dp)
                    .clip(CircleShape)
                    .background(LeafPalette.Online)
            )
        }
    }
}
