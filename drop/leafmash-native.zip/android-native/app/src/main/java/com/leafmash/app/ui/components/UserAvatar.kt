package com.leafmash.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.leafmash.app.ui.theme.AvatarPalette
import kotlin.math.abs

fun initialsOf(name: String): String {
    val letters = name.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.take(2)
        .joinToString("") { it.first().uppercase() }
    return letters.ifEmpty { "?" }
}

fun avatarColorFor(seed: String): Color {
    var hash = 0
    for (ch in seed) hash = hash * 31 + ch.code
    return AvatarPalette[abs(hash % AvatarPalette.size)]
}

@Composable
fun UserAvatar(
    name: String,
    seed: String,
    photoUrl: String,
    modifier: Modifier = Modifier,
    size: Dp = 40.dp,
    contentDescription: String? = null
) {
    val background = remember(seed) { avatarColorFor(seed.ifEmpty { name }) }
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(background),
        contentAlignment = Alignment.Center
    ) {
        if (photoUrl.isNotEmpty()) {
            AsyncImage(
                model = photoUrl,
                contentDescription = contentDescription,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(size)
            )
        } else {
            Text(
                text = initialsOf(name),
                color = Color.White,
                style = MaterialTheme.typography.titleMedium.copy(fontSize = (size.value * 0.36f).sp)
            )
        }
    }
}
