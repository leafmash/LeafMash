package com.leafmash.app.ui.components

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.leafmash.app.core.data.badge
import com.leafmash.app.core.data.MentionRef
import com.leafmash.app.core.data.UserSummary
import com.leafmash.app.core.data.displayName

class MentionInputState(private val maxLength: Int) {

    var value by mutableStateOf(TextFieldValue(""))
        private set

    private val picked = LinkedHashMap<String, MentionRef>()

    val text: String get() = value.text

    val query: String?
        get() {
            val caret = value.selection.start.coerceIn(0, value.text.length)
            val before = value.text.substring(0, caret)
            return QUERY_REGEX.find(before)?.groupValues?.get(1)
        }

    fun onChange(newValue: TextFieldValue) {
        if (newValue.text.length <= maxLength) value = newValue
    }

    fun setContent(text: String, mentions: List<MentionRef>) {
        picked.clear()
        mentions.forEach { picked[it.name] = it }
        val limited = text.take(maxLength)
        value = TextFieldValue(limited, TextRange(limited.length))
    }

    fun clear() {
        picked.clear()
        value = TextFieldValue("")
    }

    fun addMention(uid: String, name: String) {
        if (uid.isNotEmpty() && name.isNotEmpty()) picked[name] = MentionRef(uid, name)
    }

    fun prependText(prefix: String) {
        if (value.text.startsWith(prefix)) return
        val combined = (prefix + value.text).take(maxLength)
        value = TextFieldValue(combined, TextRange(combined.length))
    }

    fun removeText(piece: String) {
        if (piece.isEmpty() || !value.text.contains(piece)) return
        val updated = value.text.replaceFirst(piece, "")
        value = TextFieldValue(updated, TextRange(updated.length))
    }

    fun pick(candidate: UserSummary) {
        val caret = value.selection.start.coerceIn(0, value.text.length)
        val before = value.text.substring(0, caret)
        val match = TRAILING_REGEX.find(before) ?: return
        val newBefore = before.substring(0, match.range.first) + "@" + candidate.name + " "
        val combined = newBefore + value.text.substring(caret)
        if (combined.length > maxLength) return
        value = TextFieldValue(combined, TextRange(newBefore.length))
        picked[candidate.name] = MentionRef(candidate.uid, candidate.name)
    }

    fun mentions(): List<MentionRef> = picked.values.filter { value.text.contains("@" + it.name) }

    fun suggestions(all: List<UserSummary>, selfUid: String): List<UserSummary> {
        val q = query?.lowercase() ?: return emptyList()
        return all.asSequence()
            .filter { it.uid != selfUid && it.name.lowercase().contains(q) }
            .sortedWith(compareBy({ if (it.name.lowercase().startsWith(q)) 0 else 1 }, { it.name.lowercase() }))
            .take(MAX_SUGGESTIONS)
            .toList()
    }

    private companion object {
        val QUERY_REGEX = Regex("(?:^|\\s)@([^\\s@]{0,30})$")
        val TRAILING_REGEX = Regex("@([^\\s@]{0,30})$")
        const val MAX_SUGGESTIONS = 6
    }
}

@Composable
fun MentionSuggestionList(
    suggestions: List<UserSummary>,
    onPick: (UserSummary) -> Unit,
    modifier: Modifier = Modifier
) {
    if (suggestions.isEmpty()) return
    Surface(
        modifier = modifier.fillMaxWidth(),
        tonalElevation = 3.dp,
        shadowElevation = 2.dp,
        shape = MaterialTheme.shapes.medium
    ) {
        Column {
            suggestions.forEach { user ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .clickable { onPick(user) }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    UserAvatar(name = user.displayName, seed = user.uid, photoUrl = user.photoUrl, size = 32.dp, badge = user.badge)
                    Spacer(Modifier.width(12.dp))
                    Text(text = user.displayName, style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}
