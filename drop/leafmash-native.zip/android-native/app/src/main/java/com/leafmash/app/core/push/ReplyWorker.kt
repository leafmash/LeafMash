package com.leafmash.app.core.push

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.leafmash.app.core.network.ApiException
import dagger.hilt.android.EntryPointAccessors
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

class ReplyWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val text = inputData.getString(KEY_TEXT).orEmpty()
        if (text.isEmpty()) return Result.failure()
        val classChat = inputData.getBoolean(KEY_CLASS_CHAT, false)
        val targetUid = inputData.getString(KEY_TARGET_UID).orEmpty()
        if (!classChat && targetUid.isEmpty()) return Result.failure()
        val entry = EntryPointAccessors.fromApplication(applicationContext, PushEntryPoint::class.java)
        val payload = buildJsonObject {
            if (!classChat) put("targetUid", targetUid)
            put("text", text)
        }
        val action = if (classChat) "send-classchat-message" else "send-dm-message"
        val error = entry.api().call(action, payload, skipClientCooldown = true).exceptionOrNull()
            ?: return Result.success()
        val status = (error as? ApiException)?.statusCode
        val retryable = status == null || status == 429 || status >= 500
        if (retryable && runAttemptCount < MAX_ATTEMPTS) return Result.retry()
        entry.dispatcher().showReplyFailed()
        return Result.failure()
    }

    companion object {
        const val KEY_TEXT = "text"
        const val KEY_TARGET_UID = "targetUid"
        const val KEY_CLASS_CHAT = "classChat"
        private const val MAX_ATTEMPTS = 5
    }
}
