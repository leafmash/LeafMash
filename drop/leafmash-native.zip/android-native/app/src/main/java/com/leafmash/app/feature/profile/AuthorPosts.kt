package com.leafmash.app.feature.profile

import com.leafmash.app.core.data.Post
import com.leafmash.app.feature.wall.data.PostRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf

@OptIn(ExperimentalCoroutinesApi::class)
fun PostRepository.observeByAuthor(uid: String): Flow<List<Post>> =
    flow { emit(postsByAuthor(uid).getOrDefault(emptyList())) }
        .flatMapLatest { initial ->
            if (initial.isEmpty()) {
                flowOf(emptyList())
            } else {
                combine(initial.map { post -> observePost(post.id).catch { emit(null) } }) { array ->
                    array.filterNotNull().sortedByDescending { it.createdAtMs }
                }
            }
        }
