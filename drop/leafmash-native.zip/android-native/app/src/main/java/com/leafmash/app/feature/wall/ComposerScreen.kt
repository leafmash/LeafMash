package com.leafmash.app.feature.wall

import androidx.compose.runtime.getValue
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.AddPhotoAlternate
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.leafmash.app.R
import com.leafmash.app.core.data.displayName
import com.leafmash.app.core.util.asString
import com.leafmash.app.ui.components.MentionSuggestionList
import com.leafmash.app.ui.components.UserAvatar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComposerScreen(
    onClose: () -> Unit,
    viewModel: ComposerViewModel = hiltViewModel()
) {
    val students by viewModel.students.collectAsStateWithLifecycle()
    val users by viewModel.users.collectAsStateWithLifecycle()
    val me = users[viewModel.myUid]
    val input = viewModel.input
    val focus = remember { FocusRequester() }
    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(ComposerViewModel.MAX_IMAGES)
    ) { uris -> viewModel.addImages(uris) }

    LaunchedEffect(Unit) {
        viewModel.done.collect { onClose() }
    }
    LaunchedEffect(input.query != null) {
        if (input.query != null) viewModel.loadStudents()
    }
    LaunchedEffect(viewModel.loading) {
        if (!viewModel.loading) runCatching { focus.requestFocus() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(stringResource(if (viewModel.editing) R.string.composer_edit_title else R.string.composer_new_title))
                },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.action_close))
                    }
                },
                actions = {
                    Button(
                        onClick = viewModel::submit,
                        enabled = !viewModel.loading && !viewModel.submitting && !viewModel.loadFailed,
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Text(stringResource(if (viewModel.editing) R.string.composer_save else R.string.composer_post))
                    }
                }
            )
        }
    ) { inner ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(inner)
                .consumeWindowInsets(inner)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            if (viewModel.loading || viewModel.submitting) {
                LinearProgressIndicator(Modifier.fillMaxWidth().padding(bottom = 12.dp))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                UserAvatar(
                    name = me?.displayName.orEmpty(),
                    seed = me?.uid.orEmpty(),
                    photoUrl = me?.photoUrl.orEmpty(),
                    size = 44.dp
                )
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(text = me?.displayName.orEmpty(), style = MaterialTheme.typography.titleSmall)
                    Text(
                        text = stringResource(if (viewModel.editing) R.string.composer_editing else R.string.composer_posting_to),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = input.value,
                onValueChange = input::onChange,
                placeholder = { Text(stringResource(R.string.composer_placeholder)) },
                minLines = 6,
                enabled = !viewModel.loading && !viewModel.submitting,
                supportingText = {
                    Text(
                        text = "${input.text.length}/${ComposerViewModel.POST_LIMIT}",
                        textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                modifier = Modifier.fillMaxWidth().focusRequester(focus)
            )
            MentionSuggestionList(
                suggestions = input.suggestions(students, viewModel.myUid),
                onPick = input::pick,
                modifier = Modifier.padding(top = 4.dp)
            )
            if (viewModel.images.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(viewModel.images) { index, image ->
                        Box(Modifier.size(92.dp).clip(RoundedCornerShape(12.dp))) {
                            AsyncImage(
                                model = when (image) {
                                    is ComposerImage.Remote -> image.url
                                    is ComposerImage.Local -> image.uri
                                },
                                contentDescription = stringResource(R.string.post_photo_cd),
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            FilledTonalIconButton(
                                onClick = { viewModel.removeImage(index) },
                                modifier = Modifier.align(Alignment.TopEnd).size(32.dp)
                            ) {
                                Icon(
                                    Icons.Filled.Close,
                                    contentDescription = stringResource(R.string.composer_remove_photo),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    enabled = viewModel.images.size < ComposerViewModel.MAX_IMAGES && !viewModel.submitting
                ) {
                    Icon(Icons.Outlined.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.composer_add_photos))
                }
                if (!viewModel.editing) {
                    OutlinedButton(onClick = viewModel::togglePoll) {
                        Icon(Icons.Outlined.BarChart, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(if (viewModel.pollEnabled) R.string.composer_remove_poll else R.string.composer_add_poll))
                    }
                }
            }
            if (viewModel.pollEnabled && !viewModel.editing) {
                Spacer(Modifier.height(12.dp))
                Text(
                    text = stringResource(R.string.composer_poll_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                viewModel.pollOptions.forEachIndexed { index, option ->
                    Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = option,
                            onValueChange = { viewModel.setPollOption(index, it) },
                            placeholder = { Text(stringResource(R.string.composer_poll_option, index + 1)) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { viewModel.removePollOption(index) },
                            enabled = viewModel.pollOptions.size > ComposerViewModel.MIN_POLL_OPTIONS
                        ) {
                            Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.composer_remove_option))
                        }
                    }
                }
                if (viewModel.pollOptions.size < ComposerViewModel.MAX_POLL_OPTIONS) {
                    TextButton(onClick = viewModel::addPollOption) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.composer_add_option))
                    }
                }
            }
            val error = viewModel.error
            if (error != null) {
                Spacer(Modifier.height(12.dp))
                Text(
                    text = error.asString(),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}
