package com.leafmash.app.core.data

import androidx.annotation.StringRes
import com.leafmash.app.R

object Reactions {
    const val LEAF = "leaf"

    val all: List<String> = listOf(LEAF, "❤️", "😂", "😮", "😢")

    @StringRes
    fun labelRes(value: String?): Int = when (value) {
        null -> R.string.reaction_like
        LEAF -> R.string.reaction_like
        "❤️" -> R.string.reaction_love
        "😂" -> R.string.reaction_haha
        "😮" -> R.string.reaction_wow
        "😢" -> R.string.reaction_sad
        else -> R.string.reaction_reacted
    }

    fun top(reactions: Map<String, String>, count: Int): List<String> =
        reactions.values.groupingBy { it }.eachCount().entries
            .sortedByDescending { it.value }
            .take(count)
            .map { it.key }
}
