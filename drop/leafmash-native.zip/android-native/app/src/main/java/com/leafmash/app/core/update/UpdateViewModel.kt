package com.leafmash.app.core.update

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leafmash.app.BuildConfig
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class UpdateStatus { IDLE, DOWNLOADING, NEEDS_PERMISSION, FAILED }

data class UpdateUiState(
    val kind: UpdateKind = UpdateKind.NONE,
    val config: UpdateConfig? = null,
    val status: UpdateStatus = UpdateStatus.IDLE,
    val percent: Int = 0,
    val dismissed: Boolean = false
) {
    val visible: Boolean get() = kind == UpdateKind.FORCED || (kind == UpdateKind.OPTIONAL && !dismissed)
}

@HiltViewModel
class UpdateViewModel @Inject constructor(
    private val repository: UpdateRepository
) : ViewModel() {

    private val mutableState = MutableStateFlow(UpdateUiState())
    val state: StateFlow<UpdateUiState> = mutableState.asStateFlow()

    private var downloadJob: Job? = null

    init {
        check()
    }

    fun check() {
        viewModelScope.launch {
            val config = repository.fetchConfig() ?: return@launch
            val kind = config.kindFor(BuildConfig.VERSION_CODE)
            mutableState.update { it.copy(config = config, kind = kind) }
        }
    }

    fun dismiss() {
        mutableState.update { it.copy(dismissed = true) }
    }

    fun startUpdate() {
        val config = mutableState.value.config ?: return
        if (downloadJob?.isActive == true) return
        if (!repository.canInstall()) {
            repository.openInstallPermissionSettings()
            mutableState.update { it.copy(status = UpdateStatus.NEEDS_PERMISSION) }
            return
        }
        mutableState.update { it.copy(status = UpdateStatus.DOWNLOADING, percent = 0) }
        downloadJob = viewModelScope.launch {
            when (val result = repository.download(config.apkUrl) { percent -> mutableState.update { it.copy(percent = percent) } }) {
                is DownloadResult.Done -> {
                    mutableState.update { it.copy(status = UpdateStatus.IDLE) }
                    repository.install(result.file)
                }
                DownloadResult.Failed -> mutableState.update { it.copy(status = UpdateStatus.FAILED) }
            }
        }
    }

    fun openDownloadPage() {
        val url = mutableState.value.config?.apkUrl ?: return
        repository.openInBrowser(url)
    }
}
