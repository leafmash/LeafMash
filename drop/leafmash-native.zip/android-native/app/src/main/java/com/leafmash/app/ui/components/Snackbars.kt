package com.leafmash.app.ui.components

import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import com.leafmash.app.core.util.UiText
import kotlinx.coroutines.flow.Flow

@Composable
fun CollectSnackbars(events: Flow<UiText>, host: SnackbarHostState) {
    val context = LocalContext.current
    LaunchedEffect(events) {
        events.collect { host.showSnackbar(it.resolve(context)) }
    }
}
