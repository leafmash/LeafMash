package com.leafmash.app.core.push

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.RemoteInput
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.leafmash.app.core.util.safeCall
import dagger.hilt.android.EntryPointAccessors
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class NotificationActionReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val chatKey = intent.getStringExtra(PushExtras.CHAT_KEY) ?: return
        val appContext = context.applicationContext
        val entry = EntryPointAccessors.fromApplication(appContext, PushEntryPoint::class.java)
        when (intent.action) {
            PushActions.DISMISS -> entry.store().clear(chatKey)
            PushActions.MARK_READ -> markRead(entry, chatKey, intent.getStringExtra(PushExtras.CONVERSATION_ID))
            PushActions.REPLY -> reply(appContext, entry, chatKey, intent)
        }
    }

    private fun markRead(entry: PushEntryPoint, chatKey: String, conversationId: String?) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                safeCall {
                    if (chatKey == ChatKeys.CLASS_CHAT) {
                        entry.messages().markClassChatRead()
                    } else if (conversationId != null) {
                        entry.messages().markDmRead(conversationId)
                    }
                }
                entry.dispatcher().cancelChat(chatKey)
            } finally {
                pending.finish()
            }
        }
    }

    private fun reply(context: Context, entry: PushEntryPoint, chatKey: String, intent: Intent) {
        val text = RemoteInput.getResultsFromIntent(intent)
            ?.getCharSequence(PushExtras.REPLY_TEXT)?.toString()?.trim()
        if (text.isNullOrEmpty()) return
        val request = OneTimeWorkRequestBuilder<ReplyWorker>()
            .setInputData(
                workDataOf(
                    ReplyWorker.KEY_TEXT to text,
                    ReplyWorker.KEY_TARGET_UID to intent.getStringExtra(PushExtras.TARGET_UID).orEmpty(),
                    ReplyWorker.KEY_CLASS_CHAT to (chatKey == ChatKeys.CLASS_CHAT)
                )
            )
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, BACKOFF_SECONDS, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(context).enqueue(request)
        entry.dispatcher().cancelChat(chatKey)
    }

    private companion object {
        const val BACKOFF_SECONDS = 15L
    }
}
