package com.leafmash.app.core.data

import com.leafmash.app.core.config.AppConfig

enum class ProfileBadge { NONE, ADMIN, VERIFIED }

val UserProfile.badge: ProfileBadge
    get() = when {
        AppConfig.isAdminEmail(email) -> ProfileBadge.ADMIN
        AppConfig.isOfficialVerifiedEmail(email) || verified -> ProfileBadge.VERIFIED
        else -> ProfileBadge.NONE
    }

val UserProfile.displayName: String
    get() = when {
        AppConfig.isAdminEmail(email) -> AppConfig.ADMIN_DISPLAY_NAME
        AppConfig.isOfficialVerifiedEmail(email) -> AppConfig.VERIFIED_DISPLAY_NAME
        else -> name.ifBlank { email }
    }
