package com.leafmash.app.feature.notifications

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leafmash.app.R
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.leafmash.app.core.auth.AuthRepository
import com.leafmash.app.core.config.AppConfig
import com.leafmash.app.core.data.UserRepository
import com.leafmash.app.core.data.UserSummary
import com.leafmash.app.core.data.authorFallbackFor
import com.leafmash.app.core.profile.ProfileRepository
import com.leafmash.app.core.util.UiText
import com.leafmash.app.core.util.safeCall
import com.leafmash.app.core.util.toUiText
import com.leafmash.app.feature.notifications.data.ActivityItem
import com.leafmash.app.feature.notifications.data.NoticeAdminRepository
import com.leafmash.app.feature.notifications.data.Notice
import com.leafmash.app.feature.notifications.data.NotificationFeedRepository
import com.leafmash.app.feature.notifications.data.isVisibleTo
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class NoticeRow(val notice: Notice, val poster: UserSummary, val unread: Boolean)

data class NoticeForm(val editingId: String? = null, val text: String = "", val urgent: Boolean = false)

data class ActivityRow(val item: ActivityItem, val actor: UserSummary, val unread: Boolean)

data class NotificationsUiState(
    val noticesLoaded: Boolean = false,
    val activityLoaded: Boolean = false,
    val notices: List<NoticeRow> = emptyList(),
    val activity: List<ActivityRow> = emptyList(),
    val unreadNotices: Int = 0,
    val unreadActivity: Int = 0
)

@HiltViewModel
class NotificationsViewModel @Inject constructor(
    private val feed: NotificationFeedRepository,
    private val userRepository: UserRepository,
    private val profiles: ProfileRepository,
    private val noticeAdmin: NoticeAdminRepository,
    auth: AuthRepository
) : ViewModel() {

    private val myUid = auth.currentUid.orEmpty()

    val isAdmin: StateFlow<Boolean> = profiles.current
        .map { AppConfig.isAdminEmail(it?.email) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    var noticeForm by mutableStateOf<NoticeForm?>(null)
        private set

    var noticeSaving by mutableStateOf(false)
        private set

    var noticeError by mutableStateOf<UiText?>(null)
        private set

    var pendingDeleteId by mutableStateOf<String?>(null)
        private set

    private val eventChannel = Channel<UiText>(Channel.BUFFERED)
    val events: Flow<UiText> = eventChannel.receiveAsFlow()

    private val noticeFlow: Flow<List<Notice>?> = feed.notices
        .onEach { list -> userRepository.ensure(list.map { it.postedByUid }) }
        .map<List<Notice>, List<Notice>?> { it }
        .onStart { emit(null) }

    private val activityFlow: Flow<List<ActivityItem>?> = feed.activity
        .onEach { list -> userRepository.ensure(list.map { it.actorUid }) }
        .map<List<ActivityItem>, List<ActivityItem>?> { it }
        .onStart { emit(null) }

    private val reads: Flow<Triple<Set<String>, Set<String>, Set<String>>> = combine(
        feed.noticeReadIds,
        feed.activityReadIds,
        feed.dismissedIds
    ) { noticeRead, activityRead, dismissed -> Triple(noticeRead, activityRead, dismissed) }

    private val feeds: Flow<Triple<List<Notice>?, List<ActivityItem>?, Map<String, UserSummary>>> = combine(
        noticeFlow,
        activityFlow,
        userRepository.users
    ) { notices, activity, users -> Triple(notices, activity, users) }

    val state: StateFlow<NotificationsUiState> = combine(feeds, reads) { loaded, readSets ->
        val (notices, activity, users) = loaded
        val (noticeRead, activityRead, dismissed) = readSets
        val joined = profiles.current.value?.createdAtMs ?: 0L
        val noticeRows = notices.orEmpty().map { notice ->
            NoticeRow(notice, users[notice.postedByUid] ?: authorFallbackFor(notice.postedByUid), notice.id !in noticeRead)
        }
        val activityRows = activity.orEmpty()
            .filter { it.isVisibleTo(myUid, joined) && it.id !in dismissed }
            .map { item ->
                ActivityRow(item, users[item.actorUid] ?: authorFallbackFor(item.actorUid), item.id !in activityRead)
            }
        NotificationsUiState(
            noticesLoaded = notices != null,
            activityLoaded = activity != null,
            notices = noticeRows,
            activity = activityRows,
            unreadNotices = noticeRows.count { it.unread },
            unreadActivity = activityRows.count { it.unread }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), NotificationsUiState())

    init {
        viewModelScope.launch { feed.ensureLoaded() }
    }

    fun markNoticeRead(id: String) = feed.markNoticeRead(id)

    fun markActivityRead(id: String) = feed.markActivityRead(id)

    fun dismissActivity(id: String) = feed.dismissActivity(id)

    fun markAllRead() {
        val ids = state.value.activity.map { it.item.id }
        feed.markAllActivityRead(ids)
        eventChannel.trySend(UiText.Res(R.string.notif_marked_all))
    }

    fun startNewNotice() {
        noticeForm = NoticeForm()
        noticeError = null
    }

    fun startEditNotice(notice: Notice) {
        noticeForm = NoticeForm(notice.id, notice.text, notice.urgent)
        noticeError = null
    }

    fun changeNotice(transform: (NoticeForm) -> NoticeForm) {
        noticeForm = noticeForm?.let(transform)
    }

    fun dismissNoticeForm() {
        noticeForm = null
        noticeError = null
    }

    fun requestDeleteNotice(id: String?) {
        pendingDeleteId = id
    }

    fun submitNotice() {
        val form = noticeForm ?: return
        val text = form.text.trim()
        if (text.isEmpty()) {
            noticeError = UiText.Res(R.string.notice_error_empty)
            return
        }
        noticeError = null
        noticeSaving = true
        viewModelScope.launch {
            val result = safeCall {
                val id = form.editingId
                if (id == null) noticeAdmin.post(text, form.urgent) else noticeAdmin.update(id, text, form.urgent)
            }
            result
                .onSuccess {
                    noticeForm = null
                    eventChannel.send(UiText.Res(if (form.editingId == null) R.string.notice_posted else R.string.notice_updated))
                }
                .onFailure { noticeError = it.toUiText() }
            noticeSaving = false
        }
    }

    fun confirmDeleteNotice() {
        val id = pendingDeleteId ?: return
        pendingDeleteId = null
        viewModelScope.launch {
            safeCall { noticeAdmin.delete(id) }
                .onSuccess { eventChannel.send(UiText.Res(R.string.notice_deleted)) }
                .onFailure { eventChannel.send(it.toUiText()) }
        }
    }
}
