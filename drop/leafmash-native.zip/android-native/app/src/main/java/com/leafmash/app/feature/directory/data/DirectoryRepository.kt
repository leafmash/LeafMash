package com.leafmash.app.feature.directory.data

import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.leafmash.app.core.config.AppConfig
import com.leafmash.app.core.data.ProfileBadge
import com.leafmash.app.core.data.UserProfile
import com.leafmash.app.core.util.retryWithBackoff
import com.leafmash.app.core.util.snapshotFlow
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

data class Classmate(
    val uid: String,
    val name: String,
    val email: String,
    val roll: String,
    val year: String,
    val session: String,
    val bloodGroup: String,
    val phone: String,
    val hidePhone: Boolean,
    val photoUrl: String,
    val verified: Boolean,
    val lastActiveMs: Long
)

fun Classmate.displayName(): String = when {
    AppConfig.isAdminEmail(email) -> AppConfig.ADMIN_DISPLAY_NAME
    AppConfig.isOfficialVerifiedEmail(email) -> AppConfig.VERIFIED_DISPLAY_NAME
    else -> name.ifBlank { "Classmate" }
}

fun Classmate.badge(): ProfileBadge = when {
    AppConfig.isAdminEmail(email) -> ProfileBadge.ADMIN
    AppConfig.isOfficialVerifiedEmail(email) || verified -> ProfileBadge.VERIFIED
    else -> ProfileBadge.NONE
}

fun DocumentSnapshot.toClassmate(): Classmate = Classmate(
    uid = id,
    name = getString("name").orEmpty(),
    email = getString("email").orEmpty(),
    roll = getString("roll").orEmpty(),
    year = getString("year").orEmpty(),
    session = getString("session").orEmpty(),
    bloodGroup = getString("bloodGroup").orEmpty(),
    phone = getString("phone").orEmpty(),
    hidePhone = getBoolean("hidePhone") == true,
    photoUrl = getString("photoURL").orEmpty(),
    verified = getBoolean("verified") == true,
    lastActiveMs = getTimestamp("lastActive")?.toDate()?.time ?: 0L
)

fun DocumentSnapshot.toUserProfileOrNull(): UserProfile? {
    if (!exists()) return null
    val links = (get("socialLinks") as? List<*>).orEmpty().filterIsInstance<String>().filter { it.isNotBlank() }
        .ifEmpty { listOfNotNull(getString("socialLink")?.takeIf { it.isNotBlank() }) }
    return UserProfile(
        uid = id,
        name = getString("name").orEmpty(),
        roll = getString("roll").orEmpty(),
        bloodGroup = getString("bloodGroup").orEmpty(),
        gender = getString("gender").orEmpty(),
        phone = getString("phone").orEmpty(),
        email = getString("email").orEmpty(),
        photoUrl = getString("photoURL").orEmpty(),
        bio = getString("bio").orEmpty(),
        session = getString("session").orEmpty(),
        year = getString("year").orEmpty(),
        hometown = getString("hometown").orEmpty(),
        address = getString("address").orEmpty(),
        socialLinks = links,
        hidePhone = getBoolean("hidePhone") == true,
        hideEmail = getBoolean("hideEmail") == true,
        photoGuard = getBoolean("photoGuard") == true,
        verified = getBoolean("verified") == true,
        profileIncomplete = getBoolean("profileIncomplete") == true,
        nameChangedAtMs = getTimestamp("nameChangedAt")?.toDate()?.time ?: 0L,
        createdAtMs = getTimestamp("createdAt")?.toDate()?.time ?: 0L
    )
}

@Singleton
class DirectoryRepository @Inject constructor(
    private val firestore: FirebaseFirestore
) {

    fun observe(limit: Long): Flow<List<Classmate>> =
        firestore.collection("users")
            .limit(limit)
            .snapshotFlow()
            .map { snapshot ->
                snapshot.documents.map { it.toClassmate() }.sortedBy { it.name.lowercase() }
            }
            .retryWithBackoff()

    suspend fun loadAll(limit: Long = 500L): List<Classmate> =
        firestore.collection("users").limit(limit).get().await()
            .documents.map { it.toClassmate() }
            .filter { it.name.isNotBlank() }
            .sortedBy { it.name.lowercase() }

    suspend fun fetchProfile(uid: String): UserProfile? =
        firestore.collection("users").document(uid).get().await().toUserProfileOrNull()

    suspend fun setVerified(uid: String, verified: Boolean) {
        firestore.collection("users").document(uid).update("verified", verified).await()
    }
}
