package com.leafmash.app.feature.stories

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.leafmash.app.R
import com.leafmash.app.core.data.Story
import com.leafmash.app.core.data.StoryGroup
import com.leafmash.app.core.data.UserRepository
import com.leafmash.app.core.data.UserSummary
import com.leafmash.app.core.util.UiText
import com.leafmash.app.core.util.toUiText
import com.leafmash.app.core.notify.ActivityLogger
import com.leafmash.app.core.notify.PushTrigger
import com.leafmash.app.feature.stories.data.StoryRepository
import com.leafmash.app.feature.wall.data.PostImageUploader
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@HiltViewModel
class StoriesViewModel @Inject constructor(
    private val repository: StoryRepository,
    private val uploader: PostImageUploader,
    private val userRepository: UserRepository,
    private val auth: FirebaseAuth,
    private val activity: ActivityLogger,
    private val push: PushTrigger
) : ViewModel() {

    val myUid: String get() = auth.currentUser?.uid.orEmpty()

    val users: StateFlow<Map<String, UserSummary>> = userRepository.users

    private val eventChannel = Channel<UiText>(Channel.BUFFERED)
    val events: Flow<UiText> = eventChannel.receiveAsFlow()

    private val uploadingState = MutableStateFlow(false)
    val uploading: StateFlow<Boolean> = uploadingState.asStateFlow()

    private val viewRequested = HashSet<String>()
    private val likeNotified = HashSet<String>()

    val groups: StateFlow<List<StoryGroup>> = repository.observeActive()
        .map { list -> group(list) }
        .onEach { grouped -> userRepository.ensure(grouped.map { it.authorUid }) }
        .catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private fun group(list: List<Story>): List<StoryGroup> {
        val me = myUid
        val now = System.currentTimeMillis()
        return list
            .filter { it.expiresAtMs > now }
            .groupBy { it.authorUid }
            .map { (uid, stories) -> StoryGroup(uid, stories.sortedBy { it.createdAtMs }) }
            .sortedWith(
                compareByDescending<StoryGroup> { it.authorUid == me }
                    .thenByDescending { it.hasUnseen(me) }
                    .thenByDescending { it.latestMs }
            )
    }

    fun ensureUsers(uids: Collection<String>) {
        userRepository.ensure(uids)
    }

    fun share(uri: Uri, caption: String, onDone: () -> Unit) {
        val uid = myUid
        if (uid.isEmpty() || uploadingState.value) return
        uploadingState.value = true
        viewModelScope.launch {
            val upload = uploader.upload(listOf(uri))
            val url = upload.getOrNull()?.firstOrNull()
            if (url == null) {
                eventChannel.trySend(upload.exceptionOrNull()?.toUiText() ?: UiText.Res(R.string.err_generic))
            } else {
                repository.publish(uid, url, caption.trim().take(StoryRepository.CAPTION_LIMIT))
                    .onSuccess {
                        eventChannel.trySend(UiText.Res(R.string.story_posted))
                        onDone()
                    }
                    .onFailure { eventChannel.trySend(it.toUiText()) }
            }
            uploadingState.value = false
        }
    }

    fun markViewed(story: Story) {
        val uid = myUid
        if (uid.isEmpty() || story.authorUid == uid || uid in story.viewedBy) return
        if (!viewRequested.add(story.id)) return
        viewModelScope.launch { repository.markViewed(story.id, uid) }
    }

    fun toggleLike(story: Story) {
        val uid = myUid
        if (uid.isEmpty() || story.authorUid == uid) return
        val liked = uid !in story.likedBy
        viewModelScope.launch {
            repository.setLiked(story.id, uid, liked)
                .onSuccess {
                    if (liked && likeNotified.add(story.id)) {
                        activity.log("story-like", targetUid = story.authorUid)
                        push.send("story-like", targetUid = story.authorUid)
                    }
                }
                .onFailure { eventChannel.trySend(it.toUiText()) }
        }
    }

    fun delete(story: Story) {
        viewModelScope.launch {
            repository.delete(story.id)
                .onSuccess { eventChannel.trySend(UiText.Res(R.string.story_deleted)) }
                .onFailure { eventChannel.trySend(it.toUiText()) }
        }
    }
}
