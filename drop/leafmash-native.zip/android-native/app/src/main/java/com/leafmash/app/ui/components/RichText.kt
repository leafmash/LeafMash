package com.leafmash.app.ui.components

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material3.TextButton
import com.leafmash.app.R
import com.leafmash.app.core.data.MentionRef
import com.leafmash.app.ui.navigation.LocalOpenProfile

private val HASHTAG_REGEX = Regex("#([A-Za-z0-9_\\u0980-\\u09FF]{2,40})")

private data class Segment(val start: Int, val end: Int, val tag: String?, val uid: String? = null)

private fun buildRichString(
    text: String,
    mentions: List<MentionRef>,
    mentionStyle: SpanStyle,
    tagStyle: SpanStyle,
    onHashtag: (String) -> Unit,
    onMention: (String) -> Unit
): AnnotatedString {
    val segments = mutableListOf<Segment>()
    mentions.distinctBy { it.uid }.sortedByDescending { it.name.length }.forEach { mention ->
        val token = "@" + mention.name
        var from = 0
        while (true) {
            val index = text.indexOf(token, from)
            if (index < 0) break
            val end = index + token.length
            val boundary = end >= text.length || text[end].isWhitespace() || text[end] in ".,!?;:)"
            if (boundary && segments.none { index < it.end && end > it.start }) {
                segments.add(Segment(index, end, null, mention.uid))
            }
            from = end
        }
    }
    HASHTAG_REGEX.findAll(text).forEach { match ->
        val start = match.range.first
        val end = match.range.last + 1
        if (segments.none { start < it.end && end > it.start }) {
            segments.add(Segment(start, end, match.groupValues[1].lowercase()))
        }
    }
    segments.sortBy { it.start }
    return buildAnnotatedString {
        var cursor = 0
        segments.forEach { segment ->
            append(text.substring(cursor, segment.start))
            val piece = text.substring(segment.start, segment.end)
            val tag = segment.tag
            val mentionUid = segment.uid
            if (tag == null && mentionUid != null) {
                pushLink(
                    LinkAnnotation.Clickable(
                        tag = mentionUid,
                        styles = TextLinkStyles(style = mentionStyle),
                        linkInteractionListener = { onMention(mentionUid) }
                    )
                )
                append(piece)
                pop()
            } else if (tag == null) {
                pushStyle(mentionStyle)
                append(piece)
                pop()
            } else {
                pushLink(
                    LinkAnnotation.Clickable(
                        tag = tag,
                        styles = TextLinkStyles(style = tagStyle),
                        linkInteractionListener = { onHashtag(tag) }
                    )
                )
                append(piece)
                pop()
            }
            cursor = segment.end
        }
        append(text.substring(cursor))
    }
}

@Composable
fun RichText(
    text: String,
    mentions: List<MentionRef>,
    modifier: Modifier = Modifier,
    style: TextStyle = MaterialTheme.typography.bodyLarge,
    maxLines: Int = Int.MAX_VALUE,
    onHashtagClick: (String) -> Unit = {},
    onTextLayout: (TextLayoutResult) -> Unit = {}
) {
    val primary = MaterialTheme.colorScheme.primary
    val mentionStyle = remember(primary) { SpanStyle(color = primary, fontWeight = FontWeight.SemiBold) }
    val tagStyle = remember(primary) { SpanStyle(color = primary, fontWeight = FontWeight.Medium) }
    val currentOnHashtag by rememberUpdatedState(onHashtagClick)
    val currentOnMention by rememberUpdatedState(LocalOpenProfile.current)
    val annotated = remember(text, mentions, mentionStyle, tagStyle) {
        buildRichString(text, mentions, mentionStyle, tagStyle, { currentOnHashtag(it) }, { currentOnMention(it) })
    }
    Text(
        text = annotated,
        modifier = modifier,
        style = style,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
        onTextLayout = onTextLayout
    )
}

@Composable
fun ExpandableRichText(
    text: String,
    mentions: List<MentionRef>,
    modifier: Modifier = Modifier,
    collapsedLines: Int = 6,
    onHashtagClick: (String) -> Unit = {}
) {
    var expanded by rememberSaveable(text) { mutableStateOf(false) }
    var overflowing by remember(text) { mutableStateOf(false) }
    androidx.compose.foundation.layout.Column(modifier) {
        RichText(
            text = text,
            mentions = mentions,
            maxLines = if (expanded) Int.MAX_VALUE else collapsedLines,
            onHashtagClick = onHashtagClick,
            onTextLayout = { if (!expanded) overflowing = it.hasVisualOverflow }
        )
        if (overflowing || expanded) {
            TextButton(onClick = { expanded = !expanded }) {
                Text(stringResource(if (expanded) R.string.see_less else R.string.see_more))
            }
        }
    }
}
