package com.leafmash.app.feature.admin

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leafmash.app.R
import com.leafmash.app.ui.components.CollectSnackbars
import com.leafmash.app.ui.components.rememberTimeAgo

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    onBack: () -> Unit,
    onOpenPost: (String) -> Unit,
    viewModel: ReportsViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val isAdmin by viewModel.isAdmin.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    CollectSnackbars(viewModel.events, snackbar)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.reports_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { inner ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(inner)
        ) {
            when {
                !isAdmin -> Text(
                    text = stringResource(R.string.admin_only),
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(32.dp)
                )
                state.loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                state.items.isEmpty() -> Text(
                    text = stringResource(R.string.reports_empty),
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(32.dp)
                )
                else -> LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(state.items, key = { it.id }) { report ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(14.dp)) {
                                Text(
                                    text = report.postText.ifBlank { stringResource(R.string.reports_text_unavailable) },
                                    style = MaterialTheme.typography.bodyMedium,
                                    maxLines = 5
                                )
                                if (report.reason.isNotBlank()) {
                                    Text(
                                        text = stringResource(R.string.reports_reason, report.reason),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.padding(top = 6.dp)
                                    )
                                }
                                Text(
                                    text = stringResource(
                                        R.string.reports_by,
                                        report.reportedByName.ifBlank { stringResource(R.string.reports_classmate) },
                                        rememberTimeAgo(report.createdAtMs)
                                    ),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(top = 6.dp)
                                )
                                val busy = viewModel.busyId == report.id
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.padding(top = 10.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = { onOpenPost(report.postId) },
                                        enabled = report.postId.isNotEmpty()
                                    ) { Text(stringResource(R.string.reports_view)) }
                                    OutlinedButton(onClick = { viewModel.dismiss(report) }, enabled = !busy) {
                                        Text(stringResource(R.string.reports_dismiss))
                                    }
                                    TextButton(onClick = { viewModel.requestRemove(report) }, enabled = !busy) {
                                        Text(stringResource(R.string.reports_remove), color = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    viewModel.pendingRemove?.let {
        AlertDialog(
            onDismissRequest = { viewModel.requestRemove(null) },
            title = { Text(stringResource(R.string.reports_remove_title)) },
            text = { Text(stringResource(R.string.reports_remove_text)) },
            confirmButton = {
                TextButton(onClick = viewModel::confirmRemove) { Text(stringResource(R.string.reports_remove)) }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.requestRemove(null) }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
}
