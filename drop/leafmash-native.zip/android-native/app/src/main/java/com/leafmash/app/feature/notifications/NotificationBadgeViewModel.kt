package com.leafmash.app.feature.notifications

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leafmash.app.feature.notifications.data.NotificationFeedRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

@HiltViewModel
class NotificationBadgeViewModel @Inject constructor(
    feed: NotificationFeedRepository
) : ViewModel() {
    val unread: StateFlow<Int> = feed.unreadCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)
}
