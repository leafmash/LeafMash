package com.leafmash.app.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leafmash.app.R
import com.leafmash.app.core.update.UpdateKind
import com.leafmash.app.core.update.UpdateStatus
import com.leafmash.app.core.update.UpdateUiState
import com.leafmash.app.core.update.UpdateViewModel

@Composable
fun UpdateGate(
    viewModel: UpdateViewModel = hiltViewModel(),
    content: @Composable () -> Unit
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    if (state.kind == UpdateKind.FORCED) {
        ForcedUpdateScreen(
            state = state,
            onUpdate = viewModel::startUpdate,
            onOpenPage = viewModel::openDownloadPage
        )
        return
    }
    content()
    if (state.visible) {
        OptionalUpdateDialog(
            state = state,
            onUpdate = viewModel::startUpdate,
            onLater = viewModel::dismiss
        )
    }
}

@Composable
private fun ForcedUpdateScreen(
    state: UpdateUiState,
    onUpdate: () -> Unit,
    onOpenPage: () -> Unit
) {
    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Filled.SystemUpdate,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(16.dp))
            Text(
                text = stringResource(R.string.update_required_title),
                style = MaterialTheme.typography.headlineSmall,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.update_required_text),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            UpdateExtras(state)
            Spacer(Modifier.height(24.dp))
            Button(
                onClick = onUpdate,
                enabled = state.status != UpdateStatus.DOWNLOADING,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(stringResource(R.string.update_now))
            }
            if (state.status == UpdateStatus.FAILED || state.status == UpdateStatus.NEEDS_PERMISSION) {
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onOpenPage, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.update_open_browser))
                }
            }
        }
    }
}

@Composable
private fun UpdateExtras(state: UpdateUiState) {
    val changelog = state.config?.changelog.orEmpty()
    if (changelog.isNotBlank()) {
        Spacer(Modifier.height(12.dp))
        Text(
            text = changelog,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
    when (state.status) {
        UpdateStatus.DOWNLOADING -> {
            Spacer(Modifier.height(16.dp))
            LinearProgressIndicator(
                progress = { state.percent / 100f },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.update_downloading, state.percent),
                style = MaterialTheme.typography.bodySmall
            )
        }
        UpdateStatus.NEEDS_PERMISSION -> {
            Spacer(Modifier.height(16.dp))
            Text(
                text = stringResource(R.string.update_permission),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
                textAlign = TextAlign.Center
            )
        }
        UpdateStatus.FAILED -> {
            Spacer(Modifier.height(16.dp))
            Text(
                text = stringResource(R.string.update_failed),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
                textAlign = TextAlign.Center
            )
        }
        UpdateStatus.IDLE -> Unit
    }
}

@Composable
private fun OptionalUpdateDialog(
    state: UpdateUiState,
    onUpdate: () -> Unit,
    onLater: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onLater,
        title = { Text(stringResource(R.string.update_available_title)) },
        text = {
            Column {
                Text(stringResource(R.string.update_available_text))
                UpdateExtras(state)
            }
        },
        confirmButton = {
            TextButton(onClick = onUpdate, enabled = state.status != UpdateStatus.DOWNLOADING) {
                Text(stringResource(R.string.update_now))
            }
        },
        dismissButton = {
            TextButton(onClick = onLater) { Text(stringResource(R.string.update_later)) }
        }
    )
}
