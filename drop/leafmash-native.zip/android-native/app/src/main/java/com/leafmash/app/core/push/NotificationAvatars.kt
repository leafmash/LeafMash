package com.leafmash.app.core.push

import android.content.Context
import androidx.core.graphics.drawable.IconCompat
import androidx.core.graphics.drawable.toBitmap
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import coil.transform.CircleCropTransformation
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.withTimeoutOrNull

object NotificationAvatars {

    private const val SIZE_PX = 192
    private const val TIMEOUT_MS = 6_000L

    suspend fun load(context: Context, url: String): IconCompat? {
        if (url.isBlank()) return null
        return try {
            withTimeoutOrNull(TIMEOUT_MS) {
                val request = ImageRequest.Builder(context)
                    .data(url)
                    .size(SIZE_PX)
                    .allowHardware(false)
                    .transformations(CircleCropTransformation())
                    .build()
                val result = context.imageLoader.execute(request)
                val drawable = (result as? SuccessResult)?.drawable
                drawable?.let { IconCompat.createWithBitmap(it.toBitmap()) }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }
}
