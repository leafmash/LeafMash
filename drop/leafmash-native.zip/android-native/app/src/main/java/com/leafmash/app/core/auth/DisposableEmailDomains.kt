package com.leafmash.app.core.auth

object DisposableEmailDomains {

    private val BLOCKED = setOf(
        "10minutemail.com", "10minutemail.net", "20minutemail.com", "guerrillamail.com",
        "guerrillamail.net", "guerrillamail.org", "guerrillamail.biz", "guerrillamail.de",
        "guerrillamail.info", "guerrillamailblock.com", "sharklasers.com", "grr.la",
        "pokemail.net", "spam4.me", "mailinator.com", "mailinator.net",
        "mailinator.org", "mailnesia.com", "mailcatch.com", "mailnull.com",
        "jetable.org", "tempmail.com", "temp-mail.org", "temp-mail.io",
        "tempmailo.com", "tempinbox.com", "throwawaymail.com", "throwam.com",
        "yopmail.com", "yopmail.net", "yopmail.fr", "trashmail.com",
        "trashmail.me", "trashmail.net", "trash-mail.com", "wegwerfmail.de",
        "wegwerfmail.net", "wegwerfmail.org", "getnada.com", "getairmail.com",
        "fakeinbox.com", "fakemailgenerator.com", "dispostable.com", "maildrop.cc",
        "mintemail.com", "mohmal.com", "moakt.com", "emailondeck.com",
        "discard.email", "discardmail.com", "1secmail.com", "1secmail.net",
        "1secmail.org", "crazymailing.com", "harakirimail.com", "spamgourmet.com",
        "incognitomail.com", "anonbox.net", "luxusmail.org", "mailforspam.com",
        "mytrashmail.com", "burnermail.io", "mytemp.email", "inboxkitten.com",
        "nada.email"
    )

    fun isDisposable(email: String): Boolean {
        val domain = email.substringAfter('@', "").trim().lowercase()
        if (domain.isEmpty()) return false
        if (domain in BLOCKED) return true
        return BLOCKED.any { domain.endsWith(".$it") }
    }
}
