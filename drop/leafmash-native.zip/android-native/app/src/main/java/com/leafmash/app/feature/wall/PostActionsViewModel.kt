package com.leafmash.app.feature.wall

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.leafmash.app.R
import com.leafmash.app.core.config.AppConfig
import com.leafmash.app.core.data.Post
import com.leafmash.app.core.data.UserRepository
import com.leafmash.app.core.data.UserSummary
import com.leafmash.app.core.util.UiText
import com.leafmash.app.core.util.toUiText
import com.leafmash.app.feature.wall.data.PostActions
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch

abstract class PostActionsViewModel(
    private val actions: PostActions,
    private val userRepository: UserRepository,
    private val auth: FirebaseAuth
) : ViewModel() {

    private val eventChannel = Channel<UiText>(Channel.BUFFERED)
    val events: Flow<UiText> = eventChannel.receiveAsFlow()

    val users: StateFlow<Map<String, UserSummary>> = userRepository.users

    val myUid: String get() = auth.currentUser?.uid.orEmpty()

    val isAdmin: Boolean get() = AppConfig.isAdminEmail(auth.currentUser?.email)

    protected fun emit(text: UiText) {
        eventChannel.trySend(text)
    }

    fun ensureUsers(uids: Collection<String>) {
        userRepository.ensure(uids)
    }

    fun reactToPost(post: Post, emoji: String) {
        launchAction { actions.reactToPost(post, emoji) }
    }

    fun vote(post: Post, optionId: String) {
        launchAction { actions.vote(post, optionId) }
    }

    fun togglePin(post: Post) {
        launchAction { actions.setPinned(post, !post.pinned) }
    }

    fun deletePost(post: Post, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            actions.delete(post.id)
                .onSuccess {
                    emit(UiText.Res(R.string.post_deleted))
                    onDone()
                }
                .onFailure { emit(it.toUiText()) }
        }
    }

    fun report(post: Post, reason: String) {
        viewModelScope.launch {
            actions.report(post, reason)
                .onSuccess { emit(UiText.Res(R.string.report_sent)) }
                .onFailure { emit(it.toUiText()) }
        }
    }

    fun toggleSaved(postId: String, currentlySaved: Boolean) {
        launchAction { actions.setSaved(postId, !currentlySaved) }
    }

    private fun launchAction(block: suspend () -> Result<*>) {
        viewModelScope.launch {
            block().onFailure { emit(it.toUiText()) }
        }
    }
}
