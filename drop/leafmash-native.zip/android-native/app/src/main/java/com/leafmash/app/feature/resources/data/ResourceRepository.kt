package com.leafmash.app.feature.resources.data

import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.leafmash.app.core.network.ApiClient
import com.leafmash.app.core.network.ApiException
import com.leafmash.app.core.notify.ActivityLogger
import com.leafmash.app.core.notify.PushTrigger
import com.leafmash.app.core.util.retryWithBackoff
import com.leafmash.app.core.util.snapshotFlow
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.put

val ResourceCategories = listOf(
    "Physical Geography",
    "Climatology",
    "Human Geography",
    "Cartography",
    "General / Others"
)

data class Resource(
    val id: String,
    val title: String,
    val category: String,
    val link: String,
    val sourceType: String,
    val fileExt: String,
    val contributorName: String,
    val contributorUid: String,
    val openCount: Long,
    val createdAtMs: Long
)

fun DocumentSnapshot.toResource(): Resource = Resource(
    id = id,
    title = getString("title").orEmpty(),
    category = getString("category").orEmpty(),
    link = getString("link").orEmpty(),
    sourceType = getString("sourceType").orEmpty().ifEmpty { "link" },
    fileExt = getString("fileExt").orEmpty(),
    contributorName = getString("contributorName").orEmpty(),
    contributorUid = getString("contributorUid").orEmpty(),
    openCount = getLong("openCount") ?: 0L,
    createdAtMs = getTimestamp("createdAt")?.toDate()?.time ?: 0L
)

@Singleton
class ResourceRepository @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val api: ApiClient,
    private val activity: ActivityLogger,
    private val push: PushTrigger
) {

    fun observe(limit: Long): Flow<List<Resource>> =
        firestore.collection("resources")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(limit)
            .snapshotFlow()
            .map { snapshot -> snapshot.documents.map { it.toResource() } }
            .retryWithBackoff()

    suspend fun byContributor(uid: String): List<Resource> =
        firestore.collection("resources").whereEqualTo("contributorUid", uid).get().await()
            .documents.map { it.toResource() }
            .sortedByDescending { it.createdAtMs }

    suspend fun create(
        title: String,
        category: String,
        link: String,
        sourceType: String,
        fileExt: String?,
        fileName: String?
    ) {
        val response = api.call(
            "create-resource",
            buildJsonObject {
                put("title", title)
                put("category", category)
                put("link", link)
                put("sourceType", sourceType)
                if (fileExt.isNullOrEmpty()) put("fileExt", JsonNull) else put("fileExt", fileExt)
                if (fileName.isNullOrEmpty()) put("fileName", JsonNull) else put("fileName", fileName)
            }
        ).getOrThrow()
        val id = (response["id"] as? JsonPrimitive)?.contentOrNull ?: throw ApiException("Couldn't share resource.")
        activity.log("resource", title, resourceId = id)
        push.send(type = "resource", text = title, resourceId = id)
    }

    suspend fun edit(id: String, title: String, category: String, link: String) {
        api.call(
            "edit-resource",
            buildJsonObject {
                put("resId", id)
                put("title", title)
                put("category", category)
                put("link", link)
            }
        ).getOrThrow()
    }

    suspend fun delete(id: String) {
        firestore.collection("resources").document(id).delete().await()
        activity.deleteForResource(id)
    }

    suspend fun bumpOpenCount(id: String) {
        runCatching {
            firestore.collection("resources").document(id)
                .update("openCount", FieldValue.increment(1))
                .await()
        }
    }
}
