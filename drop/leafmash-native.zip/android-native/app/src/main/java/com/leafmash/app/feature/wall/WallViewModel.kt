package com.leafmash.app.feature.wall

import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.leafmash.app.core.data.Post
import com.leafmash.app.core.data.UserRepository
import com.leafmash.app.core.util.UiText
import com.leafmash.app.core.util.toUiText
import com.leafmash.app.feature.wall.data.BookmarkRepository
import com.leafmash.app.feature.wall.data.PendingPost
import com.leafmash.app.feature.wall.data.PostActions
import com.leafmash.app.feature.wall.data.PostPublisher
import com.leafmash.app.feature.wall.data.PostRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

data class FeedState(
    val loading: Boolean = true,
    val posts: List<Post> = emptyList(),
    val hasMore: Boolean = true,
    val loadingMore: Boolean = false,
    val refreshing: Boolean = false,
    val error: UiText? = null
)

@HiltViewModel
class WallViewModel @Inject constructor(
    private val posts: PostRepository,
    private val publisher: PostPublisher,
    bookmarks: BookmarkRepository,
    actions: PostActions,
    userRepository: UserRepository,
    auth: FirebaseAuth
) : PostActionsViewModel(actions, userRepository, auth) {

    private val feedState = MutableStateFlow(FeedState())
    val feed: StateFlow<FeedState> = feedState.asStateFlow()

    private val countState = MutableStateFlow<Map<String, Int>>(emptyMap())
    val commentCounts: StateFlow<Map<String, Int>> = countState.asStateFlow()

    val pending: StateFlow<List<PendingPost>> = publisher.pending

    val savedIds: StateFlow<Set<String>> = bookmarks.observe()
        .map { list -> list.filter { it.type == "post" }.map { it.postId }.toSet() }
        .catch { emit(emptySet()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptySet())

    val allEvents: Flow<UiText> = merge(events, publisher.events)

    private val limit = MutableStateFlow(PAGE_SIZE)
    private var observeJob: Job? = null
    private val countRequested = HashSet<String>()

    init {
        observe()
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    private fun observe() {
        observeJob?.cancel()
        observeJob = viewModelScope.launch {
            limit.flatMapLatest { size -> posts.observePosts(size).map { size to it } }
                .catch { error ->
                    feedState.update { it.copy(loading = false, loadingMore = false, refreshing = false, error = error.toUiText()) }
                }
                .collect { (size, list) ->
                    feedState.update {
                        it.copy(
                            loading = false,
                            posts = list.sortedByDescending { post -> post.pinned },
                            hasMore = list.size >= size,
                            loadingMore = false,
                            error = null
                        )
                    }
                    ensureUsers(list.map { post -> post.authorUid })
                    list.filter { post -> post.commentCount == null }.forEach { post -> requestCount(post.id) }
                }
        }
    }

    private fun requestCount(postId: String) {
        if (!countRequested.add(postId)) return
        viewModelScope.launch {
            val count = posts.countComments(postId)
            countState.update { it + (postId to count) }
        }
    }

    fun loadMore() {
        val state = feedState.value
        if (state.loading || state.loadingMore || !state.hasMore || state.error != null) return
        feedState.update { it.copy(loadingMore = true) }
        limit.value = limit.value + PAGE_SIZE
    }

    fun refresh() {
        if (feedState.value.refreshing) return
        feedState.update { it.copy(refreshing = true) }
        viewModelScope.launch {
            try {
                withTimeoutOrNull(REFRESH_TIMEOUT_MS) {
                    posts.fetchFirstPage(limit.value).onFailure { emit(it.toUiText()) }
                }
                countRequested.clear()
                feedState.value.posts.forEach { post -> requestCount(post.id) }
            } finally {
                feedState.update { it.copy(refreshing = false) }
            }
        }
    }

    fun retry() {
        feedState.update { it.copy(loading = true, error = null) }
        observe()
    }

    fun retryPending(clientId: String) {
        publisher.retry(clientId)
    }

    fun discardPending(clientId: String) {
        publisher.discard(clientId)
    }

    private companion object {
        const val PAGE_SIZE = 20
        const val REFRESH_TIMEOUT_MS = 4_000L
    }
}
