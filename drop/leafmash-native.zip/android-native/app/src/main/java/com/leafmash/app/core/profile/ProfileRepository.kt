package com.leafmash.app.core.profile

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.leafmash.app.core.data.ProfileForm
import com.leafmash.app.core.data.UserProfile
import com.leafmash.app.core.network.ApiClient
import com.leafmash.app.core.network.ApiException
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put

private val Context.profileCacheStore by preferencesDataStore(name = "profile_cache")

sealed interface ResolveResult {
    data class Loaded(val profile: UserProfile) : ResolveResult
    data class Rejected(val message: String) : ResolveResult
    data class Failed(val error: ApiException) : ResolveResult
}

@Singleton
class ProfileRepository @Inject constructor(
    @ApplicationContext context: Context,
    private val api: ApiClient,
    private val json: Json
) {
    private val store = context.profileCacheStore

    private val currentState = MutableStateFlow<UserProfile?>(null)
    val current: StateFlow<UserProfile?> = currentState.asStateFlow()

    suspend fun loadCached(uid: String): UserProfile? {
        val raw = store.data.first()[cacheKey(uid)] ?: return null
        return runCatching { UserProfile.fromJson(json.parseToJsonElement(raw).jsonObject, uid) }.getOrNull()
    }

    suspend fun setCurrent(profile: UserProfile, persist: Boolean = true) {
        currentState.value = profile
        if (persist && profile.uid.isNotEmpty()) {
            store.edit { prefs -> prefs[cacheKey(profile.uid)] = profile.toJson().toString() }
        }
    }

    fun clearCurrent() {
        currentState.value = null
    }

    suspend fun clear(uid: String) {
        currentState.value = null
        store.edit { prefs -> prefs.remove(cacheKey(uid)) }
    }

    suspend fun resolve(uid: String): ResolveResult {
        val result = api.call("resolve-profile")
        val body = result.getOrElse { error ->
            return ResolveResult.Failed(error as? ApiException ?: ApiException(error.message ?: "Request failed."))
        }
        val status = (body["status"] as? JsonPrimitive)?.contentOrNull.orEmpty()
        val profileObject = body["profile"] as? JsonObject
        return when (status) {
            "existing", "new" -> if (profileObject != null) {
                ResolveResult.Loaded(UserProfile.fromJson(profileObject, uid))
            } else {
                ResolveResult.Failed(ApiException("Unexpected response from the server."))
            }
            "conflict", "blocked" -> ResolveResult.Rejected(
                (body["message"] as? JsonPrimitive)?.contentOrNull ?: "Couldn't sign you in."
            )
            else -> ResolveResult.Failed(ApiException("Unexpected response from the server."))
        }
    }

    suspend fun update(previous: UserProfile, form: ProfileForm, photoUrl: String?): Result<UserProfile> {
        val payload = buildJsonObject {
            put("name", form.name.trim())
            put("roll", form.roll.trim())
            put("blood", form.blood)
            put("gender", form.gender)
            put("phone", form.phone.trim())
            put("year", form.year)
            put("session", form.session.trim())
            put("hometown", form.hometown.trim())
            put("address", form.address.trim())
            put("bio", form.bio.trim())
            put("socialLinks", JsonArray(form.socialLinks.map { it.trim() }.filter { it.isNotEmpty() }.map { JsonPrimitive(it) }))
            put("hidePhone", form.hidePhone)
            put("hideEmail", form.hideEmail)
            put("photoGuard", form.photoGuard)
            if (photoUrl != null) put("photoURL", photoUrl)
        }
        val nameChanged = form.name.trim().isNotEmpty() && form.name.trim() != previous.name
        return api.call("update-profile", payload).mapCatching { body ->
            val profileObject = body["profile"] as? JsonObject
                ?: throw ApiException("Unexpected response from the server.")
            val parsed = UserProfile.fromJson(profileObject, previous.uid)
            val merged = parsed.copy(
                uid = previous.uid,
                verified = previous.verified,
                nameChangedAtMs = when {
                    nameChanged -> System.currentTimeMillis()
                    parsed.nameChangedAtMs > 0L -> parsed.nameChangedAtMs
                    else -> previous.nameChangedAtMs
                },
                createdAtMs = if (parsed.createdAtMs > 0L) parsed.createdAtMs else previous.createdAtMs,
                photoUrl = parsed.photoUrl.ifEmpty { previous.photoUrl }
            )
            setCurrent(merged)
            merged
        }
    }

    private fun cacheKey(uid: String) = stringPreferencesKey("profile_$uid")
}
