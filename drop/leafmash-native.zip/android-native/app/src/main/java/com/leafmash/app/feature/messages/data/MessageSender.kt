package com.leafmash.app.feature.messages.data

import com.leafmash.app.core.network.ApiClient
import com.leafmash.app.core.notify.PushTrigger
import com.leafmash.app.core.profile.ProfileRepository
import com.leafmash.app.core.upload.AudioUploader
import com.leafmash.app.core.util.AppScope
import com.leafmash.app.core.util.UiText
import com.leafmash.app.core.util.toUiText
import java.io.File
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.put

sealed interface ChatTarget {
    data class Dm(val uid: String) : ChatTarget
    data object ClassChat : ChatTarget
}

enum class PendingStatus { SENDING, FAILED, SENT }

data class PendingMessage(
    val id: String,
    val target: ChatTarget,
    val text: String,
    val audioPath: String?,
    val durationSec: Int,
    val createdAtMs: Long,
    val status: PendingStatus,
    val realId: String? = null,
    val error: UiText? = null
)

@Singleton
class MessageSender @Inject constructor(
    private val api: ApiClient,
    private val repository: MessagesRepository,
    private val audioUploader: AudioUploader,
    private val pushTrigger: PushTrigger,
    private val profiles: ProfileRepository,
    private val appScope: AppScope
) {

    private val pendingState = MutableStateFlow<List<PendingMessage>>(emptyList())
    val pending: StateFlow<List<PendingMessage>> = pendingState.asStateFlow()

    private val gate = Mutex()
    private var lastSendAtMs = 0L

    fun sendText(target: ChatTarget, text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        enqueue(
            PendingMessage(
                id = newId(),
                target = target,
                text = clean,
                audioPath = null,
                durationSec = 0,
                createdAtMs = System.currentTimeMillis(),
                status = PendingStatus.SENDING
            )
        )
    }

    fun sendVoice(target: ChatTarget, file: File, durationSec: Int) {
        enqueue(
            PendingMessage(
                id = newId(),
                target = target,
                text = "",
                audioPath = file.absolutePath,
                durationSec = durationSec.coerceIn(1, MAX_VOICE_SECONDS),
                createdAtMs = System.currentTimeMillis(),
                status = PendingStatus.SENDING
            )
        )
    }

    fun retry(id: String) {
        val message = pendingState.value.firstOrNull { it.id == id && it.status == PendingStatus.FAILED } ?: return
        replace(id) { it.copy(status = PendingStatus.SENDING, error = null) }
        launchSend(message.id)
    }

    fun discard(id: String) {
        val message = pendingState.value.firstOrNull { it.id == id } ?: return
        pendingState.update { list -> list.filter { it.id != id } }
        message.audioPath?.let { path -> runCatching { File(path).delete() } }
    }

    private fun enqueue(message: PendingMessage) {
        pendingState.update { it + message }
        launchSend(message.id)
    }

    private fun launchSend(id: String) {
        appScope.scope.launch {
            gate.withLock {
                val message = pendingState.value.firstOrNull { it.id == id } ?: return@withLock
                val wait = MIN_GAP_MS - (System.currentTimeMillis() - lastSendAtMs)
                if (wait > 0L) delay(wait)
                lastSendAtMs = System.currentTimeMillis()
                val outcome = try {
                    Result.success(deliver(message))
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Result.failure<String>(e)
                }
                outcome.onSuccess { realId ->
                    replace(id) { it.copy(status = PendingStatus.SENT, realId = realId, error = null) }
                    message.audioPath?.let { path -> runCatching { File(path).delete() } }
                    scheduleCleanup(id)
                }.onFailure { error ->
                    replace(id) { it.copy(status = PendingStatus.FAILED, error = error.toUiText()) }
                }
            }
        }
    }

    private suspend fun deliver(message: PendingMessage): String {
        val audioUrl = if (message.audioPath != null) {
            audioUploader.upload(File(message.audioPath), VOICE_FOLDER).getOrThrow()
        } else {
            null
        }
        return when (val target = message.target) {
            is ChatTarget.Dm -> {
                val payload = buildJsonObject {
                    put("targetUid", target.uid)
                    if (audioUrl != null) {
                        put("audioUrl", audioUrl)
                        put("audioDurationSec", message.durationSec)
                    } else {
                        put("text", message.text)
                    }
                }
                val body = api.call("send-dm-message", payload, skipClientCooldown = true).getOrThrow()
                (body["messageId"] as? JsonPrimitive)?.contentOrNull.orEmpty()
            }
            ChatTarget.ClassChat -> {
                if (audioUrl != null) {
                    val name = profiles.current.value?.name.orEmpty()
                    val id = repository.addClassVoice(name, audioUrl, message.durationSec)
                    pushTrigger.send(type = "classChat", text = VOICE_PREVIEW, targetUid = null)
                    id
                } else {
                    val payload = buildJsonObject { put("text", message.text) }
                    val body = api.call("send-classchat-message", payload, skipClientCooldown = true).getOrThrow()
                    (body["messageId"] as? JsonPrimitive)?.contentOrNull.orEmpty()
                }
            }
        }
    }

    private fun scheduleCleanup(id: String) {
        appScope.scope.launch {
            delay(CLEANUP_DELAY_MS)
            pendingState.update { list -> list.filter { it.id != id || it.status != PendingStatus.SENT } }
        }
    }

    private fun replace(id: String, transform: (PendingMessage) -> PendingMessage) {
        pendingState.update { list -> list.map { if (it.id == id) transform(it) else it } }
    }

    private fun newId(): String = "pending-" + UUID.randomUUID().toString()

    companion object {
        const val VOICE_FOLDER = "leafmash/voice"
        const val MAX_VOICE_SECONDS = 60
        const val DM_TEXT_LIMIT = 2000
        const val CLASS_TEXT_LIMIT = 1000
        private const val MIN_GAP_MS = 1_650L
        private const val CLEANUP_DELAY_MS = 60_000L
        private const val VOICE_PREVIEW = "🎤 Voice message"
    }
}
