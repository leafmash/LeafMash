package com.leafmash.app.feature.auth

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leafmash.app.R
import com.leafmash.app.core.auth.AuthRepository
import com.leafmash.app.core.auth.GoogleCredentialHelper
import com.leafmash.app.core.auth.SignUpData
import com.leafmash.app.core.auth.toUiText
import com.leafmash.app.core.util.UiText
import com.leafmash.app.core.util.Validation
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch

enum class AuthTab { SIGN_IN, SIGN_UP }

data class SignInForm(
    val email: String = "",
    val password: String = ""
)

data class SignUpForm(
    val name: String = "",
    val roll: String = "",
    val blood: String = "",
    val gender: String = "",
    val phone: String = "",
    val email: String = "",
    val password: String = ""
)

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val auth: AuthRepository
) : ViewModel() {

    var tab by mutableStateOf(AuthTab.SIGN_IN)
        private set

    var signInForm by mutableStateOf(SignInForm())
        private set

    var signUpForm by mutableStateOf(SignUpForm())
        private set

    var loading by mutableStateOf(false)
        private set

    var error by mutableStateOf<UiText?>(null)
        private set

    private val eventChannel = Channel<UiText>(Channel.BUFFERED)
    val events: Flow<UiText> = eventChannel.receiveAsFlow()

    fun selectTab(value: AuthTab) {
        if (loading) return
        tab = value
        error = null
    }

    fun updateSignIn(transform: (SignInForm) -> SignInForm) {
        signInForm = transform(signInForm)
    }

    fun updateSignUp(transform: (SignUpForm) -> SignUpForm) {
        signUpForm = transform(signUpForm)
    }

    fun submitSignIn() {
        if (loading) return
        val form = signInForm
        if (form.email.isBlank() || form.password.isEmpty()) {
            error = UiText.Res(R.string.err_fill_all)
            return
        }
        if (!Validation.isEmailValid(form.email)) {
            error = UiText.Res(R.string.err_invalid_email)
            return
        }
        viewModelScope.launch {
            begin()
            auth.signIn(form.email, form.password)
                .onSuccess { finishSuccess() }
                .onFailure { fail(it) }
        }
    }

    fun submitSignUp() {
        if (loading) return
        val form = signUpForm
        val problem = signUpProblem(form)
        if (problem != null) {
            error = problem
            return
        }
        viewModelScope.launch {
            begin()
            auth.signUp(
                SignUpData(
                    name = form.name,
                    roll = form.roll,
                    phone = form.phone,
                    blood = form.blood,
                    gender = form.gender,
                    email = form.email,
                    password = form.password
                )
            )
                .onSuccess { finishSuccess() }
                .onFailure { fail(it) }
        }
    }

    fun signInWithGoogle(context: Context) {
        if (loading) return
        viewModelScope.launch {
            begin()
            val token = GoogleCredentialHelper.fetchIdToken(context).getOrElse {
                fail(it)
                return@launch
            }
            auth.signInWithGoogleIdToken(token)
                .onSuccess { finishSuccess() }
                .onFailure { fail(it) }
        }
    }

    fun sendPasswordReset() {
        if (loading) return
        val email = signInForm.email.trim()
        if (email.isEmpty()) {
            error = UiText.Res(R.string.err_enter_email_first)
            return
        }
        if (!Validation.isEmailValid(email)) {
            error = UiText.Res(R.string.err_invalid_email)
            return
        }
        viewModelScope.launch {
            begin()
            auth.sendPasswordReset(email)
                .onSuccess {
                    loading = false
                    eventChannel.send(UiText.Res(R.string.auth_reset_sent, email))
                }
                .onFailure { fail(it) }
        }
    }

    private fun signUpProblem(form: SignUpForm): UiText? = when {
        form.name.isBlank() || form.roll.isBlank() || form.blood.isEmpty() ||
            form.gender.isEmpty() || form.phone.isBlank() || form.email.isBlank() || form.password.isEmpty() ->
            UiText.Res(R.string.err_fill_all)
        form.name.trim().length > Validation.MAX_NAME -> UiText.Res(R.string.err_name_too_long)
        !Validation.isPhoneValid(form.phone) -> UiText.Res(R.string.err_invalid_phone)
        !Validation.isEmailValid(form.email) -> UiText.Res(R.string.err_invalid_email)
        else -> Validation.passwordProblem(form.password)
    }

    private fun begin() {
        loading = true
        error = null
    }

    private fun finishSuccess() {
        loading = false
        signInForm = SignInForm()
        signUpForm = SignUpForm()
    }

    private fun fail(throwable: Throwable) {
        loading = false
        error = throwable.toUiText()
    }
}
