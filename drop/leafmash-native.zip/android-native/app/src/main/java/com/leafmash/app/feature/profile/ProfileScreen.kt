package com.leafmash.app.feature.profile

import com.leafmash.app.ui.theme.LeafPalette
import com.leafmash.app.ui.components.LeafCard
import com.leafmash.app.ui.components.GradientButton
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.background
import com.leafmash.app.ui.components.LeafTopAppBar
import androidx.compose.runtime.getValue
import android.text.format.DateUtils
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.Badge
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leafmash.app.R
import com.leafmash.app.core.data.ProfileBadge
import com.leafmash.app.core.data.UserProfile
import com.leafmash.app.core.data.badge
import com.leafmash.app.core.data.displayName
import com.leafmash.app.ui.components.ProfileBadgeIcon
import com.leafmash.app.ui.components.UserAvatar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    onOpenSettings: () -> Unit,
    onEditProfile: () -> Unit,
    onOpenSaved: () -> Unit,
    onOpenRoutine: () -> Unit,
    onOpenDeadlines: () -> Unit,
    onOpenNotices: () -> Unit,
    onOpenReports: () -> Unit,
    onOpenVerified: () -> Unit,
    viewModel: ProfileViewModel = hiltViewModel()
) {
    val profile by viewModel.profile.collectAsStateWithLifecycle()
    val isAdmin by viewModel.isAdmin.collectAsStateWithLifecycle()
    val openReports by viewModel.openReports.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            LeafTopAppBar(
                title = { Text(stringResource(R.string.nav_profile)) },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(
                            imageVector = Icons.Filled.Settings,
                            contentDescription = stringResource(R.string.settings_title)
                        )
                    }
                }
            )
        }
    ) { padding ->
        val current = profile
        if (current == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            ProfileContent(
                profile = current,
                onOpenSettings = onOpenSettings,
                onEditProfile = onEditProfile,
                onOpenSaved = onOpenSaved,
                onOpenRoutine = onOpenRoutine,
                onOpenDeadlines = onOpenDeadlines,
                onOpenNotices = onOpenNotices,
                isAdmin = isAdmin,
                openReports = openReports,
                onOpenReports = onOpenReports,
                onOpenVerified = onOpenVerified,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ProfileContent(
    profile: UserProfile,
    onOpenSettings: () -> Unit,
    onEditProfile: () -> Unit,
    onOpenSaved: () -> Unit,
    onOpenRoutine: () -> Unit,
    onOpenDeadlines: () -> Unit,
    onOpenNotices: () -> Unit,
    isAdmin: Boolean,
    openReports: Int,
    onOpenReports: () -> Unit,
    onOpenVerified: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current
    val notSet = stringResource(R.string.profile_not_set)
    val hidden = stringResource(R.string.profile_hidden)

    Column(modifier = modifier.verticalScroll(rememberScrollState())) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 34.dp, bottomEnd = 34.dp))
                .background(LeafPalette.HeroBrush)
                .padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 58.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(112.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    UserAvatar(
                        name = profile.displayName,
                        seed = profile.uid,
                        photoUrl = profile.photoUrl,
                        size = 100.dp,
                        contentDescription = stringResource(R.string.profile_photo_cd)
                    )
                }
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = profile.displayName,
                        style = MaterialTheme.typography.headlineSmall,
                        color = Color.White,
                        textAlign = TextAlign.Center,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    ProfileBadgeIcon(profile.badge, modifier = Modifier.padding(start = 6.dp), size = 22.dp)
                }
                Spacer(Modifier.height(10.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    HeroChip(stringResource(R.string.profile_department))
                    if (profile.session.isNotBlank()) {
                        HeroChip(profile.session)
                    }
                    if (profile.badge == ProfileBadge.ADMIN) {
                        HeroChip(stringResource(R.string.profile_admin_chip))
                    }
                }
                if (profile.bio.isNotBlank()) {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = profile.bio,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.85f),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .offset(y = (-34).dp)
                .padding(horizontal = 14.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                StatCard(
                    value = profile.roll.ifBlank { "—" },
                    label = stringResource(R.string.profile_stat_roll),
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    value = profile.bloodGroup.ifBlank { "—" },
                    label = stringResource(R.string.profile_stat_blood),
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    value = profile.year.ifBlank { profile.session.ifBlank { "—" } },
                    label = stringResource(R.string.profile_stat_year),
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(16.dp))
            GradientButton(
                text = stringResource(R.string.profile_edit),
                onClick = onEditProfile,
                leadingIcon = Icons.Filled.Edit,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(16.dp))

        LeafCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(vertical = 4.dp)) {
                DetailRow(stringResource(R.string.profile_label_roll), profile.roll.ifBlank { notSet })
                DetailRow(stringResource(R.string.profile_label_year), profile.year.ifBlank { notSet })
                DetailRow(stringResource(R.string.profile_label_session), profile.session.ifBlank { notSet })
                DetailRow(stringResource(R.string.profile_label_blood), profile.bloodGroup.ifBlank { notSet })
                DetailRow(stringResource(R.string.profile_label_gender), genderLabel(profile.gender, notSet))
                DetailRow(stringResource(R.string.profile_label_hometown), profile.hometown.ifBlank { notSet })
                DetailRow(stringResource(R.string.profile_label_address), profile.address.ifBlank { notSet })
                DetailRow(
                    stringResource(R.string.profile_label_phone),
                    profile.phone.ifBlank { notSet } + if (profile.hidePhone) " · $hidden" else ""
                )
                DetailRow(
                    stringResource(R.string.profile_label_email),
                    profile.email.ifBlank { notSet } + if (profile.hideEmail) " · $hidden" else ""
                )
                if (profile.socialLinks.isEmpty()) {
                    DetailRow(stringResource(R.string.profile_label_social), notSet)
                } else {
                    profile.socialLinks.forEach { link ->
                        DetailRow(
                            label = stringResource(R.string.profile_label_social),
                            value = link,
                            onClick = { runCatching { uriHandler.openUri(link) } }
                        )
                    }
                }
                DetailRow(stringResource(R.string.profile_label_college), stringResource(R.string.profile_college_name))
                if (profile.createdAtMs > 0L) {
                    DetailRow(
                        stringResource(R.string.profile_label_joined),
                        DateUtils.formatDateTime(
                            context,
                            profile.createdAtMs,
                            DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_YEAR
                        )
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        LeafCard(modifier = Modifier.fillMaxWidth()) {
            ListItem(
                modifier = Modifier.clickable(onClick = onOpenSaved),
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                leadingContent = { MenuIcon(Icons.Outlined.BookmarkBorder) },
                headlineContent = { Text(stringResource(R.string.saved_title)) },
                supportingContent = { Text(stringResource(R.string.profile_saved_hint)) },
                trailingContent = {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
                }
            )
            ListItem(
                modifier = Modifier.clickable(onClick = onOpenRoutine),
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                leadingContent = { MenuIcon(Icons.Filled.Schedule) },
                headlineContent = { Text(stringResource(R.string.routine_title)) },
                trailingContent = {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
                }
            )
            ListItem(
                modifier = Modifier.clickable(onClick = onOpenDeadlines),
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                leadingContent = { MenuIcon(Icons.Filled.Event) },
                headlineContent = { Text(stringResource(R.string.deadlines_title)) },
                trailingContent = {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
                }
            )
            ListItem(
                modifier = Modifier.clickable(onClick = onOpenNotices),
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                leadingContent = { MenuIcon(Icons.Filled.Campaign) },
                headlineContent = { Text(stringResource(R.string.notices_title)) },
                trailingContent = {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
                }
            )
            if (isAdmin) {
                ListItem(
                    modifier = Modifier.clickable(onClick = onOpenReports),
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    leadingContent = { MenuIcon(Icons.Filled.Flag) },
                    headlineContent = { Text(stringResource(R.string.reports_title)) },
                    trailingContent = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (openReports > 0) {
                                Badge { Text(if (openReports > 9) "9+" else openReports.toString()) }
                            }
                            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
                        }
                    }
                )
                ListItem(
                    modifier = Modifier.clickable(onClick = onOpenVerified),
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    leadingContent = { MenuIcon(Icons.Filled.Verified) },
                    headlineContent = { Text(stringResource(R.string.verified_title)) },
                    trailingContent = {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
                    }
                )
            }
            ListItem(
                modifier = Modifier.clickable(onClick = onOpenSettings),
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                leadingContent = { MenuIcon(Icons.Filled.Settings) },
                headlineContent = { Text(stringResource(R.string.settings_title)) },
                supportingContent = { Text(stringResource(R.string.profile_settings_hint)) },
                trailingContent = {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
                }
            )
        }
        Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun HeroChip(text: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Color.White.copy(alpha = 0.16f))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium,
            color = Color.White
        )
    }
}

@Composable
private fun MenuIcon(icon: ImageVector) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(13.dp))
            .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(22.dp)
        )
    }
}

@Composable
private fun genderLabel(gender: String, fallback: String): String = when (gender) {
    "male" -> stringResource(R.string.gender_male)
    "female" -> stringResource(R.string.gender_female)
    "other" -> stringResource(R.string.gender_other)
    else -> fallback
}

@Composable
private fun StatCard(value: String, label: String, modifier: Modifier = Modifier) {
    LeafCard(modifier = modifier, shape = RoundedCornerShape(18.dp)) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String, onClick: (() -> Unit)? = null) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(0.4f)
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium,
                color = if (onClick != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.End,
                modifier = Modifier.weight(0.6f)
            )
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
    }
}
