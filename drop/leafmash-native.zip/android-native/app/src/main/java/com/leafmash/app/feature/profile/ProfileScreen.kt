package com.leafmash.app.feature.profile

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leafmash.app.R
import com.leafmash.app.feature.wall.ReactionsSheet
import com.leafmash.app.feature.wall.SavedViewModel
import com.leafmash.app.feature.wall.openLink
import com.leafmash.app.feature.wall.NoteRow
import com.leafmash.app.ui.components.CollectSnackbars
import com.leafmash.app.ui.components.EmptyCard
import com.leafmash.app.ui.components.GradientButton
import com.leafmash.app.ui.components.LeafTopAppBar
import com.leafmash.app.ui.navigation.MenuAction

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    onOpenSettings: () -> Unit,
    onEditProfile: () -> Unit,
    onOpenPost: (String, Boolean) -> Unit,
    onEditPost: (String) -> Unit,
    onOpenHashtag: (String) -> Unit,
    viewModel: ProfileViewModel = hiltViewModel(),
    savedViewModel: SavedViewModel = hiltViewModel()
) {
    val profile by viewModel.profile.collectAsStateWithLifecycle()
    val posts by viewModel.posts.collectAsStateWithLifecycle()
    val notes by viewModel.notes.collectAsStateWithLifecycle()
    val users by viewModel.users.collectAsStateWithLifecycle()
    val savedIds by viewModel.savedIds.collectAsStateWithLifecycle()
    val bookmarks by savedViewModel.bookmarkList.collectAsStateWithLifecycle()
    val savedPosts by savedViewModel.savedPosts.collectAsStateWithLifecycle()
    val savedUsers by savedViewModel.users.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var reactionsFor by remember { mutableStateOf<Map<String, String>?>(null) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val postsEmptyText = stringResource(R.string.user_posts_empty)
    val notesEmptyText = stringResource(R.string.user_notes_empty)
    val savedEmptyText = stringResource(R.string.saved_empty_all)

    CollectSnackbars(viewModel.events, snackbar)
    CollectSnackbars(savedViewModel.events, snackbar)

    LaunchedEffect(tab) {
        if (tab == 1) viewModel.loadPosts()
        if (tab == 2) viewModel.loadNotes()
    }

    Scaffold(
        topBar = {
            LeafTopAppBar(
                title = { Text(stringResource(R.string.nav_profile)) },
                actions = { MenuAction() }
            )
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        val current = profile
        if (current == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                item(key = "hero") { ProfileHero(current, showDepartment = true) }
                item(key = "actions") {
                    Column(Modifier.padding(horizontal = 14.dp, vertical = 14.dp)) {
                        ProfileStatRow(current)
                        Spacer(Modifier.height(14.dp))
                        GradientButton(
                            text = stringResource(R.string.profile_edit),
                            onClick = onEditProfile,
                            leadingIcon = Icons.Filled.Edit,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(16.dp))
                        ProfileTabPills(
                            labels = listOf(
                                stringResource(R.string.user_tab_info),
                                stringResource(R.string.user_tab_posts),
                                stringResource(R.string.user_tab_notes),
                                stringResource(R.string.profile_tab_saved)
                            ),
                            selected = tab,
                            onSelect = { tab = it }
                        )
                    }
                }
                when (tab) {
                    0 -> item(key = "info") {
                        Column(Modifier.padding(horizontal = 14.dp, vertical = 4.dp)) {
                            ProfileInfoCard(current, self = true)
                            Spacer(Modifier.height(24.dp))
                        }
                    }
                    1 -> profilePostItems(
                        posts = posts,
                        users = users,
                        savedIds = savedIds,
                        myUid = viewModel.myUid,
                        isAdmin = viewModel.isAdmin,
                        viewModel = viewModel,
                        emptyText = postsEmptyText,
                        onOpenPost = onOpenPost,
                        onEditPost = onEditPost,
                        onOpenHashtag = onOpenHashtag,
                        onViewReactions = { post ->
                            viewModel.ensureUsers(post.reactions.keys)
                            reactionsFor = post.reactions
                        }
                    )
                    2 -> profileNoteItems(notes, notesEmptyText)
                    else -> {
                        val postList = savedPosts
                        val bookmarkItems = bookmarks
                        if (postList == null || bookmarkItems == null) {
                            profilePostItems(
                                posts = null,
                                users = savedUsers,
                                savedIds = emptySet(),
                                myUid = savedViewModel.myUid,
                                isAdmin = savedViewModel.isAdmin,
                                viewModel = savedViewModel,
                                emptyText = "",
                                onOpenPost = onOpenPost,
                                onEditPost = onEditPost,
                                onOpenHashtag = onOpenHashtag,
                                onViewReactions = {}
                            )
                        } else {
                            val noteBookmarks = bookmarkItems.filter { it.type != "post" }
                            if (postList.isEmpty() && noteBookmarks.isEmpty()) {
                                item(key = "saved_empty") {
                                    EmptyCard(
                                        title = savedEmptyText,
                                        icon = Icons.Outlined.BookmarkBorder,
                                        modifier = Modifier.padding(24.dp)
                                    )
                                }
                            } else {
                                profilePostItems(
                                    posts = postList,
                                    users = savedUsers,
                                    savedIds = postList.map { it.id }.toSet(),
                                    myUid = savedViewModel.myUid,
                                    isAdmin = savedViewModel.isAdmin,
                                    viewModel = savedViewModel,
                                    emptyText = "",
                                    onOpenPost = onOpenPost,
                                    onEditPost = onEditPost,
                                    onOpenHashtag = onOpenHashtag,
                                    onViewReactions = { post ->
                                        savedViewModel.ensureUsers(post.reactions.keys)
                                        reactionsFor = post.reactions
                                    }
                                )
                                items(noteBookmarks, key = { "saved_note_${it.id}" }) { note ->
                                    NoteRow(note = note, onOpen = { openLink(context, note.link) })
                                }
                            }
                        }
                    }
                }
                item(key = "bottom") { Spacer(Modifier.height(16.dp)) }
            }
        }
    }

    val shown = reactionsFor
    if (shown != null) {
        val reactionUsers = if (tab == 3) savedUsers else users
        ReactionsSheet(reactions = shown, users = reactionUsers, onDismiss = { reactionsFor = null })
    }
}
