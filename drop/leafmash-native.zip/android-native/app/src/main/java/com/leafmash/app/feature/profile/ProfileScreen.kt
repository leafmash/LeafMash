package com.leafmash.app.feature.profile

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.leafmash.app.R
import com.leafmash.app.ui.components.PlaceholderScreen

@Composable
fun ProfileScreen(onOpenSettings: () -> Unit) {
    PlaceholderScreen(
        title = stringResource(R.string.nav_profile),
        icon = Icons.Filled.Person,
        phase = 1
    ) {
        Spacer(Modifier.height(24.dp))
        OutlinedButton(onClick = onOpenSettings) {
            Icon(Icons.Filled.Settings, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.settings_title))
        }
    }
}
