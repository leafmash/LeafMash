package com.leafmash.app.core.auth

import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.leafmash.app.R
import com.leafmash.app.core.network.ApiException
import com.leafmash.app.core.util.UiText
import java.io.IOException

fun Throwable.toUiText(): UiText = when (this) {
    is DisposableEmailException -> UiText.Res(R.string.err_disposable_email)
    is GoogleOnlyAccountException -> UiText.Res(R.string.err_google_only)
    is GoogleSignInException -> when (reason) {
        GoogleSignInException.Reason.CANCELLED -> UiText.Res(R.string.err_google_cancelled)
        GoogleSignInException.Reason.NO_ACCOUNT -> UiText.Res(R.string.err_google_no_account)
        GoogleSignInException.Reason.NOT_CONFIGURED -> UiText.Res(R.string.err_google_not_configured)
        GoogleSignInException.Reason.FAILED -> UiText.Res(R.string.err_google_failed)
    }
    is ApiException -> UiText.Plain(message)
    is FirebaseAuthWeakPasswordException -> UiText.Res(R.string.err_weak_password)
    is FirebaseAuthUserCollisionException -> if (errorCode == "ERROR_EMAIL_ALREADY_IN_USE") {
        UiText.Res(R.string.err_email_in_use)
    } else {
        UiText.Res(R.string.err_account_exists_different)
    }
    is FirebaseAuthInvalidUserException -> if (errorCode == "ERROR_USER_DISABLED") {
        UiText.Res(R.string.err_user_disabled)
    } else {
        UiText.Res(R.string.err_user_not_found)
    }
    is FirebaseAuthInvalidCredentialsException -> when (errorCode) {
        "ERROR_INVALID_EMAIL" -> UiText.Res(R.string.err_invalid_email)
        "ERROR_WRONG_PASSWORD" -> UiText.Res(R.string.err_wrong_password)
        else -> UiText.Res(R.string.err_invalid_credential)
    }
    is FirebaseTooManyRequestsException -> UiText.Res(R.string.err_too_many_attempts)
    is FirebaseNetworkException -> UiText.Res(R.string.err_network)
    is IOException -> UiText.Res(R.string.err_network)
    is FirebaseAuthException -> UiText.Res(R.string.err_generic)
    else -> UiText.Res(R.string.err_generic)
}
