package com.leafmash.app.feature.notifications.data

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.leafmash.app.core.profile.ProfileRepository
import com.leafmash.app.core.util.AppScope
import com.leafmash.app.core.util.retryWithBackoff
import com.leafmash.app.core.util.snapshotFlow
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.shareIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await
import org.json.JSONArray

@Singleton
class NotificationFeedRepository @Inject constructor(
    @ApplicationContext context: Context,
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth,
    private val profiles: ProfileRepository,
    private val appScope: AppScope
) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val loadMutex = Mutex()
    private var loadedUid: String? = null

    private val noticeReadState = MutableStateFlow<Set<String>>(emptySet())
    private val activityReadState = MutableStateFlow<Set<String>>(emptySet())
    private val dismissedState = MutableStateFlow<Set<String>>(emptySet())

    val noticeReadIds: StateFlow<Set<String>> = noticeReadState.asStateFlow()
    val activityReadIds: StateFlow<Set<String>> = activityReadState.asStateFlow()
    val dismissedIds: StateFlow<Set<String>> = dismissedState.asStateFlow()

    val notices: SharedFlow<List<Notice>> = flow {
        emitAll(
            firestore.collection("notices")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .snapshotFlow()
                .map { snapshot -> snapshot.documents.map { it.toNotice() } }
                .retryWithBackoff()
        )
    }.shareIn(appScope.scope, SharingStarted.WhileSubscribed(DETACH_DELAY_MS, 0L), 1)

    val activity: SharedFlow<List<ActivityItem>> = flow {
        val uid = auth.currentUser?.uid.orEmpty()
        val sharedFeed = firestore.collection("activity")
            .whereIn("type", listOf("post", "resource", "notice"))
            .limit(FEED_LIMIT)
            .snapshotFlow()
            .map { snapshot -> snapshot.documents.map { it.toActivityItem() } }
            .retryWithBackoff()
        val personalFeed: Flow<List<ActivityItem>> = if (uid.isEmpty()) {
            flowOf(emptyList())
        } else {
            firestore.collection("activity")
                .whereEqualTo("targetUid", uid)
                .limit(FEED_LIMIT)
                .snapshotFlow()
                .map { snapshot -> snapshot.documents.map { it.toActivityItem() } }
                .retryWithBackoff()
        }
        emitAll(
            combine(sharedFeed, personalFeed) { shared, personal ->
                (shared + personal).distinctBy { it.id }.sortedByDescending { it.createdAtMs }.take(MERGED_LIMIT)
            }
        )
    }.shareIn(appScope.scope, SharingStarted.WhileSubscribed(DETACH_DELAY_MS, 0L), 1)

    val unreadCount: Flow<Int> = flow {
        ensureLoaded()
        emitAll(
            combine(notices, activity, noticeReadIds, activityReadIds, dismissedIds) { noticeList, items, noticeRead, activityRead, dismissed ->
                val uid = auth.currentUser?.uid.orEmpty()
                val joined = profiles.current.value?.createdAtMs ?: 0L
                val unreadNotices = noticeList.count { it.id !in noticeRead }
                val unreadActivity = items
                    .filter { it.isVisibleTo(uid, joined) }
                    .count { it.id !in dismissed && it.id !in activityRead }
                unreadNotices + unreadActivity
            }
        )
    }

    suspend fun ensureLoaded() {
        val uid = auth.currentUser?.uid ?: return
        loadMutex.withLock {
            if (loadedUid == uid) return
            loadedUid = uid
            noticeReadState.value = readLocal(KIND_NOTICE, uid)
            activityReadState.value = readLocal(KIND_ACTIVITY, uid)
            dismissedState.value = readLocal(KIND_DISMISSED, uid)
        }
        mergeCloud(KIND_NOTICE, uid, noticeReadState)
        mergeCloud(KIND_ACTIVITY, uid, activityReadState)
        mergeCloud(KIND_DISMISSED, uid, dismissedState)
    }

    fun markNoticeRead(id: String) {
        if (id in noticeReadState.value) return
        noticeReadState.update { it + id }
        persist(KIND_NOTICE, noticeReadState.value)
    }

    fun markActivityRead(id: String) {
        if (id in activityReadState.value) return
        activityReadState.update { it + id }
        persist(KIND_ACTIVITY, activityReadState.value)
    }

    fun markAllActivityRead(ids: Collection<String>) {
        if (ids.isEmpty()) return
        activityReadState.update { it + ids }
        persist(KIND_ACTIVITY, activityReadState.value)
    }

    fun dismissActivity(id: String) {
        if (id in dismissedState.value) return
        dismissedState.update { it + id }
        persist(KIND_DISMISSED, dismissedState.value)
    }

    private suspend fun mergeCloud(kind: String, uid: String, target: MutableStateFlow<Set<String>>) {
        try {
            val snapshot = firestore.collection("users").document(uid)
                .collection("readState").document(kind).get().await()
            val ids = (snapshot.get("ids") as? List<*>)?.filterIsInstance<String>().orEmpty()
            if (ids.isNotEmpty() && auth.currentUser?.uid == uid) {
                target.update { it + ids }
                writeLocal(kind, uid, target.value)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Unit
        }
    }

    private fun persist(kind: String, ids: Set<String>) {
        val uid = auth.currentUser?.uid ?: return
        val trimmed = ids.toList().takeLast(MAX_IDS)
        writeLocal(kind, uid, trimmed.toSet())
        appScope.scope.launch {
            try {
                firestore.collection("users").document(uid).collection("readState").document(kind)
                    .set(mapOf("ids" to trimmed, "updatedAt" to FieldValue.serverTimestamp()))
                    .await()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Unit
            }
        }
    }

    private fun readLocal(kind: String, uid: String): Set<String> {
        val raw = prefs.getString("${kind}_$uid", null) ?: return emptySet()
        return try {
            val array = JSONArray(raw)
            val result = LinkedHashSet<String>()
            for (index in 0 until array.length()) result.add(array.getString(index))
            result
        } catch (e: Exception) {
            emptySet()
        }
    }

    private fun writeLocal(kind: String, uid: String, ids: Set<String>) {
        val array = JSONArray()
        ids.toList().takeLast(MAX_IDS).forEach { array.put(it) }
        prefs.edit().putString("${kind}_$uid", array.toString()).apply()
    }

    private companion object {
        const val PREFS_NAME = "leafmash_read_state"
        const val KIND_NOTICE = "notice"
        const val KIND_ACTIVITY = "activity"
        const val KIND_DISMISSED = "activity_dismissed"
        const val FEED_LIMIT = 200L
        const val MERGED_LIMIT = 60
        const val MAX_IDS = 400
        const val DETACH_DELAY_MS = 60_000L
    }
}
