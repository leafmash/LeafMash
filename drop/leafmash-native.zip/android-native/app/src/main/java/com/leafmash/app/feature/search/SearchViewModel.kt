package com.leafmash.app.feature.search

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leafmash.app.core.data.Post
import com.leafmash.app.core.settings.SettingsRepository
import com.leafmash.app.core.util.safeCall
import com.leafmash.app.feature.deadlines.Deadline
import com.leafmash.app.feature.directory.data.Classmate
import com.leafmash.app.feature.notifications.data.Notice
import com.leafmash.app.feature.resources.data.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SearchResults(
    val posts: List<Post> = emptyList(),
    val resources: List<Resource> = emptyList(),
    val notices: List<Notice> = emptyList(),
    val deadlines: List<Deadline> = emptyList(),
    val classmates: List<Classmate> = emptyList()
) {
    val total: Int get() = posts.size + resources.size + notices.size + deadlines.size + classmates.size
}

data class SearchUiState(
    val loading: Boolean = true,
    val failed: Boolean = false,
    val term: String = "",
    val results: SearchResults = SearchResults()
)

private const val RESULT_CAP = 25

@OptIn(FlowPreview::class)
@HiltViewModel
class SearchViewModel @Inject constructor(
    private val repository: SearchRepository,
    private val settings: SettingsRepository
) : ViewModel() {

    var query by mutableStateOf("")
        private set

    private val queryFlow = MutableStateFlow("")
    private val dataFlow = MutableStateFlow<SearchData?>(null)
    private val failedFlow = MutableStateFlow(false)

    val recent: StateFlow<List<String>> = settings.recentSearches
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val state: StateFlow<SearchUiState> = combine(
        queryFlow.debounce(200),
        dataFlow,
        failedFlow
    ) { term, data, failed ->
        SearchUiState(
            loading = data == null && !failed,
            failed = failed,
            term = term.trim(),
            results = if (data == null) SearchResults() else compute(term.trim(), data)
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SearchUiState())

    init {
        load()
    }

    fun load() {
        failedFlow.value = false
        viewModelScope.launch {
            safeCall { repository.load() }
                .onSuccess { dataFlow.value = it }
                .onFailure { failedFlow.value = true }
        }
    }

    fun updateQuery(value: String) {
        query = value
        queryFlow.value = value
    }

    fun useRecent(term: String) {
        updateQuery(term)
    }

    fun remember(term: String) {
        viewModelScope.launch { settings.addRecentSearch(term) }
    }

    fun clearRecent() {
        viewModelScope.launch { settings.clearRecentSearches() }
    }

    private fun compute(raw: String, data: SearchData): SearchResults {
        if (raw.isEmpty()) return SearchResults()
        val isTag = raw.startsWith("#")
        val q = (if (isTag) raw.drop(1) else raw).trim().lowercase()
        if (q.isEmpty()) return SearchResults()
        val posts = data.posts.filter { post ->
            if (isTag) {
                Regex("#" + Regex.escape(q) + "(?![A-Za-z0-9_\\u0980-\\u09FF])", RegexOption.IGNORE_CASE)
                    .containsMatchIn(post.text)
            } else {
                post.text.lowercase().contains(q)
            }
        }.take(RESULT_CAP)
        if (isTag) return SearchResults(posts = posts)
        return SearchResults(
            posts = posts,
            resources = data.resources.filter {
                it.title.lowercase().contains(q) || it.category.lowercase().contains(q)
            }.take(RESULT_CAP),
            notices = data.notices.filter { it.text.lowercase().contains(q) }.take(RESULT_CAP),
            deadlines = data.deadlines.filter {
                it.title.lowercase().contains(q) || it.course.lowercase().contains(q) || it.notes.lowercase().contains(q)
            }.take(RESULT_CAP),
            classmates = data.classmates.filter {
                it.name.lowercase().contains(q) || it.roll.lowercase().contains(q) || it.bloodGroup.lowercase().contains(q)
            }.take(RESULT_CAP)
        )
    }
}
