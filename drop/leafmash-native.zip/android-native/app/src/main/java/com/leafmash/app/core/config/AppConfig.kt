package com.leafmash.app.core.config

object AppConfig {

    val ADMIN_EMAILS = setOf("in.with.imran@gmail.com")

    val VERIFIED_EMAILS = setOf("leafmash@gmail.com")

    const val ADMIN_DISPLAY_NAME = "Tabib Imran"

    const val VERIFIED_DISPLAY_NAME = "LeafMash"

    const val AVATAR_FOLDER = "leafmash/avatars"

    const val POST_FOLDER = "leafmash/posts"

    fun isAdminEmail(email: String?): Boolean = !email.isNullOrBlank() && email in ADMIN_EMAILS

    fun isOfficialVerifiedEmail(email: String?): Boolean = !email.isNullOrBlank() && email in VERIFIED_EMAILS
}
