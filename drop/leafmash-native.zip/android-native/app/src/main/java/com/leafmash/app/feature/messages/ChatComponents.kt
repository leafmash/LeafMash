package com.leafmash.app.feature.messages

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.text.format.DateUtils
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.compose.foundation.Canvas
import com.leafmash.app.R
import com.leafmash.app.feature.messages.data.ChatMessage
import com.leafmash.app.feature.messages.voice.PlaybackState
import com.leafmash.app.feature.messages.voice.VoiceRecorderController
import com.leafmash.app.feature.messages.voice.RecorderUiState
import com.leafmash.app.ui.components.formatTimeAgo
import java.text.DateFormat
import java.util.Date

private const val ONLINE_WINDOW_MS = 240_000L
private const val DAY_MS = 86_400_000L

fun isOnline(lastActiveMs: Long, nowMs: Long = System.currentTimeMillis()): Boolean =
    lastActiveMs > 0L && nowMs - lastActiveMs < ONLINE_WINDOW_MS

fun presenceLabel(context: Context, lastActiveMs: Long): String? {
    if (lastActiveMs <= 0L) return null
    if (isOnline(lastActiveMs)) return context.getString(R.string.chat_online)
    return context.getString(R.string.chat_active_ago, formatTimeAgo(context, lastActiveMs))
}

fun formatClock(timeMs: Long): String = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(timeMs))

fun dayLabel(context: Context, timeMs: Long): String = when {
    DateUtils.isToday(timeMs) -> context.getString(R.string.chat_today)
    DateUtils.isToday(timeMs + DAY_MS) -> context.getString(R.string.chat_yesterday)
    else -> DateUtils.formatDateTime(
        context,
        timeMs,
        DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_YEAR
    )
}

fun sameDay(a: Long, b: Long): Boolean {
    val zoneOffset = java.util.TimeZone.getDefault().getOffset(a).toLong()
    val zoneOffsetB = java.util.TimeZone.getDefault().getOffset(b).toLong()
    return (a + zoneOffset) / DAY_MS == (b + zoneOffsetB) / DAY_MS
}

@Composable
fun rememberMicAction(onStart: () -> Unit, onDenied: () -> Unit): () -> Unit {
    val context = LocalContext.current
    val currentStart by rememberUpdatedState(onStart)
    val currentDenied by rememberUpdatedState(onDenied)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) currentStart() else currentDenied()
    }
    return remember(context, launcher) {
        {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            if (granted) currentStart() else launcher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }
}

@Composable
fun DayDivider(timeMs: Long) {
    val context = LocalContext.current
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Text(
                text = dayLabel(context, timeMs),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
    }
}

enum class Receipt { NONE, SENT, READ }

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MessageBubble(
    message: ChatMessage,
    mine: Boolean,
    senderLabel: String?,
    receipt: Receipt,
    playback: PlaybackState,
    onTogglePlay: () -> Unit,
    onSeek: (Long) -> Unit,
    onCycleSpeed: () -> Unit,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val container = when {
        message.failed -> MaterialTheme.colorScheme.errorContainer
        mine -> MaterialTheme.colorScheme.primaryContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    val content = when {
        message.failed -> MaterialTheme.colorScheme.onErrorContainer
        mine -> MaterialTheme.colorScheme.onPrimaryContainer
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    val shape = RoundedCornerShape(
        topStart = 16.dp,
        topEnd = 16.dp,
        bottomStart = if (mine) 16.dp else 4.dp,
        bottomEnd = if (mine) 4.dp else 16.dp
    )
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 2.dp),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            shape = shape,
            color = container,
            contentColor = content,
            modifier = Modifier
                .widthIn(max = 300.dp)
                .clip(shape)
                .combinedClickable(onClick = onClick, onLongClick = onLongClick)
        ) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                if (senderLabel != null) {
                    Text(
                        text = senderLabel,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (message.isVoice) {
                    VoiceContent(
                        message = message,
                        playback = playback,
                        onTogglePlay = onTogglePlay,
                        onSeek = onSeek,
                        onCycleSpeed = onCycleSpeed
                    )
                } else {
                    Text(text = message.text, style = MaterialTheme.typography.bodyLarge)
                }
                Spacer(Modifier.height(2.dp))
                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val footer = when {
                        message.failed -> stringResource(R.string.chat_failed_tap_retry)
                        message.pending -> stringResource(R.string.pending_sending)
                        message.edited -> stringResource(R.string.chat_edited_time, formatClock(message.createdAtMs))
                        else -> formatClock(message.createdAtMs)
                    }
                    Text(
                        text = footer,
                        style = MaterialTheme.typography.labelSmall,
                        color = content.copy(alpha = 0.7f)
                    )
                    if (receipt != Receipt.NONE && !message.pending && !message.failed) {
                        Spacer(Modifier.width(4.dp))
                        Icon(
                            imageVector = if (receipt == Receipt.READ) Icons.Filled.DoneAll else Icons.Filled.Done,
                            contentDescription = stringResource(
                                if (receipt == Receipt.READ) R.string.chat_read else R.string.chat_delivered
                            ),
                            tint = if (receipt == Receipt.READ) MaterialTheme.colorScheme.primary else content.copy(alpha = 0.7f),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun VoiceContent(
    message: ChatMessage,
    playback: PlaybackState,
    onTogglePlay: () -> Unit,
    onSeek: (Long) -> Unit,
    onCycleSpeed: () -> Unit
) {
    val active = playback.currentId == message.id
    val playing = active && playback.playing
    val knownMs = message.audioDurationSec * 1000L
    val durationMs = if (active && playback.durationMs > 0L) playback.durationMs else knownMs
    val progress = if (active && durationMs > 0L) (playback.positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
    val shownMs = if (active && playback.positionMs > 0L) playback.positionMs else durationMs
    Row(
        modifier = Modifier.widthIn(min = 200.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onTogglePlay, modifier = Modifier.size(40.dp)) {
            Icon(
                imageVector = if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = stringResource(if (playing) R.string.chat_pause else R.string.chat_play)
            )
        }
        Column(modifier = Modifier.weight(1f)) {
            Slider(
                value = progress,
                onValueChange = { fraction ->
                    if (active && durationMs > 0L) onSeek((fraction * durationMs).toLong())
                },
                enabled = active,
                modifier = Modifier.height(24.dp)
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = formatDuration((shownMs / 1000L).toInt()),
                    style = MaterialTheme.typography.labelSmall
                )
                if (active) {
                    Text(
                        text = stringResource(R.string.chat_speed, speedLabel(playback.speed)),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable(onClick = onCycleSpeed)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
    if (active && playback.failed) {
        Text(
            text = stringResource(R.string.chat_play_failed),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.error
        )
    }
}

private fun speedLabel(speed: Float): String = if (speed == speed.toInt().toFloat()) speed.toInt().toString() else speed.toString()

fun formatDuration(totalSec: Int): String {
    val safe = totalSec.coerceAtLeast(0)
    return "%d:%02d".format(safe / 60, safe % 60)
}

@Composable
fun MessageActionsMenu(
    expanded: Boolean,
    onDismiss: () -> Unit,
    canCopy: Boolean,
    canEdit: Boolean,
    canDelete: Boolean,
    onCopy: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        if (canCopy) {
            DropdownMenuItem(
                text = { Text(stringResource(R.string.post_copy)) },
                onClick = {
                    onDismiss()
                    onCopy()
                }
            )
        }
        if (canEdit) {
            DropdownMenuItem(
                text = { Text(stringResource(R.string.post_edit)) },
                onClick = {
                    onDismiss()
                    onEdit()
                }
            )
        }
        if (canDelete) {
            DropdownMenuItem(
                text = { Text(stringResource(R.string.action_delete)) },
                onClick = {
                    onDismiss()
                    onDelete()
                }
            )
        }
    }
}

@Composable
fun ChatComposer(
    text: String,
    onTextChange: (String) -> Unit,
    onSend: () -> Unit,
    recorder: VoiceRecorderController,
    recorderState: RecorderUiState,
    onMicDenied: () -> Unit,
    editing: Boolean,
    onCancelEdit: () -> Unit,
    allowVoice: Boolean,
    modifier: Modifier = Modifier
) {
    val startMic = rememberMicAction(onStart = { recorder.start() }, onDenied = onMicDenied)
    Surface(
        tonalElevation = 3.dp,
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .imePadding()
    ) {
        Column {
            if (editing && !recorderState.recording) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.chat_editing),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onCancelEdit) {
                        Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.action_cancel))
                    }
                }
            }
            if (recorderState.recording) {
                RecordingBar(
                    state = recorderState,
                    onCancel = { recorder.cancel() },
                    onSend = { recorder.send() }
                )
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    OutlinedTextField(
                        value = text,
                        onValueChange = onTextChange,
                        placeholder = { Text(stringResource(R.string.chat_message_hint)) },
                        shape = RoundedCornerShape(24.dp),
                        maxLines = 5,
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.Sentences,
                            imeAction = ImeAction.Default
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    if (text.isNotBlank() || !allowVoice || editing) {
                        IconButton(
                            onClick = onSend,
                            enabled = text.isNotBlank(),
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = stringResource(R.string.comment_send),
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    } else {
                        IconButton(onClick = startMic, modifier = Modifier.size(48.dp)) {
                            Icon(
                                imageVector = Icons.Filled.Mic,
                                contentDescription = stringResource(R.string.chat_record),
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RecordingBar(state: RecorderUiState, onCancel: () -> Unit, onSend: () -> Unit) {
    val barColor = MaterialTheme.colorScheme.primary
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp)
            .heightIn(min = 48.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onCancel) {
            Icon(
                imageVector = Icons.Filled.Delete,
                contentDescription = stringResource(R.string.chat_cancel_recording),
                tint = MaterialTheme.colorScheme.error
            )
        }
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.error)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = formatDuration(state.elapsedSec),
            style = MaterialTheme.typography.titleSmall
        )
        Spacer(Modifier.width(12.dp))
        Canvas(
            modifier = Modifier
                .weight(1f)
                .height(32.dp)
        ) {
            val bars = VOICE_BARS
            val slot = size.width / bars
            val barWidth = slot * 0.6f
            val padded = List(bars - state.levels.size.coerceAtMost(bars)) { 0f } + state.levels.takeLast(bars)
            padded.forEachIndexed { index, level ->
                val barHeight = (size.height * (0.12f + 0.88f * level)).coerceAtMost(size.height)
                drawRoundRect(
                    color = barColor,
                    topLeft = Offset(index * slot + (slot - barWidth) / 2f, (size.height - barHeight) / 2f),
                    size = Size(barWidth, barHeight),
                    cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
                )
            }
        }
        IconButton(onClick = onSend) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.Send,
                contentDescription = stringResource(R.string.comment_send),
                tint = MaterialTheme.colorScheme.primary
            )
        }
    }
}

private const val VOICE_BARS = 24

fun parseUri(value: String): Uri = Uri.parse(value)
