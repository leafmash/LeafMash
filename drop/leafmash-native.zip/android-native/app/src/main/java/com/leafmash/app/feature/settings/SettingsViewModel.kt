package com.leafmash.app.feature.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.FirebaseApp
import com.leafmash.app.core.auth.AuthRepository
import com.leafmash.app.core.config.AppConfig
import com.leafmash.app.feature.admin.ReportsRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import com.leafmash.app.core.profile.ProfileRepository
import com.leafmash.app.core.settings.SettingsRepository
import com.leafmash.app.core.settings.ThemePreference
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settings: SettingsRepository,
    private val auth: AuthRepository,
    private val profiles: ProfileRepository,
    reports: ReportsRepository
) : ViewModel() {

    val isAdmin: StateFlow<Boolean> = profiles.current
        .map { AppConfig.isAdminEmail(it?.email) }
        .distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppConfig.isAdminEmail(profiles.current.value?.email))

    @OptIn(ExperimentalCoroutinesApi::class)
    val openReports: StateFlow<Int> = isAdmin
        .flatMapLatest { admin -> if (admin) reports.observeOpen().map { it.size } else flowOf(0) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    val accountEmail: String
        get() = profiles.current.value?.email?.ifBlank { null } ?: auth.currentEmail.orEmpty()

    fun signOut() {
        viewModelScope.launch { auth.signOut() }
    }

    val themePreference: StateFlow<ThemePreference> = settings.themePreference
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ThemePreference.SYSTEM)

    val firebaseProjectId: String = FirebaseApp.getInstance().options.projectId.orEmpty()

    fun setThemePreference(preference: ThemePreference) {
        viewModelScope.launch { settings.setThemePreference(preference) }
    }
}
