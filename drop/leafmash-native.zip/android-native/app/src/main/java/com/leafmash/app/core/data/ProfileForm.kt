package com.leafmash.app.core.data

data class ProfileForm(
    val name: String = "",
    val roll: String = "",
    val blood: String = "",
    val gender: String = "",
    val phone: String = "",
    val year: String = "",
    val session: String = "",
    val hometown: String = "",
    val address: String = "",
    val socialLinks: List<String> = listOf(""),
    val bio: String = "",
    val hidePhone: Boolean = false,
    val hideEmail: Boolean = false,
    val photoGuard: Boolean = false
) {
    companion object {
        fun from(profile: UserProfile): ProfileForm = ProfileForm(
            name = profile.name,
            roll = profile.roll,
            blood = profile.bloodGroup,
            gender = profile.gender,
            phone = profile.phone,
            year = profile.year,
            session = profile.session,
            hometown = profile.hometown,
            address = profile.address,
            socialLinks = profile.socialLinks.ifEmpty { listOf("") },
            bio = profile.bio,
            hidePhone = profile.hidePhone,
            hideEmail = profile.hideEmail,
            photoGuard = profile.photoGuard
        )
    }
}
