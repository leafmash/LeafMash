package com.leafmash.app.feature.wall

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leafmash.app.core.data.Post
import com.leafmash.app.core.data.UserRepository
import com.leafmash.app.core.data.UserSummary
import com.leafmash.app.core.util.UiText
import com.leafmash.app.core.util.toUiText
import com.leafmash.app.feature.wall.data.PostRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class HashtagState(
    val loading: Boolean = true,
    val posts: List<Post> = emptyList(),
    val error: UiText? = null
)

@HiltViewModel
class HashtagViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val posts: PostRepository,
    private val userRepository: UserRepository
) : ViewModel() {

    val tag: String = savedStateHandle.get<String>("tag").orEmpty()

    private val stateFlow = MutableStateFlow(HashtagState())
    val state: StateFlow<HashtagState> = stateFlow.asStateFlow()

    val users: StateFlow<Map<String, UserSummary>> = userRepository.users

    init {
        load()
    }

    fun load() {
        stateFlow.value = HashtagState()
        viewModelScope.launch {
            posts.postsWithTag(tag.lowercase())
                .onSuccess { list ->
                    userRepository.ensure(list.map { it.authorUid })
                    stateFlow.value = HashtagState(loading = false, posts = list)
                }
                .onFailure { stateFlow.value = HashtagState(loading = false, error = it.toUiText()) }
        }
    }
}
