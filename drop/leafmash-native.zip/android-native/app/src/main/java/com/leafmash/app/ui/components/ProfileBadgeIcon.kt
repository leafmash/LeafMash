package com.leafmash.app.ui.components

import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.leafmash.app.R
import com.leafmash.app.core.data.ProfileBadge

@Composable
fun ProfileBadgeIcon(badge: ProfileBadge, modifier: Modifier = Modifier, size: Dp = 18.dp) {
    when (badge) {
        ProfileBadge.NONE -> Unit
        ProfileBadge.ADMIN -> Icon(
            imageVector = Icons.Filled.Verified,
            contentDescription = stringResource(R.string.badge_admin),
            tint = MaterialTheme.colorScheme.tertiary,
            modifier = modifier.size(size)
        )
        ProfileBadge.VERIFIED -> Icon(
            imageVector = Icons.Filled.Verified,
            contentDescription = stringResource(R.string.badge_verified),
            tint = MaterialTheme.colorScheme.primary,
            modifier = modifier.size(size)
        )
    }
}
