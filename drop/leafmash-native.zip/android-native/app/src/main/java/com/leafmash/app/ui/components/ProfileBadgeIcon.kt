package com.leafmash.app.ui.components

import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.leafmash.app.R
import com.leafmash.app.core.data.ProfileBadge
import com.leafmash.app.ui.theme.LeafPalette

@Composable
fun badgeColor(badge: ProfileBadge): Color? {
    val dark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
    return when (badge) {
        ProfileBadge.NONE -> null
        ProfileBadge.ADMIN -> if (dark) LeafPalette.AdminBadgeDark else LeafPalette.AdminBadge
        ProfileBadge.VERIFIED -> MaterialTheme.colorScheme.primary
    }
}

@Composable
fun ProfileBadgeIcon(badge: ProfileBadge, modifier: Modifier = Modifier, size: Dp = 18.dp) {
    val tint = badgeColor(badge) ?: return
    when (badge) {
        ProfileBadge.NONE -> Unit
        ProfileBadge.ADMIN -> Icon(
            imageVector = Icons.Filled.WorkspacePremium,
            contentDescription = stringResource(R.string.badge_admin),
            tint = tint,
            modifier = modifier.size(size + 2.dp)
        )
        ProfileBadge.VERIFIED -> Icon(
            imageVector = Icons.Filled.Verified,
            contentDescription = stringResource(R.string.badge_verified),
            tint = tint,
            modifier = modifier.size(size)
        )
    }
}
