package com.leafmash.app.feature.deadlines

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leafmash.app.R
import com.leafmash.app.core.config.AppConfig
import com.leafmash.app.core.profile.ProfileRepository
import com.leafmash.app.core.util.UiText
import com.leafmash.app.core.util.safeCall
import com.leafmash.app.core.util.toUiText
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DeadlinesUiState(
    val loading: Boolean = true,
    val items: List<Deadline> = emptyList()
)

data class DeadlineForm(
    val editing: Deadline? = null,
    val title: String = "",
    val type: String = "Assignment",
    val course: String = "",
    val notes: String = "",
    val dueAtMs: Long? = null
)

@HiltViewModel
class DeadlinesViewModel @Inject constructor(
    private val repository: DeadlinesRepository,
    profiles: ProfileRepository
) : ViewModel() {

    private val eventChannel = Channel<UiText>(Channel.BUFFERED)
    val events: Flow<UiText> = eventChannel.receiveAsFlow()

    val isAdmin: StateFlow<Boolean> = profiles.current
        .map { AppConfig.isAdminEmail(it?.email) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    val state: StateFlow<DeadlinesUiState> = repository.observe()
        .map { DeadlinesUiState(loading = false, items = it) }
        .onStart { emit(DeadlinesUiState()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DeadlinesUiState())

    var form by mutableStateOf<DeadlineForm?>(null)
        private set

    var saving by mutableStateOf(false)
        private set

    var formError by mutableStateOf<UiText?>(null)
        private set

    var selected by mutableStateOf<Deadline?>(null)
        private set

    var pendingDelete by mutableStateOf<Deadline?>(null)
        private set

    fun select(item: Deadline?) {
        selected = item
    }

    fun requestDelete(item: Deadline?) {
        pendingDelete = item
    }

    fun startAdd() {
        form = DeadlineForm()
        formError = null
    }

    fun startEdit(item: Deadline) {
        selected = null
        form = DeadlineForm(item, item.title, item.type, item.course, item.notes, item.dueAtMs)
        formError = null
    }

    fun dismissForm() {
        form = null
        formError = null
    }

    fun change(transform: (DeadlineForm) -> DeadlineForm) {
        form = form?.let(transform)
    }

    fun submit() {
        val current = form ?: return
        val title = current.title.trim()
        val due = current.dueAtMs
        if (title.isEmpty()) {
            formError = UiText.Res(R.string.deadline_error_title)
            return
        }
        if (due == null) {
            formError = UiText.Res(R.string.deadline_error_due)
            return
        }
        formError = null
        saving = true
        viewModelScope.launch {
            val editing = current.editing
            val result = safeCall {
                if (editing == null) {
                    repository.create(title, current.type, current.course.trim(), current.notes.trim(), due)
                } else {
                    repository.update(editing, title, current.type, current.course.trim(), current.notes.trim(), due)
                }
            }
            result
                .onSuccess {
                    form = null
                    eventChannel.send(UiText.Res(if (editing == null) R.string.deadline_added else R.string.deadline_updated))
                }
                .onFailure { formError = it.toUiText() }
            saving = false
        }
    }

    fun confirmDelete() {
        val target = pendingDelete ?: return
        pendingDelete = null
        viewModelScope.launch {
            safeCall { repository.delete(target.id) }
                .onSuccess { eventChannel.send(UiText.Res(R.string.deadline_deleted)) }
                .onFailure { eventChannel.send(it.toUiText()) }
        }
    }
}
