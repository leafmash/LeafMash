package com.leafmash.app.feature.wall

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.leafmash.app.core.data.Comment
import com.leafmash.app.core.data.MentionRef
import com.leafmash.app.core.data.PendingComment
import com.leafmash.app.core.data.Post
import com.leafmash.app.core.data.ReplyRef
import com.leafmash.app.core.data.UserRepository
import com.leafmash.app.core.data.UserSummary
import com.leafmash.app.core.notify.ActivityLogger
import com.leafmash.app.core.notify.PushTrigger
import com.leafmash.app.core.util.UiText
import com.leafmash.app.core.util.safeCall
import com.leafmash.app.core.util.toUiText
import com.leafmash.app.feature.wall.data.BookmarkRepository
import com.leafmash.app.feature.wall.data.PostActions
import com.leafmash.app.feature.wall.data.PostRepository
import com.leafmash.app.ui.components.MentionInputState
import dagger.hilt.android.lifecycle.HiltViewModel
import java.util.UUID
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class DetailState(
    val loading: Boolean = true,
    val post: Post? = null,
    val missing: Boolean = false,
    val comments: List<Comment> = emptyList(),
    val commentsLoaded: Boolean = false,
    val error: UiText? = null
)

data class ReplyTarget(val id: String, val authorUid: String, val authorName: String)

@HiltViewModel
class PostDetailViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val posts: PostRepository,
    private val actions: PostActions,
    private val activity: ActivityLogger,
    private val push: PushTrigger,
    bookmarks: BookmarkRepository,
    private val userRepository: UserRepository,
    private val auth: FirebaseAuth
) : PostActionsViewModel(actions, userRepository, auth) {

    val postId: String = savedStateHandle.get<String>("postId").orEmpty()

    val focusComment: Boolean = savedStateHandle.get<Boolean>("focus") ?: false

    private val detailState = MutableStateFlow(DetailState())
    val detail: StateFlow<DetailState> = detailState.asStateFlow()

    private val pendingState = MutableStateFlow<List<PendingComment>>(emptyList())

    val visiblePending: StateFlow<List<PendingComment>> = combine(detailState, pendingState) { state, pending ->
        val me = auth.currentUser?.uid
        pending.filterNot { item ->
            state.comments.any { comment ->
                comment.authorUid == me && comment.text == item.text && comment.replyTo?.id == item.replyTo?.id
            }
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val saved: StateFlow<Boolean> = bookmarks.observe()
        .map { list -> list.any { it.type == "post" && it.postId == postId } }
        .catch { emit(false) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    val input = MentionInputState(COMMENT_LIMIT)

    var replyTarget by mutableStateOf<ReplyTarget?>(null)
        private set

    var sending by mutableStateOf(false)
        private set

    val students: StateFlow<List<UserSummary>> = userRepository.students

    init {
        viewModelScope.launch {
            posts.observePost(postId)
                .catch { error -> detailState.update { it.copy(loading = false, error = error.toUiText()) } }
                .collect { post ->
                    detailState.update { it.copy(loading = false, post = post, missing = post == null, error = null) }
                    if (post != null) ensureUsers(listOf(post.authorUid))
                }
        }
        viewModelScope.launch {
            posts.observeComments(postId)
                .catch { error ->
                    detailState.update { it.copy(commentsLoaded = true) }
                    this@PostDetailViewModel.emit(error.toUiText())
                }
                .collect { list ->
                    detailState.update { it.copy(comments = list, commentsLoaded = true) }
                    ensureUsers(list.map { comment -> comment.authorUid })
                }
        }
    }

    fun loadStudents() {
        viewModelScope.launch { safeCall { userRepository.loadStudents() } }
    }

    fun reactToComment(comment: Comment, emoji: String) {
        viewModelScope.launch {
            actions.reactToComment(postId, comment, emoji).onFailure { emit(it.toUiText()) }
        }
    }

    fun startReply(target: ReplyTarget) {
        replyTarget = target
        if (target.authorUid.isNotEmpty() && target.authorUid != auth.currentUser?.uid) {
            input.addMention(target.authorUid, target.authorName)
            input.prependText("@${target.authorName} ")
        }
    }

    fun cancelReply() {
        val target = replyTarget ?: return
        input.removeText("@${target.authorName} ")
        replyTarget = null
    }

    fun onInputChanged(value: androidx.compose.ui.text.input.TextFieldValue) {
        input.onChange(value)
        val target = replyTarget ?: return
        val mentionedAtStart = target.authorUid.isNotEmpty() && target.authorUid != auth.currentUser?.uid
        if (mentionedAtStart && !input.text.contains("@${target.authorName}")) replyTarget = null
    }

    fun sendComment() {
        if (sending) return
        val text = input.text.trim()
        if (text.isEmpty()) return
        val mentions = input.mentions()
        val reply = replyTarget
        val post = detailState.value.post ?: return
        val tempId = UUID.randomUUID().toString()
        val replyRef = reply?.let { ReplyRef(it.id, it.authorUid, it.authorName) }
        input.clear()
        replyTarget = null
        sending = true
        pendingState.update { it + PendingComment(tempId, text, replyRef) }
        viewModelScope.launch {
            posts.createComment(postId, text, mentions, reply?.id)
                .onSuccess { result -> notifyComment(post, text, mentions, reply, result.id, result.replyTargetUid) }
                .onFailure { error ->
                    input.setContent(text, mentions)
                    replyTarget = reply
                    emit(error.toUiText())
                }
            pendingState.update { list -> list.filterNot { it.tempId == tempId } }
            sending = false
        }
    }

    private fun notifyComment(
        post: Post,
        text: String,
        mentions: List<MentionRef>,
        reply: ReplyTarget?,
        commentId: String,
        replyTargetUid: String
    ) {
        val notified = HashSet<String>()
        auth.currentUser?.uid?.let { notified.add(it) }
        if (post.authorUid.isNotEmpty() && notified.add(post.authorUid)) {
            activity.log("comment", text, post.authorUid, postId)
            push.send("comment", text, post.authorUid, postId)
        }
        if (reply != null && replyTargetUid.isNotEmpty() && notified.add(replyTargetUid)) {
            activity.log("reply", text, replyTargetUid, postId)
            push.send("reply", text, replyTargetUid, postId, commentId)
        }
        mentions.forEach { mention ->
            if (mention.uid.isNotEmpty() && notified.add(mention.uid)) {
                activity.log("mention", text, mention.uid, postId)
                push.send("mention", text, mention.uid, postId)
            }
        }
    }

    fun editComment(comment: Comment, text: String, mentions: List<MentionRef>, onDone: () -> Unit) {
        viewModelScope.launch {
            posts.editComment(postId, comment.id, text.trim(), mentions)
                .onSuccess { onDone() }
                .onFailure { emit(it.toUiText()) }
        }
    }

    fun deleteComment(comment: Comment) {
        viewModelScope.launch {
            posts.deleteComment(postId, comment.id).onFailure { emit(it.toUiText()) }
        }
    }

    companion object {
        const val COMMENT_LIMIT = 500
    }
}
