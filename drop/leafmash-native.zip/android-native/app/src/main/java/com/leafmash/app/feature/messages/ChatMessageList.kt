package com.leafmash.app.feature.messages

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.leafmash.app.R
import com.leafmash.app.core.data.UserSummary
import com.leafmash.app.core.data.authorFallbackFor
import com.leafmash.app.core.data.displayName
import com.leafmash.app.feature.messages.data.ChatMessage
import com.leafmash.app.feature.messages.voice.PlaybackState

@Composable
fun ChatMessageList(
    messages: List<ChatMessage>,
    myUid: String,
    showSender: Boolean,
    users: Map<String, UserSummary>,
    receiptFor: (ChatMessage) -> Receipt,
    playback: PlaybackState,
    canEdit: (ChatMessage) -> Boolean,
    canDelete: (ChatMessage) -> Boolean,
    onTogglePlay: (ChatMessage) -> Unit,
    onSeek: (ChatMessage, Long) -> Unit,
    onCycleSpeed: () -> Unit,
    onRetry: (ChatMessage) -> Unit,
    onEdit: (ChatMessage) -> Unit,
    onDelete: (ChatMessage) -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()
    val clipboard = LocalClipboardManager.current
    var menuFor by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf<ChatMessage?>(null) }
    val newestId = messages.firstOrNull()?.id

    LaunchedEffect(newestId) {
        if (listState.firstVisibleItemIndex <= 1) listState.scrollToItem(0)
    }

    LazyColumn(
        state = listState,
        reverseLayout = true,
        contentPadding = PaddingValues(vertical = 8.dp),
        modifier = modifier
    ) {
        itemsIndexed(messages, key = { _, message -> message.id }) { index, message ->
            val mine = message.senderUid == myUid
            val older = messages.getOrNull(index + 1)
            Column {
                if (older == null || !sameDay(older.createdAtMs, message.createdAtMs)) {
                    DayDivider(message.createdAtMs)
                }
                Box {
                    MessageBubble(
                        message = message,
                        mine = mine,
                        senderLabel = if (showSender && !mine) {
                            (users[message.senderUid] ?: authorFallbackFor(message.senderUid)).displayName
                        } else {
                            null
                        },
                        receipt = if (mine) receiptFor(message) else Receipt.NONE,
                        playback = playback,
                        onTogglePlay = { onTogglePlay(message) },
                        onSeek = { position -> onSeek(message, position) },
                        onCycleSpeed = onCycleSpeed,
                        onClick = { if (message.failed) onRetry(message) },
                        onLongClick = { if (!message.pending) menuFor = message.id }
                    )
                    MessageActionsMenu(
                        expanded = menuFor == message.id,
                        onDismiss = { menuFor = null },
                        canCopy = !message.isVoice && !message.failed && message.text.isNotEmpty(),
                        canEdit = canEdit(message),
                        canDelete = canDelete(message),
                        onCopy = { clipboard.setText(AnnotatedString(message.text)) },
                        onEdit = { onEdit(message) },
                        onDelete = {
                            if (message.failed) onDelete(message) else confirmDelete = message
                        }
                    )
                }
            }
        }
    }

    val target = confirmDelete
    if (target != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text(stringResource(R.string.chat_delete_message_title)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = null
                    onDelete(target)
                }) { Text(stringResource(R.string.action_delete)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = null }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
}
