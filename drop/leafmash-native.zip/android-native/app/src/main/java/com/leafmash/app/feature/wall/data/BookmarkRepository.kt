package com.leafmash.app.feature.wall.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.leafmash.app.core.util.safeCall
import com.leafmash.app.core.util.snapshotFlow
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

data class Bookmark(
    val id: String,
    val type: String,
    val postId: String,
    val resourceId: String,
    val title: String,
    val category: String,
    val link: String,
    val contributorName: String
)

private fun DocumentSnapshot.toBookmark(): Bookmark = Bookmark(
    id = id,
    type = getString("type") ?: "resource",
    postId = getString("postId").orEmpty(),
    resourceId = getString("resourceId") ?: id,
    title = getString("title").orEmpty(),
    category = getString("category").orEmpty(),
    link = getString("link").orEmpty(),
    contributorName = getString("contributorName").orEmpty()
)

@Singleton
class BookmarkRepository @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth
) {

    fun observe(): Flow<List<Bookmark>> {
        val uid = auth.currentUser?.uid ?: return flowOf(emptyList())
        return firestore.collection("users").document(uid).collection("bookmarks")
            .orderBy("savedAt", Query.Direction.DESCENDING)
            .snapshotFlow()
            .map { snapshot -> snapshot.documents.map { it.toBookmark() } }
    }

    suspend fun setPostSaved(postId: String, saved: Boolean): Result<Unit> = safeCall {
        val uid = auth.currentUser?.uid ?: error("Not signed in")
        val ref = firestore.collection("users").document(uid).collection("bookmarks").document("post_$postId")
        if (saved) {
            ref.set(
                hashMapOf<String, Any>(
                    "type" to "post",
                    "postId" to postId,
                    "savedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } else {
            ref.delete().await()
        }
        Unit
    }
}
