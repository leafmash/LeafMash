package com.leafmash.app.feature.wall

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.outlined.Eco
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.leafmash.app.R
import com.leafmash.app.core.data.Reactions
import com.leafmash.app.core.data.UserSummary
import com.leafmash.app.core.data.authorFallbackFor
import com.leafmash.app.core.data.badge
import com.leafmash.app.core.data.displayName
import com.leafmash.app.ui.components.ProfileBadgeIcon
import com.leafmash.app.ui.components.UserAvatar

@Composable
fun ReactionGlyph(value: String?, modifier: Modifier = Modifier, size: Dp = 20.dp) {
    when (value) {
        null -> Icon(
            imageVector = Icons.Outlined.Eco,
            contentDescription = null,
            modifier = modifier.size(size)
        )
        Reactions.LEAF -> Icon(
            imageVector = Icons.Filled.Eco,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = modifier.size(size)
        )
        else -> Text(text = value, fontSize = (size.value * 0.9f).sp, modifier = modifier)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ReactionButton(
    myReaction: String?,
    onReact: (String) -> Unit,
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    var pickerOpen by remember { mutableStateOf(false) }
    val haptics = LocalHapticFeedback.current
    val contentColor = if (myReaction != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
    Box(modifier) {
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(
                    if (myReaction != null) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                    else Color.Transparent
                )
                .combinedClickable(
                    onClick = { onReact(myReaction ?: Reactions.LEAF) },
                    onLongClick = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        pickerOpen = true
                    }
                )
                .heightIn(min = if (compact) 32.dp else 48.dp)
                .padding(horizontal = if (compact) 8.dp else 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ReactionGlyph(myReaction, size = if (compact) 16.dp else 20.dp)
            Spacer(Modifier.width(6.dp))
            Text(
                text = stringResource(Reactions.labelRes(myReaction)),
                style = if (compact) MaterialTheme.typography.labelMedium else MaterialTheme.typography.labelLarge,
                color = contentColor
            )
        }
        DropdownMenu(expanded = pickerOpen, onDismissRequest = { pickerOpen = false }) {
            Row(Modifier.padding(horizontal = 4.dp)) {
                Reactions.all.forEach { emoji ->
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .clickable {
                                pickerOpen = false
                                onReact(emoji)
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        ReactionGlyph(emoji, size = 28.dp)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReactionsSheet(
    reactions: Map<String, String>,
    users: Map<String, UserSummary>,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState()) {
        Text(
            text = stringResource(R.string.reactions_title),
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
        )
        val entries = reactions.entries.toList()
        LazyColumn {
            items(entries, key = { it.key }) { entry ->
                val user = users[entry.key] ?: authorFallbackFor(entry.key)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 56.dp)
                        .padding(horizontal = 24.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    UserAvatar(name = user.displayName, seed = user.uid, photoUrl = user.photoUrl, size = 40.dp)
                    Spacer(Modifier.width(12.dp))
                    Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                        Text(text = user.displayName, style = MaterialTheme.typography.bodyLarge)
                        ProfileBadgeIcon(user.badge, Modifier.padding(start = 4.dp), 16.dp)
                    }
                    ReactionGlyph(entry.value, size = 24.dp)
                }
            }
        }
        Spacer(Modifier.size(24.dp))
    }
}
