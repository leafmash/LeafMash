package com.leafmash.app.feature.wall

import androidx.compose.runtime.setValue
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import kotlin.math.roundToInt
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.leafmash.app.R
import com.leafmash.app.core.data.Reactions
import com.leafmash.app.core.data.UserSummary
import com.leafmash.app.core.data.authorFallbackFor
import com.leafmash.app.core.data.badge
import com.leafmash.app.core.data.displayName
import com.leafmash.app.ui.components.LeafIcons
import com.leafmash.app.ui.components.ProfileBadgeIcon
import com.leafmash.app.ui.theme.LeafPalette
import com.leafmash.app.ui.components.UserAvatar

@Composable
fun ReactionGlyph(
    value: String?,
    modifier: Modifier = Modifier,
    size: Dp = 20.dp,
    tint: Color = Color.Unspecified
) {
    when (value) {
        null -> Icon(
            imageVector = LeafIcons.Outline,
            contentDescription = null,
            tint = if (tint == Color.Unspecified) LocalContentColor.current else tint,
            modifier = modifier.size(size)
        )
        Reactions.LEAF -> Icon(
            imageVector = LeafIcons.Filled,
            contentDescription = null,
            tint = if (tint == Color.Unspecified) MaterialTheme.colorScheme.primary else tint,
            modifier = modifier.size(size)
        )
        else -> Text(text = value, fontSize = (size.value * 0.9f).sp, modifier = modifier)
    }
}

private val PickerItemWidth = 46.dp
private val PickerPadding = 8.dp
private val PickerOuter = 6.dp
private val PickerHeight = 52.dp
private val PickerHeadroom = 22.dp
private val PickerShadow = 8.dp
private val PickerGap = 8.dp

@Composable
fun ReactionButton(
    myReaction: String?,
    onReact: (String) -> Unit,
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    var pickerOpen by remember { mutableStateOf(false) }
    var hovered by remember { mutableIntStateOf(-1) }
    var anchorX by remember { mutableFloatStateOf(0f) }
    val haptics = LocalHapticFeedback.current
    val density = LocalDensity.current
    val screenWidthPx = with(density) { LocalConfiguration.current.screenWidthDp.dp.toPx() }
    val pickerWidthPx = with(density) {
        (PickerItemWidth * Reactions.all.size + PickerPadding * 2 + PickerOuter * 2).toPx()
    }
    val marginPx = with(density) { 8.dp.toPx() }
    val dxPx = anchorX.coerceIn(marginPx, (screenWidthPx - pickerWidthPx - marginPx).coerceAtLeast(marginPx)) - anchorX
    val currentReaction by rememberUpdatedState(myReaction)
    val currentOnReact by rememberUpdatedState(onReact)
    val currentDx by rememberUpdatedState(dxPx)

    val reacted = myReaction != null
    val contentColor = if (reacted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
    val background: Modifier = if (reacted) {
        Modifier.background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = if (compact) 0.7f else 0.9f))
    } else {
        Modifier
    }
    Box(modifier.onGloballyPositioned { anchorX = it.positionInWindow().x }) {
        Row(
            modifier = Modifier
                .then(if (compact) Modifier else Modifier.fillMaxWidth())
                .clip(RoundedCornerShape(if (compact) 20.dp else 14.dp))
                .then(background)
                .semantics {
                    role = Role.Button
                    onClick {
                        currentOnReact(currentReaction ?: Reactions.LEAF)
                        true
                    }
                }
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        if (pickerOpen) {
                            pickerOpen = false
                            hovered = -1
                            waitForUpOrCancellation()
                            return@awaitEachGesture
                        }
                        var cancelled = false
                        val up = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                            waitForUpOrCancellation().also { if (it == null) cancelled = true }
                        }
                        if (up != null) {
                            up.consume()
                            currentOnReact(currentReaction ?: Reactions.LEAF)
                            return@awaitEachGesture
                        }
                        if (cancelled) return@awaitEachGesture
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        pickerOpen = true
                        hovered = -1
                        val itemWidth = PickerItemWidth.toPx()
                        val startOffset = (PickerOuter + PickerPadding).toPx()
                        var moved = false
                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull { it.id == down.id } ?: break
                            if (!moved && (change.position - down.position).getDistance() > viewConfiguration.touchSlop) {
                                moved = true
                            }
                            if (moved && change.pressed) {
                                val x = change.position.x - currentDx - startOffset
                                val index = if (change.position.y <= size.height + 24.dp.toPx() &&
                                    x >= 0f && x < itemWidth * Reactions.all.size
                                ) (x / itemWidth).toInt() else -1
                                if (index != hovered) {
                                    hovered = index
                                    if (index >= 0) haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                }
                            }
                            if (!change.pressed) {
                                val chosen = hovered
                                if (moved) {
                                    pickerOpen = false
                                    hovered = -1
                                    if (chosen >= 0) currentOnReact(Reactions.all[chosen])
                                } else {
                                    hovered = -1
                                }
                                change.consume()
                                break
                            }
                            change.consume()
                        }
                    }
                }
                .heightIn(min = if (compact) 32.dp else 40.dp)
                .padding(horizontal = if (compact) 8.dp else 14.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            CompositionLocalProvider(LocalContentColor provides contentColor) {
                ReactionGlyph(
                    value = myReaction,
                    size = if (compact) 16.dp else 20.dp,
                    tint = contentColor
                )
                Spacer(Modifier.width(if (compact) 6.dp else 8.dp))
                Text(
                    text = stringResource(Reactions.labelRes(myReaction)),
                    style = if (compact) MaterialTheme.typography.labelMedium else MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = contentColor,
                    maxLines = 1
                )
            }
        }
        if (pickerOpen) {
            val yOffset = with(density) { -(PickerHeadroom + PickerHeight + PickerGap).roundToPx() }
            Popup(
                alignment = Alignment.TopStart,
                offset = IntOffset(dxPx.roundToInt(), yOffset),
                onDismissRequest = {
                    pickerOpen = false
                    hovered = -1
                },
                properties = PopupProperties(focusable = false, dismissOnClickOutside = true, clippingEnabled = false)
            ) {
                ReactionPicker(
                    hovered = hovered,
                    onPick = { index ->
                        pickerOpen = false
                        hovered = -1
                        onReact(Reactions.all[index])
                    }
                )
            }
        }
    }
}

@Composable
private fun ReactionPicker(hovered: Int, onPick: (Int) -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val appear by animateFloatAsState(
        targetValue = if (shown) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 500f),
        label = "pickerAppear"
    )
    Box(
        modifier = Modifier
            .padding(start = PickerOuter, end = PickerOuter, bottom = PickerShadow)
            .height(PickerHeight + PickerHeadroom)
            .graphicsLayer {
                val factor = 0.7f + 0.3f * appear
                scaleX = factor
                scaleY = factor
                alpha = appear.coerceIn(0f, 1f)
                transformOrigin = TransformOrigin(0.15f, 1f)
            },
        contentAlignment = Alignment.BottomStart
    ) {
        Surface(
            shape = RoundedCornerShape(50),
            color = MaterialTheme.colorScheme.surfaceContainerLowest,
            shadowElevation = 10.dp,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.height(PickerHeight)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = PickerPadding),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Reactions.all.forEachIndexed { index, emoji ->
                    val scale by animateFloatAsState(
                        targetValue = when {
                            hovered == index -> 1.5f
                            hovered >= 0 -> 0.9f
                            else -> 1f
                        },
                        animationSpec = spring(dampingRatio = 0.55f, stiffness = 600f),
                        label = "pickerItem"
                    )
                    Box(
                        modifier = Modifier
                            .width(PickerItemWidth)
                            .fillMaxHeight()
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { onPick(index) }
                            .graphicsLayer {
                                scaleX = scale
                                scaleY = scale
                                translationY = -(scale - 1f) * 18.dp.toPx()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        ReactionGlyph(emoji, size = 28.dp)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReactionsSheet(
    reactions: Map<String, String>,
    users: Map<String, UserSummary>,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState()) {
        Text(
            text = stringResource(R.string.reactions_title),
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
        )
        val entries = reactions.entries.toList()
        LazyColumn {
            items(entries, key = { it.key }) { entry ->
                val user = users[entry.key] ?: authorFallbackFor(entry.key)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 56.dp)
                        .padding(horizontal = 24.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    UserAvatar(name = user.displayName, seed = user.uid, photoUrl = user.photoUrl, size = 40.dp)
                    Spacer(Modifier.width(12.dp))
                    Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                        Text(text = user.displayName, style = MaterialTheme.typography.bodyLarge)
                        ProfileBadgeIcon(user.badge, Modifier.padding(start = 4.dp), 16.dp)
                    }
                    ReactionGlyph(entry.value, size = 24.dp)
                }
            }
        }
        Spacer(Modifier.size(24.dp))
    }
}
