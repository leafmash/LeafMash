package com.leafmash.app.feature.notifications.data

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.DocumentSnapshot.ServerTimestampBehavior

data class Notice(
    val id: String,
    val text: String,
    val urgent: Boolean,
    val postedByUid: String,
    val postedByName: String,
    val postedByEmail: String,
    val createdAtMs: Long
)

data class ActivityItem(
    val id: String,
    val type: String,
    val text: String,
    val targetUid: String?,
    val postId: String?,
    val resourceId: String?,
    val noticeId: String?,
    val deadlineId: String?,
    val actorUid: String,
    val actorName: String,
    val actorEmail: String,
    val createdAtMs: Long
)

private fun DocumentSnapshot.millis(field: String): Long =
    (get(field, ServerTimestampBehavior.ESTIMATE) as? Timestamp)?.toDate()?.time ?: System.currentTimeMillis()

fun DocumentSnapshot.toNotice(): Notice = Notice(
    id = id,
    text = getString("text").orEmpty(),
    urgent = getBoolean("urgent") == true,
    postedByUid = getString("postedByUid").orEmpty(),
    postedByName = getString("postedByName").orEmpty(),
    postedByEmail = getString("postedBy").orEmpty(),
    createdAtMs = millis("createdAt")
)

fun DocumentSnapshot.toActivityItem(): ActivityItem = ActivityItem(
    id = id,
    type = getString("type").orEmpty(),
    text = getString("text").orEmpty(),
    targetUid = getString("targetUid"),
    postId = getString("postId"),
    resourceId = getString("resourceId"),
    noticeId = getString("noticeId"),
    deadlineId = getString("deadlineId"),
    actorUid = getString("actorUid").orEmpty(),
    actorName = getString("actorName").orEmpty(),
    actorEmail = getString("actorEmail").orEmpty(),
    createdAtMs = millis("createdAt")
)

private val PERSONAL_TYPES = setOf("comment", "reply", "like", "comment-like", "mention", "story-like", "verified")

fun ActivityItem.isVisibleTo(myUid: String, joinedAtMs: Long): Boolean {
    if (type in PERSONAL_TYPES) return targetUid == myUid
    if (actorUid == myUid) return false
    if (joinedAtMs > 0L && createdAtMs < joinedAtMs) return false
    return true
}
