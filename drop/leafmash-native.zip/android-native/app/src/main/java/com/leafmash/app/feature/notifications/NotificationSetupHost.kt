package com.leafmash.app.feature.notifications

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import com.leafmash.app.R
import com.leafmash.app.core.push.BatterySettings
import kotlinx.coroutines.launch

private enum class SetupStep {
    CHECK_PERMISSION,
    RATIONALE,
    CHECK_BATTERY,
    BATTERY,
    CHECK_AUTOSTART,
    AUTOSTART,
    DONE
}

@Composable
fun NotificationSetupHost(viewModel: NotificationSetupViewModel = hiltViewModel()) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var stepName by rememberSaveable { mutableStateOf(SetupStep.CHECK_PERMISSION.name) }
    val step = SetupStep.valueOf(stepName)

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        stepName = SetupStep.CHECK_BATTERY.name
    }

    LaunchedEffect(step) {
        when (step) {
            SetupStep.CHECK_PERMISSION -> {
                val needsPermission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                    ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
                    PackageManager.PERMISSION_GRANTED
                stepName = if (needsPermission && !viewModel.rationaleShown()) {
                    SetupStep.RATIONALE.name
                } else {
                    SetupStep.CHECK_BATTERY.name
                }
            }
            SetupStep.CHECK_BATTERY -> {
                val needed = !viewModel.batteryPrompted() && !BatterySettings.isIgnoringOptimizations(context)
                stepName = if (needed) SetupStep.BATTERY.name else SetupStep.CHECK_AUTOSTART.name
            }
            SetupStep.CHECK_AUTOSTART -> {
                val needed = !viewModel.autostartPrompted() && BatterySettings.hasAutostartSettings()
                stepName = if (needed) SetupStep.AUTOSTART.name else SetupStep.DONE.name
            }
            else -> Unit
        }
    }

    when (step) {
        SetupStep.RATIONALE -> AlertDialog(
            onDismissRequest = {},
            title = { Text(stringResource(R.string.setup_notif_title)) },
            text = { Text(stringResource(R.string.setup_notif_text)) },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        viewModel.markRationaleShown()
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            stepName = SetupStep.CHECK_BATTERY.name
                        }
                    }
                }) { Text(stringResource(R.string.setup_allow)) }
            },
            dismissButton = {
                TextButton(onClick = {
                    scope.launch {
                        viewModel.markRationaleShown()
                        stepName = SetupStep.CHECK_BATTERY.name
                    }
                }) { Text(stringResource(R.string.setup_not_now)) }
            }
        )
        SetupStep.BATTERY -> AlertDialog(
            onDismissRequest = {},
            title = { Text(stringResource(R.string.setup_battery_title)) },
            text = { Text(stringResource(R.string.setup_battery_text)) },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        viewModel.markBatteryPrompted()
                        BatterySettings.requestExemption(context)
                        stepName = SetupStep.CHECK_AUTOSTART.name
                    }
                }) { Text(stringResource(R.string.setup_open_settings)) }
            },
            dismissButton = {
                TextButton(onClick = {
                    scope.launch {
                        viewModel.markBatteryPrompted()
                        stepName = SetupStep.CHECK_AUTOSTART.name
                    }
                }) { Text(stringResource(R.string.setup_not_now)) }
            }
        )
        SetupStep.AUTOSTART -> AlertDialog(
            onDismissRequest = {},
            title = { Text(stringResource(R.string.setup_autostart_title)) },
            text = { Text(stringResource(R.string.setup_autostart_text)) },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        viewModel.markAutostartPrompted()
                        BatterySettings.openAutostartSettings(context)
                        stepName = SetupStep.DONE.name
                    }
                }) { Text(stringResource(R.string.setup_open_settings)) }
            },
            dismissButton = {
                TextButton(onClick = {
                    scope.launch {
                        viewModel.markAutostartPrompted()
                        stepName = SetupStep.DONE.name
                    }
                }) { Text(stringResource(R.string.setup_not_now)) }
            }
        )
        else -> Unit
    }
}
