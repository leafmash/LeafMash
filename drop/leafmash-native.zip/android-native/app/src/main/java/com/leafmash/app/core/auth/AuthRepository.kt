package com.leafmash.app.core.auth

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.leafmash.app.core.data.UserProfile
import com.leafmash.app.core.network.ApiClient
import com.leafmash.app.core.network.ApiException
import com.leafmash.app.core.profile.ProfileRepository
import com.leafmash.app.core.push.PushSession
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

data class SignUpData(
    val name: String,
    val roll: String,
    val phone: String,
    val blood: String,
    val gender: String,
    val email: String,
    val password: String
)

@Singleton
class AuthRepository @Inject constructor(
    private val auth: FirebaseAuth,
    private val api: ApiClient,
    private val profiles: ProfileRepository,
    private val pushSession: PushSession
) {

    @Volatile
    private var pendingSignUp: CompletableDeferred<Unit>? = null

    val authState: Flow<FirebaseUser?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { trySend(it.currentUser) }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    val currentUid: String? get() = auth.currentUser?.uid

    val currentEmail: String? get() = auth.currentUser?.email

    suspend fun awaitPendingSignUp(): Boolean {
        val pending = pendingSignUp ?: return true
        return try {
            pending.await()
            true
        } catch (e: CancellationException) {
            if (pending.isCancelled) false else throw e
        } catch (e: Exception) {
            false
        }
    }

    suspend fun signIn(email: String, password: String): Result<Unit> {
        val cleanEmail = email.trim()
        return try {
            auth.signInWithEmailAndPassword(cleanEmail, password).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val credentialProblem = e is FirebaseAuthInvalidUserException || e is FirebaseAuthInvalidCredentialsException
            if (credentialProblem && usesOnlyOtherProviders(cleanEmail)) {
                Result.failure(GoogleOnlyAccountException())
            } else {
                Result.failure(e)
            }
        }
    }

    suspend fun signUp(data: SignUpData): Result<UserProfile> {
        val email = data.email.trim()
        if (DisposableEmailDomains.isDisposable(email)) {
            return Result.failure(DisposableEmailException())
        }
        val pending = CompletableDeferred<Unit>()
        pendingSignUp = pending
        return try {
            val user = auth.createUserWithEmailAndPassword(email, data.password).await().user
                ?: throw ApiException("Couldn't create your account. Please try again.")
            val payload: JsonObject = buildJsonObject {
                put("name", data.name.trim())
                put("roll", data.roll.trim())
                put("phone", data.phone.trim())
                put("blood", data.blood)
                put("gender", data.gender)
            }
            val response = api.call("create-profile", payload)
            val profileObject = response.getOrNull()?.get("profile") as? JsonObject
            if (profileObject == null) {
                runCatching { user.delete().await() }
                val failure = response.exceptionOrNull() ?: ApiException("Unexpected response from the server.")
                pending.completeExceptionally(failure)
                Result.failure(failure)
            } else {
                val profile = UserProfile.fromJson(profileObject, user.uid)
                profiles.setCurrent(profile)
                pending.complete(Unit)
                Result.success(profile)
            }
        } catch (e: CancellationException) {
            pending.cancel()
            throw e
        } catch (e: Exception) {
            pending.completeExceptionally(e)
            Result.failure(e)
        } finally {
            pendingSignUp = null
        }
    }

    suspend fun signInWithGoogleIdToken(idToken: String): Result<Unit> = try {
        auth.signInWithCredential(GoogleAuthProvider.getCredential(idToken, null)).await()
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun sendPasswordReset(email: String): Result<Unit> = try {
        auth.sendPasswordResetEmail(email.trim()).await()
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun signOut() {
        pushSession.end()
        val uid = auth.currentUser?.uid
        if (uid != null) profiles.clear(uid) else profiles.clearCurrent()
        auth.signOut()
    }

    private suspend fun usesOnlyOtherProviders(email: String): Boolean = try {
        @Suppress("DEPRECATION")
        val methods = auth.fetchSignInMethodsForEmail(email).await().signInMethods.orEmpty()
        methods.isNotEmpty() && "password" !in methods
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        false
    }
}
