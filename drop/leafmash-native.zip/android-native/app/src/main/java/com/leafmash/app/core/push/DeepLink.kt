package com.leafmash.app.core.push

import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed interface DeepLinkTarget {
    data class Post(val postId: String, val focusComment: Boolean) : DeepLinkTarget
    data class Dm(val uid: String) : DeepLinkTarget
    data object ClassChat : DeepLinkTarget
    data object Messages : DeepLinkTarget
    data object Resources : DeepLinkTarget
    data object Notices : DeepLinkTarget
    data object Routine : DeepLinkTarget
    data object Reports : DeepLinkTarget
    data object Home : DeepLinkTarget
}

object DeepLinkParser {

    fun parse(url: String?, type: String?): DeepLinkTarget {
        when (type) {
            "resource" -> return DeepLinkTarget.Resources
            "classChat" -> return DeepLinkTarget.ClassChat
        }
        val fragment = url.orEmpty().substringAfter('#', "")
        val route = fragment.substringBefore('?')
        val query = fragment.substringAfter('?', "")
        val params = query.split('&')
            .filter { it.contains('=') }
            .associate { it.substringBefore('=') to android.net.Uri.decode(it.substringAfter('=')) }
        return when (route) {
            "post-detail" -> {
                val id = params["id"].orEmpty()
                if (id.isEmpty()) DeepLinkTarget.Home else DeepLinkTarget.Post(id, type == "comment" || type == "reply")
            }
            "dm-thread" -> {
                val uid = params["id"].orEmpty()
                if (uid.isEmpty()) DeepLinkTarget.Messages else DeepLinkTarget.Dm(uid)
            }
            "message" -> DeepLinkTarget.Messages
            "notices" -> DeepLinkTarget.Notices
            "routine" -> DeepLinkTarget.Routine
            "reports" -> DeepLinkTarget.Reports
            else -> DeepLinkTarget.Home
        }
    }
}

@Singleton
class DeepLinkHandler @Inject constructor() {

    private val state = MutableStateFlow<DeepLinkTarget?>(null)
    val pending: StateFlow<DeepLinkTarget?> = state.asStateFlow()

    fun post(target: DeepLinkTarget) {
        state.value = target
    }

    fun consume(target: DeepLinkTarget) {
        if (state.value == target) state.value = null
    }
}
