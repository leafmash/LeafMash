package com.leafmash.app.core.push

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PushSession @Inject constructor(
    private val tokens: PushTokenRepository,
    private val dispatcher: NotificationDispatcher
) {

    suspend fun start() {
        tokens.register()
    }

    suspend fun end() {
        tokens.revoke()
        dispatcher.clearAll()
    }
}
