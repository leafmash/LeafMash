package com.leafmash.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.res.stringResource
import com.leafmash.app.R

val LocalOpenProfile = staticCompositionLocalOf<(String) -> Unit> { {} }

val LocalOpenMenu = staticCompositionLocalOf<() -> Unit> { {} }

@Composable
fun MenuAction() {
    val open = LocalOpenMenu.current
    IconButton(onClick = open) {
        Icon(Icons.Filled.Menu, contentDescription = stringResource(R.string.menu_title))
    }
}
