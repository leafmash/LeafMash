package com.leafmash.app.ui.navigation

import androidx.compose.runtime.staticCompositionLocalOf

val LocalOpenProfile = staticCompositionLocalOf<(String) -> Unit> { {} }
