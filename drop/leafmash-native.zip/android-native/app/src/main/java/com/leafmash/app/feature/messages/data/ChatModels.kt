package com.leafmash.app.feature.messages.data

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.DocumentSnapshot.ServerTimestampBehavior
import com.leafmash.app.core.util.UiText
import java.io.File

data class Conversation(
    val id: String,
    val participants: List<String>,
    val lastMessageText: String,
    val lastMessageAtMs: Long,
    val lastSenderUid: String?,
    val lastReadAtMs: Map<String, Long>,
    val blockedBy: List<String>,
    val typingMs: Map<String, Long>,
    val deletedForMs: Map<String, Long>
) {
    fun otherUid(myUid: String): String? = participants.firstOrNull { it != myUid }

    fun isHiddenFor(myUid: String): Boolean {
        val deletedAt = deletedForMs[myUid] ?: return false
        return deletedAt >= lastMessageAtMs
    }

    fun hasMessages(): Boolean = lastSenderUid != null

    fun isUnreadFor(myUid: String): Boolean {
        val sender = lastSenderUid ?: return false
        if (sender == myUid) return false
        return lastMessageAtMs > (lastReadAtMs[myUid] ?: 0L)
    }
}

data class ChatMessage(
    val id: String,
    val senderUid: String,
    val text: String,
    val audioUrl: String,
    val audioDurationSec: Int,
    val createdAtMs: Long,
    val edited: Boolean = false,
    val pending: Boolean = false,
    val failed: Boolean = false,
    val failure: UiText? = null
) {
    val isVoice: Boolean get() = audioUrl.isNotEmpty()
}

private fun Any?.asMillis(): Long? = (this as? Timestamp)?.toDate()?.time

private fun Any?.asMillisMap(): Map<String, Long> {
    val raw = this as? Map<*, *> ?: return emptyMap()
    val result = HashMap<String, Long>()
    for ((key, value) in raw) {
        val millis = value.asMillis()
        if (key is String && millis != null) result[key] = millis
    }
    return result
}

fun DocumentSnapshot.toConversation(): Conversation? {
    if (!exists()) return null
    val participants = (get("participants") as? List<*>)?.filterIsInstance<String>().orEmpty()
    val blocked = (get("blockedBy") as? List<*>)?.filterIsInstance<String>().orEmpty()
    return Conversation(
        id = id,
        participants = participants,
        lastMessageText = getString("lastMessageText").orEmpty(),
        lastMessageAtMs = getTimestamp("lastMessageAt", ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0L,
        lastSenderUid = getString("lastSenderUid"),
        lastReadAtMs = get("lastReadAt", ServerTimestampBehavior.ESTIMATE).asMillisMap(),
        blockedBy = blocked,
        typingMs = get("typing", ServerTimestampBehavior.ESTIMATE).asMillisMap(),
        deletedForMs = get("deletedFor", ServerTimestampBehavior.ESTIMATE).asMillisMap()
    )
}

fun DocumentSnapshot.toDmMessage(): ChatMessage = ChatMessage(
    id = id,
    senderUid = getString("senderUid").orEmpty(),
    text = getString("text").orEmpty(),
    audioUrl = getString("audioUrl").orEmpty(),
    audioDurationSec = getLong("audioDurationSec")?.toInt() ?: 0,
    createdAtMs = getTimestamp("createdAt", ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: System.currentTimeMillis()
)

fun DocumentSnapshot.toClassMessage(): ChatMessage = ChatMessage(
    id = id,
    senderUid = getString("authorUid").orEmpty(),
    text = getString("text").orEmpty(),
    audioUrl = getString("audioUrl").orEmpty(),
    audioDurationSec = getLong("audioDurationSec")?.toInt() ?: 0,
    createdAtMs = getTimestamp("createdAt", ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: System.currentTimeMillis(),
    edited = getBoolean("edited") == true
)

fun PendingMessage.toChatMessage(myUid: String): ChatMessage = ChatMessage(
    id = id,
    senderUid = myUid,
    text = text,
    audioUrl = audioPath?.let { android.net.Uri.fromFile(File(it)).toString() }.orEmpty(),
    audioDurationSec = durationSec,
    createdAtMs = createdAtMs,
    pending = status == PendingStatus.SENDING,
    failed = status == PendingStatus.FAILED,
    failure = error
)
