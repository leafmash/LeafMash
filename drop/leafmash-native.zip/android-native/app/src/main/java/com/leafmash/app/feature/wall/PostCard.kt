package com.leafmash.app.feature.wall

import com.leafmash.app.ui.components.FlatItem
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import android.content.Intent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.leafmash.app.R
import com.leafmash.app.core.data.Post
import com.leafmash.app.core.data.Reactions
import com.leafmash.app.core.data.UserSummary
import com.leafmash.app.core.data.badge
import com.leafmash.app.core.data.displayName
import com.leafmash.app.ui.components.ExpandableRichText
import com.leafmash.app.ui.components.LeafCard
import com.leafmash.app.ui.components.RingAvatar
import com.leafmash.app.ui.components.SocialCard
import com.leafmash.app.core.data.ProfileBadge
import androidx.compose.foundation.shape.CircleShape
import com.leafmash.app.ui.components.ProfileBadgeIcon
import com.leafmash.app.ui.components.UserAvatar
import com.leafmash.app.ui.navigation.LocalOpenProfile
import com.leafmash.app.ui.components.rememberTimeAgo

data class PostCardCallbacks(
    val onOpen: () -> Unit,
    val onReact: (String) -> Unit,
    val onVote: (String) -> Unit,
    val onComment: () -> Unit,
    val onBookmark: () -> Unit,
    val onEdit: () -> Unit,
    val onPin: () -> Unit,
    val onDelete: () -> Unit,
    val onReport: (String) -> Unit,
    val onHashtag: (String) -> Unit,
    val onViewReactions: () -> Unit
)

@Composable
fun PostCard(
    post: Post,
    author: UserSummary,
    commentCount: Int?,
    saved: Boolean,
    myUid: String,
    isAdmin: Boolean,
    callbacks: PostCardCallbacks,
    modifier: Modifier = Modifier,
    openable: Boolean = true
) {
    val context = LocalContext.current
    val openProfile = LocalOpenProfile.current
    val clipboard = LocalClipboardManager.current
    var menuOpen by remember { mutableStateOf(false) }
    var confirmDelete by rememberSaveable { mutableStateOf(false) }
    var reportOpen by rememberSaveable { mutableStateOf(false) }
    var viewerIndex by rememberSaveable { mutableStateOf(-1) }
    val own = post.authorUid == myUid
    val timeAgo = rememberTimeAgo(post.createdAtMs)
    val edited = stringResource(R.string.post_edited)
    val subtitle = buildList {
        add(timeAgo)
        if (post.edited) add(edited)
    }.joinToString(" · ")
    val myReaction = post.reactions[myUid]

    val body: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 14.dp, bottom = 10.dp)
        ) {
            if (post.pinned) {
                Row(
                    modifier = Modifier
                        .padding(start = 16.dp, bottom = 10.dp)
                        .clip(RoundedCornerShape(50))
                        .background(MaterialTheme.colorScheme.tertiaryContainer)
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.PushPin,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(Modifier.width(5.dp))
                    Text(
                        text = stringResource(R.string.post_pinned),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onTertiaryContainer
                    )
                }
            }
            Row(
                modifier = Modifier.padding(start = 10.dp, end = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RingAvatar(
                    name = author.displayName,
                    seed = author.uid,
                    photoUrl = author.photoUrl,
                    size = 42.dp,
                    ring = author.badge != ProfileBadge.NONE,
                    modifier = Modifier.clip(CircleShape).clickable { openProfile(author.uid) }
                )
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f).clickable { openProfile(author.uid) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = author.displayName,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 1,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        ProfileBadgeIcon(author.badge, Modifier.padding(start = 4.dp), 16.dp)
                    }
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                androidx.compose.foundation.layout.Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(
                            imageVector = Icons.Filled.MoreVert,
                            contentDescription = stringResource(R.string.post_more),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.post_copy)) },
                            leadingIcon = { Icon(Icons.Outlined.ContentCopy, null) },
                            onClick = {
                                menuOpen = false
                                clipboard.setText(AnnotatedString(post.text))
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.post_share)) },
                            leadingIcon = { Icon(Icons.Outlined.Share, null) },
                            onClick = {
                                menuOpen = false
                                sharePost(context, author.displayName, post.text)
                            }
                        )
                        if (own) {
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.post_edit)) },
                                leadingIcon = { Icon(Icons.Outlined.Edit, null) },
                                onClick = {
                                    menuOpen = false
                                    callbacks.onEdit()
                                }
                            )
                        }
                        if (isAdmin) {
                            DropdownMenuItem(
                                text = { Text(stringResource(if (post.pinned) R.string.post_unpin else R.string.post_pin)) },
                                leadingIcon = { Icon(Icons.Outlined.PushPin, null) },
                                onClick = {
                                    menuOpen = false
                                    callbacks.onPin()
                                }
                            )
                        }
                        if (own || isAdmin) {
                            DropdownMenuItem(
                                text = { Text(stringResource(if (own) R.string.post_delete else R.string.post_remove_admin)) },
                                leadingIcon = { Icon(Icons.Outlined.Delete, null, tint = MaterialTheme.colorScheme.error) },
                                onClick = {
                                    menuOpen = false
                                    confirmDelete = true
                                }
                            )
                        } else {
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.post_report)) },
                                leadingIcon = { Icon(Icons.Outlined.Flag, null) },
                                onClick = {
                                    menuOpen = false
                                    reportOpen = true
                                }
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            Column(Modifier.padding(horizontal = 16.dp)) {
                ExpandableRichText(
                    text = post.text,
                    mentions = post.mentions,
                    collapsedLines = if (openable) 6 else Int.MAX_VALUE,
                    onHashtagClick = callbacks.onHashtag
                )
                if (post.images.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    PostImageCarousel(
                        images = post.images,
                        onImageClick = { viewerIndex = it },
                        onDoubleTap = { if (myReaction == null) callbacks.onReact(Reactions.LEAF) }
                    )
                }
                val poll = post.poll
                if (poll != null) {
                    Spacer(Modifier.height(12.dp))
                    PollBlock(poll, myUid, callbacks.onVote)
                }
            }
            val reactionTotal = post.reactions.size
            val comments = commentCount ?: 0
            if (reactionTotal > 0 || comments > 0) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (reactionTotal > 0) {
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .clickable(onClick = callbacks.onViewReactions)
                                .heightIn(min = 32.dp)
                                .padding(horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Reactions.top(post.reactions, 3).forEach { ReactionGlyph(it, size = 16.dp) }
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = context.resources.getQuantityString(R.plurals.reactions_count, reactionTotal, reactionTotal),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        Spacer(Modifier.width(1.dp))
                    }
                    if (comments > 0) {
                        Text(
                            text = context.resources.getQuantityString(R.plurals.comments_count, comments, comments),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .clickable(onClick = callbacks.onComment)
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                        )
                    }
                }
            }
            HorizontalDivider(
                modifier = Modifier.padding(horizontal = 14.dp).padding(top = 8.dp),
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp)
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ReactionButton(
                    myReaction = myReaction,
                    onReact = callbacks.onReact,
                    modifier = Modifier.weight(1.3f)
                )
                PostAction(
                    icon = Icons.Outlined.ChatBubbleOutline,
                    label = stringResource(R.string.post_comment),
                    onClick = callbacks.onComment,
                    modifier = Modifier.weight(1.3f)
                )
                PostAction(
                    icon = Icons.Outlined.Share,
                    label = null,
                    description = stringResource(R.string.post_share),
                    onClick = { sharePost(context, author.displayName, post.text) },
                    modifier = Modifier.weight(0.7f)
                )
                PostAction(
                    icon = if (saved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                    label = null,
                    description = stringResource(if (saved) R.string.post_unsave else R.string.post_save),
                    tint = if (saved) MaterialTheme.colorScheme.primary else null,
                    onClick = callbacks.onBookmark,
                    modifier = Modifier.weight(0.7f)
                )
            }
        }
    }
    if (openable) {
        SocialCard(modifier = modifier, onClick = callbacks.onOpen, content = body)
    } else {
        FlatItem(modifier = modifier.fillMaxWidth(), onClick = null, gap = false, content = body)
    }

    if (viewerIndex >= 0) {
        ImageViewerDialog(images = post.images, startIndex = viewerIndex, onDismiss = { viewerIndex = -1 })
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(stringResource(if (own) R.string.post_delete_title else R.string.post_remove_title)) },
            text = { Text(stringResource(if (own) R.string.post_delete_text else R.string.post_remove_text)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    callbacks.onDelete()
                }) {
                    Text(
                        text = stringResource(if (own) R.string.action_delete else R.string.action_remove),
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
    if (reportOpen) {
        var reason by rememberSaveable { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { reportOpen = false },
            title = { Text(stringResource(R.string.report_title)) },
            text = {
                Column {
                    Text(
                        text = stringResource(R.string.report_hint),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = reason,
                        onValueChange = { if (it.length <= REPORT_REASON_LIMIT) reason = it },
                        placeholder = { Text(stringResource(R.string.report_reason_placeholder)) },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    reportOpen = false
                    callbacks.onReport(reason)
                }) { Text(stringResource(R.string.report_send)) }
            },
            dismissButton = {
                TextButton(onClick = { reportOpen = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
}

private const val REPORT_REASON_LIMIT = 500

@Composable
private fun PostAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    description: String? = label,
    tint: androidx.compose.ui.graphics.Color? = null
) {
    val color = tint ?: MaterialTheme.colorScheme.onSurfaceVariant
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .heightIn(min = 42.dp)
            .padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = description,
            tint = color,
            modifier = Modifier.size(20.dp)
        )
        if (label != null) {
            Spacer(Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = color,
                maxLines = 1
            )
        }
    }
}

@Composable
fun DashedDivider(modifier: Modifier = Modifier) {
    val color = MaterialTheme.colorScheme.outlineVariant
    Canvas(modifier = modifier.fillMaxWidth().height(1.dp)) {
        drawLine(
            color = color,
            start = Offset(0f, 0f),
            end = Offset(size.width, 0f),
            strokeWidth = 1.5f,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))
        )
    }
}

private fun sharePost(context: android.content.Context, authorName: String, text: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, "$authorName: $text")
    }
    context.startActivity(Intent.createChooser(send, null))
}
