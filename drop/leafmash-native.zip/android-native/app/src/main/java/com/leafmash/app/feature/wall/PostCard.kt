package com.leafmash.app.feature.wall

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.leafmash.app.R
import com.leafmash.app.core.data.Post
import com.leafmash.app.core.data.Reactions
import com.leafmash.app.core.data.UserSummary
import com.leafmash.app.core.data.badge
import com.leafmash.app.core.data.displayName
import com.leafmash.app.ui.components.ExpandableRichText
import com.leafmash.app.ui.components.ProfileBadgeIcon
import com.leafmash.app.ui.components.UserAvatar
import com.leafmash.app.ui.components.rememberTimeAgo

data class PostCardCallbacks(
    val onOpen: () -> Unit,
    val onReact: (String) -> Unit,
    val onVote: (String) -> Unit,
    val onComment: () -> Unit,
    val onBookmark: () -> Unit,
    val onEdit: () -> Unit,
    val onPin: () -> Unit,
    val onDelete: () -> Unit,
    val onReport: (String) -> Unit,
    val onHashtag: (String) -> Unit,
    val onViewReactions: () -> Unit
)

@Composable
fun PostCard(
    post: Post,
    author: UserSummary,
    commentCount: Int?,
    saved: Boolean,
    myUid: String,
    isAdmin: Boolean,
    callbacks: PostCardCallbacks,
    modifier: Modifier = Modifier,
    openable: Boolean = true
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var menuOpen by remember { mutableStateOf(false) }
    var confirmDelete by rememberSaveable { mutableStateOf(false) }
    var reportOpen by rememberSaveable { mutableStateOf(false) }
    var viewerIndex by rememberSaveable { mutableStateOf(-1) }
    val own = post.authorUid == myUid
    val timeAgo = rememberTimeAgo(post.createdAtMs)
    val edited = stringResource(R.string.post_edited)
    val subtitle = buildList {
        add(timeAgo)
        if (post.edited) add(edited)
    }.joinToString(" · ")
    val myReaction = post.reactions[myUid]

    Column(modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .then(if (openable) Modifier.clickable(onClick = callbacks.onOpen) else Modifier)
                .padding(start = 16.dp, end = 4.dp, top = 12.dp, bottom = 4.dp)
        ) {
            if (post.pinned) {
                Row(Modifier.padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.PushPin,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = stringResource(R.string.post_pinned),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                UserAvatar(name = author.displayName, seed = author.uid, photoUrl = author.photoUrl, size = 44.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = author.displayName,
                            style = MaterialTheme.typography.titleSmall,
                            maxLines = 1,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        ProfileBadgeIcon(author.badge, Modifier.padding(start = 4.dp), 16.dp)
                    }
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = callbacks.onBookmark) {
                    Icon(
                        imageVector = if (saved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                        contentDescription = stringResource(if (saved) R.string.post_unsave else R.string.post_save),
                        tint = if (saved) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                androidx.compose.foundation.layout.Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(
                            imageVector = Icons.Filled.MoreVert,
                            contentDescription = stringResource(R.string.post_more)
                        )
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.post_copy)) },
                            leadingIcon = { Icon(Icons.Outlined.ContentCopy, null) },
                            onClick = {
                                menuOpen = false
                                clipboard.setText(AnnotatedString(post.text))
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.post_share)) },
                            leadingIcon = { Icon(Icons.Outlined.Share, null) },
                            onClick = {
                                menuOpen = false
                                sharePost(context, author.displayName, post.text)
                            }
                        )
                        if (own) {
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.post_edit)) },
                                leadingIcon = { Icon(Icons.Outlined.Edit, null) },
                                onClick = {
                                    menuOpen = false
                                    callbacks.onEdit()
                                }
                            )
                        }
                        if (isAdmin) {
                            DropdownMenuItem(
                                text = { Text(stringResource(if (post.pinned) R.string.post_unpin else R.string.post_pin)) },
                                leadingIcon = { Icon(Icons.Outlined.PushPin, null) },
                                onClick = {
                                    menuOpen = false
                                    callbacks.onPin()
                                }
                            )
                        }
                        if (own || isAdmin) {
                            DropdownMenuItem(
                                text = { Text(stringResource(if (own) R.string.post_delete else R.string.post_remove_admin)) },
                                leadingIcon = { Icon(Icons.Outlined.Delete, null, tint = MaterialTheme.colorScheme.error) },
                                onClick = {
                                    menuOpen = false
                                    confirmDelete = true
                                }
                            )
                        } else {
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.post_report)) },
                                leadingIcon = { Icon(Icons.Outlined.Flag, null) },
                                onClick = {
                                    menuOpen = false
                                    reportOpen = true
                                }
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Column(Modifier.padding(end = 12.dp)) {
                ExpandableRichText(
                    text = post.text,
                    mentions = post.mentions,
                    collapsedLines = if (openable) 6 else Int.MAX_VALUE,
                    onHashtagClick = callbacks.onHashtag
                )
                if (post.images.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    PostImageGrid(post.images, onImageClick = { viewerIndex = it })
                }
                val poll = post.poll
                if (poll != null) {
                    Spacer(Modifier.height(12.dp))
                    PollBlock(poll, myUid, callbacks.onVote)
                }
            }
            val reactionTotal = post.reactions.size
            val comments = commentCount ?: 0
            if (reactionTotal > 0 || comments > 0) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(end = 12.dp, top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (reactionTotal > 0) {
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable(onClick = callbacks.onViewReactions)
                                .heightIn(min = 32.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Reactions.top(post.reactions, 3).forEach { ReactionGlyph(it, size = 16.dp) }
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = context.resources.getQuantityString(R.plurals.reactions_count, reactionTotal, reactionTotal),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        Spacer(Modifier.width(1.dp))
                    }
                    if (comments > 0) {
                        Text(
                            text = context.resources.getQuantityString(R.plurals.comments_count, comments, comments),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable(onClick = callbacks.onComment)
                                .padding(8.dp)
                        )
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                ReactionButton(myReaction = myReaction, onReact = callbacks.onReact)
                TextButton(onClick = callbacks.onComment, modifier = Modifier.heightIn(min = 48.dp)) {
                    Icon(
                        imageVector = Icons.Outlined.ChatBubbleOutline,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.post_comment))
                }
            }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
    }

    if (viewerIndex >= 0) {
        ImageViewerDialog(images = post.images, startIndex = viewerIndex, onDismiss = { viewerIndex = -1 })
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(stringResource(if (own) R.string.post_delete_title else R.string.post_remove_title)) },
            text = { Text(stringResource(if (own) R.string.post_delete_text else R.string.post_remove_text)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    callbacks.onDelete()
                }) {
                    Text(
                        text = stringResource(if (own) R.string.action_delete else R.string.action_remove),
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
    if (reportOpen) {
        var reason by rememberSaveable { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { reportOpen = false },
            title = { Text(stringResource(R.string.report_title)) },
            text = {
                Column {
                    Text(
                        text = stringResource(R.string.report_hint),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = reason,
                        onValueChange = { if (it.length <= REPORT_REASON_LIMIT) reason = it },
                        placeholder = { Text(stringResource(R.string.report_reason_placeholder)) },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    reportOpen = false
                    callbacks.onReport(reason)
                }) { Text(stringResource(R.string.report_send)) }
            },
            dismissButton = {
                TextButton(onClick = { reportOpen = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
}

private const val REPORT_REASON_LIMIT = 500

private fun sharePost(context: android.content.Context, authorName: String, text: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, "$authorName: $text")
    }
    context.startActivity(Intent.createChooser(send, null))
}
