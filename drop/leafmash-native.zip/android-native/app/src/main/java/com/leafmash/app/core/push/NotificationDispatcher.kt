package com.leafmash.app.core.push

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.Person
import androidx.core.app.RemoteInput
import androidx.core.content.ContextCompat
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import com.google.firebase.auth.FirebaseAuth
import com.leafmash.app.MainActivity
import com.leafmash.app.R
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.cancellation.CancellationException

@Singleton
class NotificationDispatcher @Inject constructor(
    @ApplicationContext private val context: Context,
    private val auth: FirebaseAuth,
    private val store: ChatNotificationStore
) {

    @Volatile
    private var activeChat: String? = null

    fun setActiveChat(chatKey: String?) {
        activeChat = chatKey
        if (chatKey != null) cancelChat(chatKey)
    }

    fun cancelChat(chatKey: String) {
        store.clear(chatKey)
        NotificationManagerCompat.from(context).cancel(chatNotificationId(chatKey))
    }

    fun clearAll() {
        NotificationManagerCompat.from(context).cancelAll()
        store.clearAll()
    }

    fun ensureChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        val soundUri = Uri.parse("android.resource://${context.packageName}/${R.raw.leafmash_message}")
        val chatSound = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION_COMMUNICATION_INSTANT)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val messages = NotificationChannel(
            PushChannels.MESSAGES,
            context.getString(R.string.push_channel_messages),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = context.getString(R.string.push_channel_messages_desc)
            setSound(soundUri, chatSound)
        }
        val social = NotificationChannel(
            PushChannels.SOCIAL,
            context.getString(R.string.push_channel_social),
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply { description = context.getString(R.string.push_channel_social_desc) }
        val announcements = NotificationChannel(
            PushChannels.ANNOUNCEMENTS,
            context.getString(R.string.push_channel_announcements),
            NotificationManager.IMPORTANCE_HIGH
        ).apply { description = context.getString(R.string.push_channel_announcements_desc) }
        val reminders = NotificationChannel(
            PushChannels.REMINDERS,
            context.getString(R.string.push_channel_reminders),
            NotificationManager.IMPORTANCE_HIGH
        ).apply { description = context.getString(R.string.push_channel_reminders_desc) }
        manager.createNotificationChannels(listOf(messages, social, announcements, reminders))
    }

    suspend fun handle(data: Map<String, String>) {
        val myUid = auth.currentUser?.uid ?: return
        ensureChannels()
        when (data["type"].orEmpty()) {
            "dm" -> handleDm(myUid, data)
            "classChat" -> handleClassChat(myUid, data)
            else -> handleGeneral(data)
        }
    }

    fun showReplyFailed() {
        val notification = NotificationCompat.Builder(context, PushChannels.MESSAGES)
            .setSmallIcon(R.drawable.ic_stat_notify)
            .setColor(ContextCompat.getColor(context, R.color.notification_icon_color))
            .setContentTitle(context.getString(R.string.push_reply_failed_title))
            .setContentText(context.getString(R.string.push_reply_failed_text))
            .setAutoCancel(true)
            .setContentIntent(openIntent(REPLY_FAILED_ID, "/#message", "dm"))
            .build()
        post(REPLY_FAILED_ID, notification)
    }

    private suspend fun handleDm(myUid: String, data: Map<String, String>) {
        val conversationId = data["conversationId"].orEmpty()
        val senderUid = data["senderUid"].orEmpty()
        if (conversationId.isEmpty() || senderUid.isEmpty() || senderUid == myUid) return
        val messageId = data["messageId"].orEmpty()
        if (messageId.isNotEmpty() && !store.markSeen("dm:$messageId")) return
        val chatKey = ChatKeys.dm(conversationId)
        val senderName = data["senderName"]?.takeIf { it.isNotBlank() }
            ?: data["title"]?.takeIf { it.isNotBlank() }
            ?: context.getString(R.string.app_name)
        store.addMessage(
            chatKey,
            StoredMessage(data["body"].orEmpty(), false, senderUid, senderName, System.currentTimeMillis())
        )
        data["senderPhotoURL"]?.takeIf { it.isNotBlank() }?.let { store.setPhoto(senderUid, it) }
        store.setTitle(chatKey, senderName)
        if (activeChat == chatKey) {
            store.clear(chatKey)
            return
        }
        store.incrementUnread(chatKey)
        showChat(
            chatKey = chatKey,
            title = senderName,
            group = false,
            url = data["url"]?.takeIf { it.isNotBlank() } ?: "/#dm-thread?id=$senderUid",
            type = "dm",
            targetUid = senderUid,
            conversationId = conversationId
        )
    }

    private suspend fun handleClassChat(myUid: String, data: Map<String, String>) {
        val senderUid = data["senderUid"].orEmpty()
        if (senderUid.isEmpty() || senderUid == myUid) return
        val messageId = data["messageId"].orEmpty()
        if (messageId.isNotEmpty() && !store.markSeen("class:$messageId")) return
        val senderName = data["senderName"]?.takeIf { it.isNotBlank() } ?: context.getString(R.string.push_someone)
        store.addMessage(
            ChatKeys.CLASS_CHAT,
            StoredMessage(data["body"].orEmpty(), false, senderUid, senderName, System.currentTimeMillis())
        )
        data["senderPhotoURL"]?.takeIf { it.isNotBlank() }?.let { store.setPhoto(senderUid, it) }
        if (activeChat == ChatKeys.CLASS_CHAT) {
            store.clear(ChatKeys.CLASS_CHAT)
            return
        }
        store.incrementUnread(ChatKeys.CLASS_CHAT)
        showChat(
            chatKey = ChatKeys.CLASS_CHAT,
            title = context.getString(R.string.chat_class_title),
            group = true,
            url = data["url"]?.takeIf { it.isNotBlank() } ?: "/#message",
            type = "classChat",
            targetUid = null,
            conversationId = null
        )
    }

    private suspend fun showChat(
        chatKey: String,
        title: String,
        group: Boolean,
        url: String,
        type: String,
        targetUid: String?,
        conversationId: String?
    ) {
        val notificationId = chatNotificationId(chatKey)
        val me = Person.Builder().setName(context.getString(R.string.push_you)).setKey(ME_KEY).build()
        val style = NotificationCompat.MessagingStyle(me)
            .setConversationTitle(title)
            .setGroupConversation(group)

        val stored = store.messages(chatKey)
        val unread = store.unread(chatKey)
        val historic = (stored.size - unread).coerceAtLeast(0)
        val persons = HashMap<String, Person>()
        val icons = HashMap<String, IconCompat?>()
        var latestSender: String? = null
        stored.forEachIndexed { index, message ->
            val person = if (message.fromMe) {
                null
            } else {
                persons.getOrPut(message.senderUid) {
                    val icon = NotificationAvatars.load(context, store.photo(message.senderUid))
                    icons[message.senderUid] = icon
                    Person.Builder()
                        .setName(message.senderName.ifBlank { title })
                        .setKey(message.senderUid)
                        .setImportant(true)
                        .apply { icon?.let { setIcon(it) } }
                        .build()
                }
            }
            if (!message.fromMe) latestSender = message.senderUid
            val entry = NotificationCompat.MessagingStyle.Message(message.text, message.timestamp, person)
            if (index < historic) style.addHistoricMessage(entry) else style.addMessage(entry)
        }

        latestSender?.let { uid ->
            persons[uid]?.let { person -> pushShortcut(chatKey, title, icons[uid], person, url, type) }
        }

        val builder = NotificationCompat.Builder(context, PushChannels.MESSAGES)
            .setSmallIcon(R.drawable.ic_stat_notify)
            .setColor(ContextCompat.getColor(context, R.color.notification_icon_color))
            .setStyle(style)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setNumber(unread)
            .setShortcutId(chatKey)
            .setContentIntent(openIntent(notificationId, url, type))
            .setDeleteIntent(actionIntent(PushActions.DISMISS, chatKey, targetUid, conversationId, notificationId, false))
            .addAction(replyAction(chatKey, targetUid, conversationId, notificationId))
            .addAction(markReadAction(chatKey, targetUid, conversationId, notificationId))
        post(notificationId, builder.build())
    }

    private fun handleGeneral(data: Map<String, String>) {
        val type = data["type"].orEmpty()
        val title = data["title"]?.takeIf { it.isNotBlank() } ?: context.getString(R.string.app_name)
        val body = data["body"].orEmpty()
        val url = data["url"]?.takeIf { it.isNotBlank() } ?: "/"
        val channel = channelFor(type)
        val groupKey = "leafmash_group_$channel"
        val notificationId = "$type|$url|$title".hashCode()
        val notification = NotificationCompat.Builder(context, channel)
            .setSmallIcon(R.drawable.ic_stat_notify)
            .setColor(ContextCompat.getColor(context, R.color.notification_icon_color))
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setGroup(groupKey)
            .setPriority(
                if (channel == PushChannels.SOCIAL) NotificationCompat.PRIORITY_DEFAULT else NotificationCompat.PRIORITY_HIGH
            )
            .setContentIntent(openIntent(notificationId, url, type))
            .build()
        post(notificationId, notification)
        postSummaryIfNeeded(channel, groupKey)
    }

    private fun postSummaryIfNeeded(channel: String, groupKey: String) {
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        val active = try {
            manager.activeNotifications.count { it.notification.group == groupKey && it.id != summaryId(channel) }
        } catch (e: Exception) {
            0
        }
        if (active < 2) return
        val label = when (channel) {
            PushChannels.SOCIAL -> context.getString(R.string.push_channel_social)
            PushChannels.ANNOUNCEMENTS -> context.getString(R.string.push_channel_announcements)
            else -> context.getString(R.string.push_channel_reminders)
        }
        val summary = NotificationCompat.Builder(context, channel)
            .setSmallIcon(R.drawable.ic_stat_notify)
            .setColor(ContextCompat.getColor(context, R.color.notification_icon_color))
            .setContentTitle(label)
            .setContentText(context.getString(R.string.push_summary_text, active))
            .setStyle(NotificationCompat.InboxStyle().setSummaryText(label))
            .setGroup(groupKey)
            .setGroupSummary(true)
            .setAutoCancel(true)
            .setContentIntent(openIntent(summaryId(channel), "/", ""))
            .build()
        post(summaryId(channel), summary)
    }

    private fun channelFor(type: String): String = when (type) {
        "notice", "deadline", "routine", "report" -> PushChannels.ANNOUNCEMENTS
        "deadline-reminder" -> PushChannels.REMINDERS
        else -> PushChannels.SOCIAL
    }

    private fun summaryId(channel: String): Int = ("summary:$channel").hashCode()

    private fun chatNotificationId(chatKey: String): Int = chatKey.hashCode()

    private fun openIntent(requestCode: Int, url: String, type: String): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            putExtra(PushExtras.URL, url)
            putExtra(PushExtras.TYPE, type)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        return PendingIntent.getActivity(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    private fun actionIntent(
        action: String,
        chatKey: String,
        targetUid: String?,
        conversationId: String?,
        notificationId: Int,
        mutable: Boolean
    ): PendingIntent {
        val intent = Intent(context, NotificationActionReceiver::class.java).apply {
            this.action = action
            putExtra(PushExtras.CHAT_KEY, chatKey)
            putExtra(PushExtras.TARGET_UID, targetUid)
            putExtra(PushExtras.CONVERSATION_ID, conversationId)
            putExtra(PushExtras.NOTIFICATION_ID, notificationId)
        }
        val flags = if (mutable) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        }
        return PendingIntent.getBroadcast(context, "$action:$chatKey".hashCode(), intent, flags)
    }

    private fun replyAction(
        chatKey: String,
        targetUid: String?,
        conversationId: String?,
        notificationId: Int
    ): NotificationCompat.Action {
        val remoteInput = RemoteInput.Builder(PushExtras.REPLY_TEXT)
            .setLabel(context.getString(R.string.push_action_reply))
            .build()
        return NotificationCompat.Action.Builder(
            android.R.drawable.ic_menu_send,
            context.getString(R.string.push_action_reply),
            actionIntent(PushActions.REPLY, chatKey, targetUid, conversationId, notificationId, true)
        )
            .addRemoteInput(remoteInput)
            .setAllowGeneratedReplies(true)
            .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_REPLY)
            .setShowsUserInterface(false)
            .build()
    }

    private fun markReadAction(
        chatKey: String,
        targetUid: String?,
        conversationId: String?,
        notificationId: Int
    ): NotificationCompat.Action = NotificationCompat.Action.Builder(
        android.R.drawable.ic_menu_agenda,
        context.getString(R.string.push_action_mark_read),
        actionIntent(PushActions.MARK_READ, chatKey, targetUid, conversationId, notificationId, false)
    )
        .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_MARK_AS_READ)
        .setShowsUserInterface(false)
        .build()

    private fun pushShortcut(
        chatKey: String,
        title: String,
        icon: IconCompat?,
        person: Person,
        url: String,
        type: String
    ) {
        try {
            val intent = Intent(context, MainActivity::class.java).apply {
                action = Intent.ACTION_VIEW
                putExtra(PushExtras.URL, url)
                putExtra(PushExtras.TYPE, type)
            }
            val builder = ShortcutInfoCompat.Builder(context, chatKey)
                .setShortLabel(title)
                .setLongLived(true)
                .setPerson(person)
                .setIntent(intent)
                .setCategories(setOf("android.shortcut.conversation"))
            icon?.let { builder.setIcon(it) }
            ShortcutManagerCompat.pushDynamicShortcut(context, builder.build())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Unit
        }
    }

    @SuppressLint("MissingPermission")
    private fun post(id: Int, notification: Notification) {
        val allowed = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        if (!allowed) return
        NotificationManagerCompat.from(context).notify(id, notification)
    }

    private companion object {
        const val ME_KEY = "leafmash_me"
        const val REPLY_FAILED_ID = 7_101
    }
}
