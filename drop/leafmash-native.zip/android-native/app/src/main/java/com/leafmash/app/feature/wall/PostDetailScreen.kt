package com.leafmash.app.feature.wall

import com.leafmash.app.ui.theme.LeafPalette
import com.leafmash.app.ui.components.LeafCard
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.background
import com.leafmash.app.ui.components.LeafTopAppBar
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leafmash.app.R
import com.leafmash.app.core.data.Comment
import com.leafmash.app.core.data.authorFallback
import com.leafmash.app.core.data.displayName
import com.leafmash.app.core.util.asString
import com.leafmash.app.ui.components.CollectSnackbars
import com.leafmash.app.ui.components.MentionInputState
import com.leafmash.app.ui.components.MentionSuggestionList
import com.leafmash.app.ui.components.SkeletonPost

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostDetailScreen(
    onBack: () -> Unit,
    onEditPost: (String) -> Unit,
    onOpenHashtag: (String) -> Unit,
    viewModel: PostDetailViewModel = hiltViewModel()
) {
    val detail by viewModel.detail.collectAsStateWithLifecycle()
    val pending by viewModel.visiblePending.collectAsStateWithLifecycle()
    val saved by viewModel.saved.collectAsStateWithLifecycle()
    val users by viewModel.users.collectAsStateWithLifecycle()
    val students by viewModel.students.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val focus = remember { FocusRequester() }
    var reactionsFor by remember { mutableStateOf<Map<String, String>?>(null) }
    var editing by remember { mutableStateOf<Comment?>(null) }
    var deleting by remember { mutableStateOf<Comment?>(null) }
    var expanded by remember { mutableStateOf(setOf<String>()) }
    val myUid = viewModel.myUid
    val isAdmin = viewModel.isAdmin
    val post = detail.post
    val input = viewModel.input

    CollectSnackbars(viewModel.events, snackbar)
    LaunchedEffect(post != null) {
        if (post != null && viewModel.focusComment) runCatching { focus.requestFocus() }
    }
    LaunchedEffect(input.query != null) {
        if (input.query != null) viewModel.loadStudents()
    }

    val topLevel = remember(detail.comments) { detail.comments.filter { it.replyTo == null } }
    val repliesByParent = remember(detail.comments) {
        detail.comments.filter { it.replyTo != null }.groupBy { it.replyTo?.id.orEmpty() }
    }
    val orphans = remember(topLevel, repliesByParent) {
        val ids = topLevel.map { it.id }.toSet()
        repliesByParent.filterKeys { it !in ids }.values.flatten()
    }
    val pendingTop = pending.filter { it.replyTo == null }
    val pendingByParent = pending.filter { it.replyTo != null }.groupBy { it.replyTo?.id.orEmpty() }

    Scaffold(
        topBar = {
            LeafTopAppBar(
                title = {
                    Text(
                        text = if (post != null) {
                            stringResource(R.string.post_detail_title_named, (users[post.authorUid] ?: post.authorFallback()).displayName)
                        } else {
                            stringResource(R.string.post_detail_title)
                        },
                        maxLines = 1
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            if (post != null) {
                CommentBar(
                    viewModel = viewModel,
                    students = students,
                    sending = viewModel.sending,
                    focus = focus
                )
            }
        }
    ) { inner ->
        Box(Modifier.fillMaxSize().padding(inner)) {
            when {
                detail.loading -> Column { SkeletonPost() }
                detail.missing || post == null -> Text(
                    text = detail.error?.asString() ?: stringResource(R.string.post_missing),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(32.dp)
                )
                else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 7.dp)) {
                    item(key = "post") {
                        PostCard(
                            post = post,
                            author = users[post.authorUid] ?: post.authorFallback(),
                            commentCount = if (detail.commentsLoaded) detail.comments.size else post.commentCount,
                            saved = saved,
                            myUid = myUid,
                            isAdmin = isAdmin,
                            openable = false,
                            callbacks = postCallbacks(
                                viewModel = viewModel,
                                post = post,
                                saved = saved,
                                onOpenPost = { _, _ -> runCatching { focus.requestFocus() } },
                                onEditPost = onEditPost,
                                onOpenHashtag = onOpenHashtag,
                                onViewReactions = { reactionsFor = it.reactions },
                                onDeleted = onBack
                            )
                        )
                    }
                    if (!detail.commentsLoaded) {
                        item(key = "comments_loading") { SkeletonPost() }
                    } else if (detail.comments.isEmpty() && pending.isEmpty()) {
                        item(key = "comments_empty") {
                            Text(
                                text = stringResource(R.string.comments_empty),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth().padding(24.dp)
                            )
                        }
                    }
                    items(topLevel, key = { "thread_${it.id}" }) { comment ->
                        val replies = repliesByParent[comment.id].orEmpty()
                        val pendingReplies = pendingByParent[comment.id].orEmpty()
                        val open = comment.id in expanded || pendingReplies.isNotEmpty()
                        ThreadCard {
                            CommentRow(
                                comment = comment,
                                isReply = false,
                                parentAuthorUid = null,
                                viewModel = viewModel,
                                users = users,
                                myUid = myUid,
                                isAdmin = isAdmin,
                                postAuthorUid = post.authorUid,
                                onEdit = { editing = it },
                                onDelete = { deleting = it },
                                onShowReactions = { reactionsFor = it.reactions },
                                onOpenHashtag = onOpenHashtag
                            )
                            if (replies.isNotEmpty()) {
                                Text(
                                    text = if (open) {
                                        stringResource(R.string.comment_hide_replies)
                                    } else {
                                        androidx.compose.ui.platform.LocalContext.current.resources
                                            .getQuantityString(R.plurals.comment_view_replies, replies.size, replies.size)
                                    },
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier
                                        .padding(start = 44.dp, top = 4.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .clickable {
                                            expanded = if (comment.id in expanded) expanded - comment.id else expanded + comment.id
                                        }
                                        .padding(horizontal = 8.dp, vertical = 8.dp)
                                )
                            }
                            if (open) {
                                Column(Modifier.padding(start = 44.dp)) {
                                    replies.forEach { reply ->
                                        CommentRow(
                                            comment = reply,
                                            isReply = true,
                                            parentAuthorUid = comment.authorUid,
                                            viewModel = viewModel,
                                            users = users,
                                            myUid = myUid,
                                            isAdmin = isAdmin,
                                            postAuthorUid = post.authorUid,
                                            onEdit = { editing = it },
                                            onDelete = { deleting = it },
                                            onShowReactions = { reactionsFor = it.reactions },
                                            onOpenHashtag = onOpenHashtag
                                        )
                                    }
                                    pendingReplies.forEach { PendingCommentItem(it, users[myUid]) }
                                }
                            }
                        }
                    }
                    items(orphans, key = { "orphan_${it.id}" }) { comment ->
                        ThreadCard {
                            CommentRow(
                                comment = comment,
                                isReply = true,
                                parentAuthorUid = null,
                                viewModel = viewModel,
                                users = users,
                                myUid = myUid,
                                isAdmin = isAdmin,
                                postAuthorUid = post.authorUid,
                                onEdit = { editing = it },
                                onDelete = { deleting = it },
                                onShowReactions = { reactionsFor = it.reactions },
                                onOpenHashtag = onOpenHashtag
                            )
                        }
                    }
                    items(pendingTop, key = { "pending_${it.tempId}" }) { item ->
                        ThreadCard {
                            PendingCommentItem(item, users[myUid])
                        }
                    }
                    item(key = "bottom_space") { Spacer(Modifier.height(24.dp)) }
                }
            }
        }
    }

    val shown = reactionsFor
    if (shown != null) {
        LaunchedEffect(shown) { viewModel.ensureUsers(shown.keys) }
        ReactionsSheet(reactions = shown, users = users, onDismiss = { reactionsFor = null })
    }

    val toEdit = editing
    if (toEdit != null) {
        val editState = remember(toEdit.id) {
            MentionInputState(PostDetailViewModel.COMMENT_LIMIT).also { it.setContent(toEdit.text, toEdit.mentions) }
        }
        LaunchedEffect(editState.query != null) {
            if (editState.query != null) viewModel.loadStudents()
        }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text(stringResource(R.string.comment_edit_title)) },
            text = {
                Column {
                    OutlinedTextField(
                        value = editState.value,
                        onValueChange = editState::onChange,
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth(),
                        supportingText = {
                            Text(
                                text = "${editState.text.length}/${PostDetailViewModel.COMMENT_LIMIT}",
                                textAlign = TextAlign.End,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    )
                    MentionSuggestionList(
                        suggestions = editState.suggestions(students, myUid),
                        onPick = editState::pick
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = editState.text.isNotBlank(),
                    onClick = {
                        viewModel.editComment(toEdit, editState.text, editState.mentions()) { editing = null }
                    }
                ) { Text(stringResource(R.string.composer_save)) }
            },
            dismissButton = {
                TextButton(onClick = { editing = null }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }

    val toDelete = deleting
    if (toDelete != null) {
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text(stringResource(R.string.comment_delete_title)) },
            text = { Text(stringResource(R.string.comment_delete_text)) },
            confirmButton = {
                TextButton(onClick = {
                    deleting = null
                    viewModel.deleteComment(toDelete)
                }) { Text(stringResource(R.string.action_delete), color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { deleting = null }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
}

@Composable
private fun CommentRow(
    comment: Comment,
    isReply: Boolean,
    parentAuthorUid: String?,
    viewModel: PostDetailViewModel,
    users: Map<String, com.leafmash.app.core.data.UserSummary>,
    myUid: String,
    isAdmin: Boolean,
    postAuthorUid: String,
    onEdit: (Comment) -> Unit,
    onDelete: (Comment) -> Unit,
    onShowReactions: (Comment) -> Unit,
    onOpenHashtag: (String) -> Unit
) {
    val own = comment.authorUid == myUid
    CommentItem(
        comment = comment,
        author = users[comment.authorUid] ?: comment.authorFallback(),
        isReply = isReply,
        myUid = myUid,
        canDelete = own || postAuthorUid == myUid || isAdmin,
        parentAuthorUid = parentAuthorUid,
        callbacks = CommentCallbacks(
            onReact = { viewModel.reactToComment(comment, it) },
            onReply = {
                viewModel.startReply(
                    ReplyTarget(
                        id = comment.replyTo?.id ?: comment.id,
                        authorUid = comment.authorUid,
                        authorName = comment.authorName
                    )
                )
            },
            onEdit = { onEdit(comment) },
            onDelete = { onDelete(comment) },
            onViewReactions = { onShowReactions(comment) },
            onHashtag = onOpenHashtag
        )
    )
}

@Composable
private fun CommentBar(
    viewModel: PostDetailViewModel,
    students: List<com.leafmash.app.core.data.UserSummary>,
    sending: Boolean,
    focus: FocusRequester
) {
    val input = viewModel.input
    val target = viewModel.replyTarget
    Surface(
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        shadowElevation = 12.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            Modifier
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            MentionSuggestionList(
                suggestions = input.suggestions(students, viewModel.myUid),
                onPick = input::pick,
                modifier = Modifier.padding(bottom = 6.dp)
            )
            if (target != null) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.comment_replying_to, target.authorName),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = viewModel::cancelReply, modifier = Modifier.size(32.dp)) {
                        Icon(
                            Icons.Filled.Close,
                            contentDescription = stringResource(R.string.comment_cancel_reply),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
            Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = input.value,
                    onValueChange = viewModel::onInputChanged,
                    placeholder = { Text(stringResource(R.string.comment_placeholder)) },
                    maxLines = 4,
                    shape = RoundedCornerShape(26.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier.weight(1f).focusRequester(focus)
                )
                val canSend = input.text.isNotBlank() && !sending
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(
                            if (canSend) LeafPalette.FabBrush
                            else Brush.linearGradient(
                                listOf(
                                    MaterialTheme.colorScheme.surfaceContainerHighest,
                                    MaterialTheme.colorScheme.surfaceContainerHighest
                                )
                            )
                        )
                        .clickable(enabled = canSend, onClick = viewModel::sendComment),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.Send,
                        contentDescription = stringResource(R.string.comment_send),
                        tint = if (canSend) Color.White else MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
            Text(
                text = "${input.text.length}/${PostDetailViewModel.COMMENT_LIMIT}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.End,
                modifier = Modifier.fillMaxWidth().padding(end = 56.dp)
            )
        }
    }
}

@Composable
private fun ThreadCard(content: @Composable ColumnScope.() -> Unit) {
    LeafCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 5.dp)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
            content = content
        )
    }
}
