package com.leafmash.app.feature.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leafmash.app.core.config.AppConfig
import com.leafmash.app.core.data.UserProfile
import com.leafmash.app.core.profile.ProfileRepository
import com.leafmash.app.feature.admin.ReportsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class ProfileViewModel @Inject constructor(
    profiles: ProfileRepository,
    reports: ReportsRepository
) : ViewModel() {

    val profile: StateFlow<UserProfile?> = profiles.current
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), profiles.current.value)

    val isAdmin: StateFlow<Boolean> = profiles.current
        .map { AppConfig.isAdminEmail(it?.email) }
        .distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppConfig.isAdminEmail(profiles.current.value?.email))

    val openReports: StateFlow<Int> = isAdmin
        .flatMapLatest { admin -> if (admin) reports.observeOpen().map { it.size } else flowOf(0) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)
}
