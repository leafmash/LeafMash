package com.leafmash.app.feature.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leafmash.app.core.data.UserProfile
import com.leafmash.app.core.profile.ProfileRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

@HiltViewModel
class ProfileViewModel @Inject constructor(
    profiles: ProfileRepository
) : ViewModel() {

    val profile: StateFlow<UserProfile?> = profiles.current
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), profiles.current.value)
}
