package com.leafmash.app.feature.profile

import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.leafmash.app.core.data.Post
import com.leafmash.app.core.data.UserProfile
import com.leafmash.app.core.data.UserRepository
import com.leafmash.app.core.profile.ProfileRepository
import com.leafmash.app.feature.resources.data.Resource
import com.leafmash.app.feature.resources.data.ResourceRepository
import com.leafmash.app.feature.wall.PostActionsViewModel
import com.leafmash.app.feature.wall.data.BookmarkRepository
import com.leafmash.app.feature.wall.data.PostActions
import com.leafmash.app.feature.wall.data.PostRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class ProfileViewModel @Inject constructor(
    profiles: ProfileRepository,
    bookmarks: BookmarkRepository,
    private val postRepository: PostRepository,
    private val resourceRepository: ResourceRepository,
    actions: PostActions,
    userRepository: UserRepository,
    auth: FirebaseAuth
) : PostActionsViewModel(actions, userRepository, auth) {

    val profile: StateFlow<UserProfile?> = profiles.current
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), profiles.current.value)

    private val postsRequested = MutableStateFlow(false)

    val posts: StateFlow<List<Post>?> = postsRequested
        .flatMapLatest { requested ->
            if (requested) {
                postRepository.observeByAuthor(myUid).map<List<Post>, List<Post>?> { it }
            } else {
                emptyFlow<List<Post>?>()
            }
        }
        .onEach { list -> ensureUsers(list.orEmpty().map { it.authorUid }) }
        .catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val savedIds: StateFlow<Set<String>> = bookmarks.observe()
        .map { list -> list.filter { it.type == "post" }.map { it.postId }.toSet() }
        .catch { emit(emptySet()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptySet())

    private val notesState = MutableStateFlow<List<Resource>?>(null)
    val notes: StateFlow<List<Resource>?> = notesState

    fun loadPosts() {
        postsRequested.value = true
    }

    fun loadNotes() {
        if (notesState.value != null) return
        viewModelScope.launch {
            notesState.value = runCatching { resourceRepository.byContributor(myUid) }
                .getOrDefault(emptyList())
        }
    }
}
