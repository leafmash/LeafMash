package com.leafmash.app.feature.messages.voice

import android.content.Context
import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class PlaybackState(
    val currentId: String? = null,
    val playing: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val speed: Float = 1f,
    val failed: Boolean = false
)

@Singleton
class VoicePlayer @Inject constructor(
    @ApplicationContext private val context: Context
) {

    private val mainScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val uiState = MutableStateFlow(PlaybackState())
    val state: StateFlow<PlaybackState> = uiState.asStateFlow()

    private var player: ExoPlayer? = null
    private var progressJob: Job? = null

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            uiState.value = uiState.value.copy(playing = isPlaying)
            if (isPlaying) startProgress() else stopProgress()
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            val active = player ?: return
            if (playbackState == Player.STATE_READY) {
                val duration = active.duration
                if (duration != C.TIME_UNSET) uiState.value = uiState.value.copy(durationMs = duration)
            }
            if (playbackState == Player.STATE_ENDED) {
                active.pause()
                active.seekTo(0L)
                uiState.value = uiState.value.copy(playing = false, positionMs = 0L)
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            uiState.value = uiState.value.copy(playing = false, failed = true)
        }
    }

    fun toggle(id: String, uri: Uri, knownDurationMs: Long) {
        val active = obtain()
        val current = uiState.value
        if (current.currentId == id && !current.failed) {
            if (active.isPlaying) active.pause() else active.play()
            return
        }
        active.setMediaItem(MediaItem.fromUri(uri))
        active.setPlaybackSpeed(current.speed)
        active.prepare()
        uiState.value = current.copy(
            currentId = id,
            playing = false,
            positionMs = 0L,
            durationMs = knownDurationMs,
            failed = false
        )
        active.play()
    }

    fun seekTo(id: String, positionMs: Long) {
        if (uiState.value.currentId != id) return
        player?.seekTo(positionMs)
        uiState.value = uiState.value.copy(positionMs = positionMs)
    }

    fun cycleSpeed() {
        val next = when (uiState.value.speed) {
            1f -> 1.5f
            1.5f -> 2f
            else -> 1f
        }
        player?.setPlaybackSpeed(next)
        uiState.value = uiState.value.copy(speed = next)
    }

    fun stop() {
        stopProgress()
        player?.let {
            it.stop()
            it.clearMediaItems()
        }
        uiState.value = PlaybackState(speed = uiState.value.speed)
    }

    private fun obtain(): ExoPlayer {
        player?.let { return it }
        val created = ExoPlayer.Builder(context).build()
        created.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_SPEECH)
                .build(),
            true
        )
        created.addListener(listener)
        player = created
        return created
    }

    private fun startProgress() {
        stopProgress()
        progressJob = mainScope.launch {
            while (true) {
                val active = player ?: return@launch
                uiState.value = uiState.value.copy(positionMs = active.currentPosition)
                delay(PROGRESS_TICK_MS)
            }
        }
    }

    private fun stopProgress() {
        progressJob?.cancel()
        progressJob = null
    }

    private companion object {
        const val PROGRESS_TICK_MS = 200L
    }
}
