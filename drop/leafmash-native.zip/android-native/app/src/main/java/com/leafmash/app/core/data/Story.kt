package com.leafmash.app.core.data

import com.google.firebase.firestore.DocumentSnapshot

data class Story(
    val id: String,
    val authorUid: String,
    val imageUrl: String,
    val caption: String,
    val createdAtMs: Long,
    val expiresAtMs: Long,
    val viewedBy: Set<String>,
    val likedBy: Set<String> = emptySet()
)

data class StoryGroup(
    val authorUid: String,
    val stories: List<Story>
) {
    val latestMs: Long get() = stories.maxOfOrNull { it.createdAtMs } ?: 0L

    fun hasUnseen(uid: String): Boolean = stories.any { uid !in it.viewedBy }

    fun firstUnseenIndex(uid: String): Int =
        stories.indexOfFirst { uid !in it.viewedBy }.let { if (it < 0) 0 else it }
}

fun DocumentSnapshot.toStory(): Story? {
    if (!exists()) return null
    val authorUid = getString("authorUid").orEmpty()
    val imageUrl = getString("imageUrl").orEmpty()
    if (authorUid.isEmpty() || imageUrl.isEmpty()) return null
    return Story(
        id = id,
        authorUid = authorUid,
        imageUrl = imageUrl,
        caption = getString("caption").orEmpty(),
        createdAtMs = getTimestamp("createdAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0L,
        expiresAtMs = getTimestamp("expiresAt")?.toDate()?.time ?: 0L,
        viewedBy = (get("viewedBy") as? List<*>).orEmpty().filterIsInstance<String>().toSet(),
        likedBy = (get("likedBy") as? List<*>).orEmpty().filterIsInstance<String>().toSet()
    )
}
