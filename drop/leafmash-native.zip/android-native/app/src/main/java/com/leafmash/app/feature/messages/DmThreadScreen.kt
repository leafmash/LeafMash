package com.leafmash.app.feature.messages

import android.net.Uri
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leafmash.app.R
import com.leafmash.app.core.data.badge
import com.leafmash.app.core.data.displayName
import com.leafmash.app.ui.components.CollectSnackbars
import com.leafmash.app.ui.components.ProfileBadgeIcon
import com.leafmash.app.ui.components.UserAvatar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DmThreadScreen(
    onBack: () -> Unit,
    viewModel: DmThreadViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val typing by viewModel.typingNow.collectAsStateWithLifecycle()
    val playback by viewModel.playback.collectAsStateWithLifecycle()
    val recorderState by viewModel.recorder.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var menuOpen by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val other = state.other
    val subtitle = when {
        typing -> context.getString(R.string.chat_typing)
        else -> presenceLabel(context, state.lastActiveMs)
    }

    CollectSnackbars(viewModel.events, snackbar)

    LifecycleResumeEffect(Unit) {
        viewModel.setScreenActive(true)
        onPauseOrDispose { viewModel.setScreenActive(false) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        UserAvatar(
                            name = other.displayName,
                            seed = other.uid,
                            photoUrl = other.photoUrl,
                            size = 36.dp
                        )
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = other.displayName,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.titleMedium,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                                ProfileBadgeIcon(
                                    badge = other.badge,
                                    modifier = Modifier.padding(start = 4.dp),
                                    size = 16.dp
                                )
                            }
                            if (subtitle != null) {
                                Text(
                                    text = subtitle,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (typing || isOnline(state.lastActiveMs)) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                )
                            }
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                },
                actions = {
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Filled.MoreVert, contentDescription = stringResource(R.string.post_more))
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        stringResource(
                                            if (state.iBlocked) R.string.chat_unblock else R.string.chat_block
                                        )
                                    )
                                },
                                onClick = {
                                    menuOpen = false
                                    viewModel.setBlocked(!state.iBlocked)
                                }
                            )
                        }
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            when {
                state.iBlocked -> BlockedBar(
                    text = stringResource(R.string.chat_you_blocked),
                    actionLabel = stringResource(R.string.chat_unblock),
                    onAction = { viewModel.setBlocked(false) }
                )
                state.blockedMe -> BlockedBar(
                    text = stringResource(R.string.chat_blocked_you),
                    actionLabel = null,
                    onAction = {}
                )
                else -> ChatComposer(
                    text = viewModel.text,
                    onTextChange = viewModel::onTextChange,
                    onSend = viewModel::submit,
                    recorder = viewModel.recorder,
                    recorderState = recorderState,
                    onMicDenied = viewModel::permissionDenied,
                    editing = false,
                    onCancelEdit = {},
                    allowVoice = true
                )
            }
        }
    ) { inner ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(inner)
        ) {
            when {
                state.loading -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                state.messages.isEmpty() -> Text(
                    text = stringResource(R.string.chat_thread_empty, other.displayName),
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .fillMaxWidth()
                        .padding(32.dp)
                )
                else -> ChatMessageList(
                    messages = state.messages,
                    myUid = viewModel.myUid,
                    showSender = false,
                    users = emptyMap(),
                    receiptFor = { message ->
                        if (message.createdAtMs <= state.otherReadAtMs) Receipt.READ else Receipt.SENT
                    },
                    playback = playback,
                    canEdit = { false },
                    canDelete = { message -> message.senderUid == viewModel.myUid && !message.pending },
                    onTogglePlay = { message ->
                        viewModel.togglePlay(message.id, Uri.parse(message.audioUrl), message.audioDurationSec)
                    },
                    onSeek = { message, position -> viewModel.seekVoice(message.id, position) },
                    onCycleSpeed = viewModel::cycleSpeed,
                    onRetry = { message -> viewModel.retry(message.id) },
                    onEdit = {},
                    onDelete = viewModel::delete,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

@Composable
private fun BlockedBar(text: String, actionLabel: String?, onAction: () -> Unit) {
    Surface(
        tonalElevation = 3.dp,
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f)
            )
            if (actionLabel != null) {
                TextButton(onClick = onAction) { Text(actionLabel) }
            }
        }
    }
}
