package com.leafmash.app.ui.navigation

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.LibraryBooks
import androidx.compose.material.icons.automirrored.outlined.LibraryBooks
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.ui.graphics.vector.ImageVector
import com.leafmash.app.R

object Routes {
    const val SETTINGS = "settings"
    const val EDIT_PROFILE = "edit-profile"
    const val POST_DETAIL = "post/{postId}?focus={focus}"
    const val COMPOSE = "compose?postId={postId}"
    const val SAVED = "saved"
    const val HASHTAG = "hashtag/{tag}"
    const val CLASS_CHAT = "class-chat"
    const val NEW_CHAT = "new-chat"
    const val DM_THREAD = "dm/{uid}"
    const val NOTIFICATIONS = "notifications?tab={tab}"
    const val ROUTINE = "routine"
    const val DEADLINES = "deadlines"

    fun postDetail(postId: String, focus: Boolean): String = "post/$postId?focus=$focus"

    fun compose(postId: String? = null): String =
        if (postId == null) "compose" else "compose?postId=$postId"

    fun notifications(tab: Int = 0): String = "notifications?tab=$tab"

    fun dmThread(uid: String): String = "dm/${android.net.Uri.encode(uid)}"

    fun hashtag(tag: String): String = "hashtag/${android.net.Uri.encode(tag)}"
}

enum class TopLevelDestination(
    val route: String,
    @StringRes val label: Int,
    val icon: ImageVector,
    val selectedIcon: ImageVector
) {
    WALL("wall", R.string.nav_wall, Icons.Outlined.Home, Icons.Filled.Home),
    RESOURCES(
        "resources",
        R.string.nav_resources,
        Icons.AutoMirrored.Outlined.LibraryBooks,
        Icons.AutoMirrored.Filled.LibraryBooks
    ),
    MESSAGES("messages", R.string.nav_messages, Icons.Outlined.ChatBubbleOutline, Icons.Filled.ChatBubble),
    DIRECTORY("directory", R.string.nav_directory, Icons.Outlined.Groups, Icons.Filled.Groups),
    PROFILE("profile", R.string.nav_profile, Icons.Outlined.Person, Icons.Filled.Person)
}
