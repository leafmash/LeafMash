package com.leafmash.app.ui.navigation

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.LibraryBooks
import androidx.compose.material.icons.automirrored.outlined.LibraryBooks
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.ui.graphics.vector.ImageVector
import com.leafmash.app.R

object Routes {
    const val SETTINGS = "settings"
    const val EDIT_PROFILE = "edit-profile"
}

enum class TopLevelDestination(
    val route: String,
    @StringRes val label: Int,
    val icon: ImageVector,
    val selectedIcon: ImageVector
) {
    WALL("wall", R.string.nav_wall, Icons.Outlined.Home, Icons.Filled.Home),
    RESOURCES(
        "resources",
        R.string.nav_resources,
        Icons.AutoMirrored.Outlined.LibraryBooks,
        Icons.AutoMirrored.Filled.LibraryBooks
    ),
    MESSAGES("messages", R.string.nav_messages, Icons.Outlined.ChatBubbleOutline, Icons.Filled.ChatBubble),
    DIRECTORY("directory", R.string.nav_directory, Icons.Outlined.Groups, Icons.Filled.Groups),
    PROFILE("profile", R.string.nav_profile, Icons.Outlined.Person, Icons.Filled.Person)
}
