package com.leafmash.app.core.push

import com.leafmash.app.core.network.ApiClient
import com.leafmash.app.feature.messages.data.MessagesRepository
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@EntryPoint
@InstallIn(SingletonComponent::class)
interface PushEntryPoint {
    fun api(): ApiClient
    fun messages(): MessagesRepository
    fun dispatcher(): NotificationDispatcher
    fun store(): ChatNotificationStore
}
