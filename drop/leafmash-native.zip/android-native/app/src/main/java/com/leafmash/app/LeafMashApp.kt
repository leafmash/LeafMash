package com.leafmash.app

import android.app.Application
import com.leafmash.app.core.push.NotificationDispatcher
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class LeafMashApp : Application() {

    @Inject
    lateinit var notificationDispatcher: NotificationDispatcher

    override fun onCreate() {
        super.onCreate()
        notificationDispatcher.ensureChannels()
    }
}
