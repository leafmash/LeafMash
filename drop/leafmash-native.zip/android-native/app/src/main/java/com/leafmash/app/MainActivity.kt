package com.leafmash.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.leafmash.app.core.push.DeepLinkHandler
import com.leafmash.app.core.push.DeepLinkParser
import com.leafmash.app.core.push.PushExtras
import com.leafmash.app.ui.LeafMashRoot
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import kotlinx.coroutines.launch

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val appViewModel: AppViewModel by viewModels()

    @Inject
    lateinit var deepLinks: DeepLinkHandler

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        splash.setKeepOnScreenCondition { !appViewModel.isReady.value }
        enableEdgeToEdge()
        handleIntent(intent)
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                appViewModel.runPresence()
            }
        }
        setContent {
            LeafMashRoot(appViewModel)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        val url = intent?.getStringExtra(PushExtras.URL) ?: return
        val type = intent.getStringExtra(PushExtras.TYPE)
        intent.removeExtra(PushExtras.URL)
        intent.removeExtra(PushExtras.TYPE)
        deepLinks.post(DeepLinkParser.parse(url, type))
    }
}
