package com.leafmash.app.feature.directory

import com.leafmash.app.ui.components.FlatItem
import com.leafmash.app.ui.components.LeafTopAppBar
import com.leafmash.app.ui.navigation.MenuAction
import com.leafmash.app.ui.components.LeafCard
import com.leafmash.app.ui.components.EmptyCard
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.foundation.shape.RoundedCornerShape
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bloodtype
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.PhoneDisabled
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leafmash.app.R
import com.leafmash.app.feature.directory.data.Classmate
import com.leafmash.app.feature.directory.data.badge
import com.leafmash.app.feature.directory.data.displayName
import com.leafmash.app.feature.messages.isOnline
import com.leafmash.app.ui.components.ProfileBadgeIcon
import com.leafmash.app.ui.components.RingAvatar
import com.leafmash.app.ui.theme.LeafPalette
import androidx.compose.ui.graphics.vector.ImageVector
import kotlinx.coroutines.delay

private const val ONLINE_REFRESH_MS = 12_000L

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DirectoryScreen(
    onOpenProfile: (String) -> Unit,
    onMessage: (String) -> Unit,
    viewModel: DirectoryViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val query by viewModel.query.collectAsStateWithLifecycle()
    val year by viewModel.year.collectAsStateWithLifecycle()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(ONLINE_REFRESH_MS)
            now = System.currentTimeMillis()
        }
    }

    val years = state.all.map { it.year }.filter { it.isNotBlank() }.distinct()
    val activeYear = if (year == YEAR_ALL || year in years) year else YEAR_ALL
    val term = query.trim().lowercase()
    val filtered = state.all.filter { c ->
        (activeYear == YEAR_ALL || c.year == activeYear) &&
            (
                term.isEmpty() ||
                    c.name.lowercase().contains(term) ||
                    c.bloodGroup.lowercase().contains(term) ||
                    c.roll.lowercase().contains(term)
                )
    }
    val online = state.all.filter { it.uid.isNotEmpty() && it.uid != viewModel.myUid && isOnline(it.lastActiveMs, now) }
    val grouped = filtered.groupBy { letterOf(it.name) }.toSortedMap()

    Column(Modifier.fillMaxSize()) {
        LeafTopAppBar(title = { Text(stringResource(R.string.nav_directory)) }, actions = { MenuAction() })
        OutlinedTextField(
            value = query,
            onValueChange = viewModel::updateQuery,
            placeholder = { Text(stringResource(R.string.directory_search)) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                focusedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                unfocusedBorderColor = Color.Transparent
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 8.dp)
        )
        if (years.isNotEmpty()) {
            val chipColors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primary,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
            )
            LazyRow(
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = activeYear == YEAR_ALL,
                        onClick = { viewModel.selectYear(YEAR_ALL) },
                        shape = RoundedCornerShape(50),
                        colors = chipColors,
                        label = { Text(stringResource(R.string.resource_filter_all)) }
                    )
                }
                items(years) { y ->
                    FilterChip(
                        selected = activeYear == y,
                        onClick = { viewModel.selectYear(y) },
                        shape = RoundedCornerShape(50),
                        colors = chipColors,
                        label = { Text(y) }
                    )
                }
            }
        }
        Box(Modifier.fillMaxSize()) {
            when {
                state.loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                filtered.isEmpty() -> EmptyCard(
                    title = stringResource(R.string.directory_empty),
                    icon = Icons.Filled.Search,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp)
                )
                else -> LazyColumn(
                    contentPadding = PaddingValues(bottom = 24.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    if (online.isNotEmpty() && term.isEmpty() && activeYear == YEAR_ALL) {
                        item(key = "online") {
                            OnlineNow(online, onOpenProfile)
                        }
                    }
                    grouped.forEach { (letter, members) ->
                        stickyHeader(key = "h_$letter") {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.background)
                                    .padding(horizontal = 16.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = letter,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(50))
                                        .background(MaterialTheme.colorScheme.primaryContainer)
                                        .padding(horizontal = 12.dp, vertical = 3.dp)
                                )
                            }
                        }
                        items(members, key = { it.uid }) { classmate ->
                            ClassmateCard(
                                classmate = classmate,
                                isSelf = classmate.uid == viewModel.myUid,
                                online = isOnline(classmate.lastActiveMs, now),
                                onOpen = { onOpenProfile(classmate.uid) },
                                onMessage = { onMessage(classmate.uid) }
                            )
                        }
                    }
                    if (state.canLoadMore) {
                        item(key = "more") {
                            OutlinedButton(
                                onClick = viewModel::loadMore,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp)
                            ) {
                                Text(stringResource(R.string.directory_load_more))
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun letterOf(name: String): String {
    val first = name.trim().firstOrNull() ?: return "#"
    return if (first.isLetter()) first.uppercaseChar().toString() else "#"
}

@Composable
private fun OnlineNow(online: List<Classmate>, onOpenProfile: (String) -> Unit) {
    Column(Modifier.padding(top = 4.dp, bottom = 6.dp)) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(LeafPalette.Online)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = stringResource(R.string.directory_online_now, online.size),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            items(online, key = { it.uid }) { c ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .width(74.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onOpenProfile(c.uid) }
                        .padding(vertical = 6.dp)
                ) {
                    RingAvatar(
                        name = c.displayName(),
                        seed = c.uid,
                        photoUrl = c.photoUrl,
                        size = 52.dp,
                        ring = true,
                        onlineDot = true,
                        badge = c.badge()
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = c.displayName().substringBefore(' '),
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun RoundAction(
    icon: ImageVector,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    container: Color = MaterialTheme.colorScheme.primaryContainer,
    tint: Color = MaterialTheme.colorScheme.primary
) {
    Box(
        modifier = modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(container)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = description,
            tint = if (enabled) tint else MaterialTheme.colorScheme.outline,
            modifier = Modifier.size(19.dp)
        )
    }
}

@Composable
private fun ClassmateCard(
    classmate: Classmate,
    isSelf: Boolean,
    online: Boolean,
    onOpen: () -> Unit,
    onMessage: () -> Unit
) {
    val context = LocalContext.current
    val scheme = MaterialTheme.colorScheme
    val hasPhone = classmate.phone.isNotBlank() && !classmate.hidePhone
    Column(Modifier.fillMaxWidth().background(scheme.surfaceContainerLowest)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onOpen)
                .padding(start = 12.dp, end = 14.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RingAvatar(
                name = classmate.displayName(),
                seed = classmate.uid,
                photoUrl = classmate.photoUrl,
                size = 46.dp,
                ring = online,
                onlineDot = online,
                badge = classmate.badge()
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = classmate.displayName(),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    ProfileBadgeIcon(classmate.badge(), Modifier.padding(start = 4.dp), 16.dp)
                }
                val sub = listOf(classmate.roll.ifBlank { "—" }, classmate.year.ifBlank { classmate.session })
                    .filter { it.isNotBlank() }
                    .joinToString(" · ")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = sub,
                        style = MaterialTheme.typography.bodySmall,
                        color = scheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (classmate.bloodGroup.isNotBlank()) {
                        Spacer(Modifier.width(8.dp))
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(scheme.errorContainer)
                                .padding(horizontal = 7.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Bloodtype,
                                contentDescription = null,
                                tint = scheme.error,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(Modifier.width(2.dp))
                            Text(
                                text = classmate.bloodGroup,
                                style = MaterialTheme.typography.labelSmall,
                                color = scheme.onErrorContainer
                            )
                        }
                    }
                }
            }
            if (!isSelf) {
                Spacer(Modifier.width(8.dp))
                RoundAction(
                    icon = Icons.AutoMirrored.Filled.Message,
                    description = stringResource(R.string.directory_message),
                    onClick = onMessage
                )
                Spacer(Modifier.width(8.dp))
                if (classmate.hidePhone) {
                    RoundAction(
                        icon = Icons.Filled.PhoneDisabled,
                        description = stringResource(R.string.directory_hidden),
                        onClick = {},
                        enabled = false,
                        container = scheme.surfaceContainer
                    )
                } else if (hasPhone) {
                    RoundAction(
                        icon = Icons.Filled.Call,
                        description = stringResource(R.string.directory_call),
                        onClick = {
                            runCatching {
                                context.startActivity(
                                    Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + classmate.phone))
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            }
                        },
                        container = scheme.secondaryContainer,
                        tint = scheme.secondary
                    )
                }
            }
        }
        HorizontalDivider(
            modifier = Modifier.padding(start = 72.dp),
            color = scheme.outlineVariant.copy(alpha = 0.7f)
        )
    }
}
