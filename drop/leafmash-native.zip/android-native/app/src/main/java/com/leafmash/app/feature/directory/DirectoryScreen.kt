package com.leafmash.app.feature.directory

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.PhoneDisabled
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leafmash.app.R
import com.leafmash.app.feature.directory.data.Classmate
import com.leafmash.app.feature.directory.data.badge
import com.leafmash.app.feature.directory.data.displayName
import com.leafmash.app.feature.messages.isOnline
import com.leafmash.app.ui.components.ProfileBadgeIcon
import com.leafmash.app.ui.components.UserAvatar
import kotlinx.coroutines.delay

private const val ONLINE_REFRESH_MS = 12_000L

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DirectoryScreen(
    onOpenProfile: (String) -> Unit,
    onMessage: (String) -> Unit,
    viewModel: DirectoryViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val query by viewModel.query.collectAsStateWithLifecycle()
    val year by viewModel.year.collectAsStateWithLifecycle()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(ONLINE_REFRESH_MS)
            now = System.currentTimeMillis()
        }
    }

    val years = state.all.map { it.year }.filter { it.isNotBlank() }.distinct()
    val activeYear = if (year == YEAR_ALL || year in years) year else YEAR_ALL
    val term = query.trim().lowercase()
    val filtered = state.all.filter { c ->
        (activeYear == YEAR_ALL || c.year == activeYear) &&
            (
                term.isEmpty() ||
                    c.name.lowercase().contains(term) ||
                    c.bloodGroup.lowercase().contains(term) ||
                    c.roll.lowercase().contains(term)
                )
    }
    val online = state.all.filter { it.uid.isNotEmpty() && it.uid != viewModel.myUid && isOnline(it.lastActiveMs, now) }
    val grouped = filtered.groupBy { letterOf(it.name) }.toSortedMap()

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = viewModel::updateQuery,
            placeholder = { Text(stringResource(R.string.directory_search)) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        )
        if (years.isNotEmpty()) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = activeYear == YEAR_ALL,
                        onClick = { viewModel.selectYear(YEAR_ALL) },
                        label = { Text(stringResource(R.string.resource_filter_all)) }
                    )
                }
                items(years) { y ->
                    FilterChip(
                        selected = activeYear == y,
                        onClick = { viewModel.selectYear(y) },
                        label = { Text(y) }
                    )
                }
            }
        }
        Box(Modifier.fillMaxSize()) {
            when {
                state.loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                filtered.isEmpty() -> Text(
                    text = stringResource(R.string.directory_empty),
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(32.dp)
                )
                else -> LazyColumn(
                    contentPadding = PaddingValues(bottom = 24.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    if (online.isNotEmpty() && term.isEmpty() && activeYear == YEAR_ALL) {
                        item(key = "online") {
                            OnlineNow(online, onOpenProfile)
                        }
                    }
                    grouped.forEach { (letter, members) ->
                        stickyHeader(key = "h_$letter") {
                            Text(
                                text = letter,
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surface)
                                    .padding(horizontal = 16.dp, vertical = 6.dp)
                            )
                        }
                        items(members, key = { it.uid }) { classmate ->
                            ClassmateCard(
                                classmate = classmate,
                                isSelf = classmate.uid == viewModel.myUid,
                                online = isOnline(classmate.lastActiveMs, now),
                                onOpen = { onOpenProfile(classmate.uid) },
                                onMessage = { onMessage(classmate.uid) }
                            )
                        }
                    }
                    if (state.canLoadMore) {
                        item(key = "more") {
                            OutlinedButton(
                                onClick = viewModel::loadMore,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp)
                            ) {
                                Text(stringResource(R.string.directory_load_more))
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun letterOf(name: String): String {
    val first = name.trim().firstOrNull() ?: return "#"
    return if (first.isLetter()) first.uppercaseChar().toString() else "#"
}

@Composable
private fun OnlineNow(online: List<Classmate>, onOpenProfile: (String) -> Unit) {
    Column(Modifier.padding(top = 8.dp)) {
        Text(
            text = stringResource(R.string.directory_online_now, online.size),
            style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(online, key = { it.uid }) { c ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .width(64.dp)
                        .clickable { onOpenProfile(c.uid) }
                        .padding(vertical = 4.dp)
                ) {
                    Box {
                        UserAvatar(name = c.displayName(), seed = c.uid, photoUrl = c.photoUrl, size = 48.dp)
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF2E9E5B))
                        )
                    }
                    Text(
                        text = c.displayName().substringBefore(' '),
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun ClassmateCard(
    classmate: Classmate,
    isSelf: Boolean,
    online: Boolean,
    onOpen: () -> Unit,
    onMessage: () -> Unit
) {
    val context = LocalContext.current
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clickable(onClick = onOpen)
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box {
                    UserAvatar(name = classmate.displayName(), seed = classmate.uid, photoUrl = classmate.photoUrl, size = 48.dp)
                    if (online) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF2E9E5B))
                        )
                    }
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = classmate.displayName(),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        ProfileBadgeIcon(classmate.badge(), Modifier.padding(start = 4.dp), 16.dp)
                    }
                    val sub = listOf(classmate.roll.ifBlank { "—" }, classmate.year.ifBlank { classmate.session })
                        .filter { it.isNotBlank() }
                        .joinToString(" · ")
                    Text(
                        text = sub,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    text = classmate.bloodGroup.ifBlank { "—" },
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.error
                )
            }
            val hasPhone = classmate.phone.isNotBlank() && !classmate.hidePhone
            if (!isSelf || hasPhone || classmate.hidePhone) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    if (!isSelf) {
                        TextButton(onClick = onMessage) {
                            Icon(Icons.AutoMirrored.Filled.Message, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.directory_message))
                        }
                    }
                    if (classmate.hidePhone) {
                        TextButton(onClick = {}, enabled = false) {
                            Icon(Icons.Filled.PhoneDisabled, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.directory_hidden))
                        }
                    } else if (hasPhone) {
                        TextButton(
                            onClick = {
                                runCatching {
                                    context.startActivity(
                                        Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + classmate.phone))
                                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    )
                                }
                            }
                        ) {
                            Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.directory_call))
                        }
                    }
                }
            }
        }
    }
}
