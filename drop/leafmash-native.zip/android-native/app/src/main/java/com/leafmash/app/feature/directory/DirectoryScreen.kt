package com.leafmash.app.feature.directory

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Groups
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.leafmash.app.R
import com.leafmash.app.ui.components.PlaceholderScreen

@Composable
fun DirectoryScreen() {
    PlaceholderScreen(
        title = stringResource(R.string.nav_directory),
        icon = Icons.Filled.Groups,
        phase = 6
    )
}
