package com.leafmash.app.feature.wall.data

import android.net.Uri
import com.google.firebase.auth.FirebaseAuth
import com.leafmash.app.R
import com.leafmash.app.core.data.MentionRef
import com.leafmash.app.core.notify.ActivityLogger
import com.leafmash.app.core.notify.PushTrigger
import com.leafmash.app.core.util.AppScope
import com.leafmash.app.core.util.UiText
import com.leafmash.app.core.util.toUiText
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class PendingStatus { SENDING, FAILED }

data class PendingPost(
    val clientId: String,
    val text: String,
    val mentions: List<MentionRef>,
    val pollOptions: List<String>,
    val imageUris: List<Uri>,
    val status: PendingStatus,
    val error: UiText?
)

@Singleton
class PostPublisher @Inject constructor(
    private val posts: PostRepository,
    private val imageUploader: PostImageUploader,
    private val activity: ActivityLogger,
    private val push: PushTrigger,
    private val auth: FirebaseAuth,
    private val appScope: AppScope
) {

    private val pendingState = MutableStateFlow<List<PendingPost>>(emptyList())
    val pending: StateFlow<List<PendingPost>> = pendingState.asStateFlow()

    private val eventChannel = Channel<UiText>(Channel.BUFFERED)
    val events: Flow<UiText> = eventChannel.receiveAsFlow()

    fun submit(text: String, mentions: List<MentionRef>, pollOptions: List<String>, imageUris: List<Uri>) {
        val item = PendingPost(
            clientId = UUID.randomUUID().toString(),
            text = text,
            mentions = mentions,
            pollOptions = pollOptions,
            imageUris = imageUris,
            status = PendingStatus.SENDING,
            error = null
        )
        pendingState.update { it + item }
        run(item.clientId, skipCooldown = false)
    }

    fun retry(clientId: String) {
        val exists = pendingState.value.any { it.clientId == clientId && it.status == PendingStatus.FAILED }
        if (!exists) return
        update(clientId) { it.copy(status = PendingStatus.SENDING, error = null) }
        run(clientId, skipCooldown = true)
    }

    fun discard(clientId: String) {
        pendingState.update { list -> list.filterNot { it.clientId == clientId } }
    }

    private fun update(clientId: String, transform: (PendingPost) -> PendingPost) {
        pendingState.update { list -> list.map { if (it.clientId == clientId) transform(it) else it } }
    }

    private fun run(clientId: String, skipCooldown: Boolean) {
        val item = pendingState.value.firstOrNull { it.clientId == clientId } ?: return
        appScope.scope.launch {
            val uploaded = imageUploader.upload(item.imageUris).getOrElse { error ->
                update(clientId) { it.copy(status = PendingStatus.FAILED, error = error.toUiText()) }
                return@launch
            }
            val postId = posts.createPost(item.text, uploaded, item.mentions, item.pollOptions, skipCooldown)
                .getOrElse { error ->
                    update(clientId) { it.copy(status = PendingStatus.FAILED, error = error.toUiText()) }
                    return@launch
                }
            discard(clientId)
            eventChannel.trySend(UiText.Res(R.string.wall_posted))
            activity.log("post", item.text, postId = postId)
            push.send("post", item.text, postId = postId)
            val me = auth.currentUser?.uid
            item.mentions.filter { it.uid.isNotEmpty() && it.uid != me }.forEach { mention ->
                activity.log("mention", item.text, mention.uid, postId)
                push.send("mention", item.text, mention.uid, postId)
            }
        }
    }
}
