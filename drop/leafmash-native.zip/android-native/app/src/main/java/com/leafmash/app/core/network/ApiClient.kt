package com.leafmash.app.core.network

import com.google.firebase.auth.FirebaseAuth
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.cancellation.CancellationException
import kotlin.math.ceil
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import retrofit2.HttpException

@Singleton
class ApiClient @Inject constructor(
    private val api: LeafMashApi,
    private val auth: FirebaseAuth,
    private val json: Json
) {
    private val lastCallAt = ConcurrentHashMap<String, Long>()

    suspend fun call(
        action: String,
        payload: JsonObject = JsonObject(emptyMap()),
        skipClientCooldown: Boolean = false
    ): Result<JsonObject> {
        val cooldownMs = CLIENT_COOLDOWN_MS[action]
        if (cooldownMs != null && !skipClientCooldown) {
            val now = System.currentTimeMillis()
            val waitMs = cooldownMs - (now - (lastCallAt[action] ?: 0L))
            if (waitMs > 0) {
                val seconds = ceil(waitMs / 1000.0).toInt()
                return Result.failure(
                    ApiException("You're doing that too fast — please wait ${seconds}s and try again.")
                )
            }
            lastCallAt[action] = now
        }
        if (auth.currentUser == null) {
            return Result.failure(ApiException("You're not signed in."))
        }
        return try {
            Result.success(api.call(action, payload))
        } catch (e: CancellationException) {
            throw e
        } catch (e: HttpException) {
            Result.failure(ApiException(errorMessage(e) ?: "Request failed (${e.code()}).", e.code()))
        } catch (e: SerializationException) {
            Result.failure(ApiException("Unexpected response from the server."))
        } catch (e: IOException) {
            Result.failure(ApiException("Network error. Check your connection and try again."))
        }
    }

    private fun errorMessage(e: HttpException): String? = runCatching {
        val body = e.response()?.errorBody()?.string().orEmpty()
        json.parseToJsonElement(body).jsonObject["error"]?.jsonPrimitive?.contentOrNull
    }.getOrNull()

    private companion object {
        val CLIENT_COOLDOWN_MS = mapOf(
            "create-post" to 3000L,
            "create-comment" to 1500L
        )
    }
}
