package com.leafmash.app.feature.wall.data

import android.net.Uri
import com.leafmash.app.core.config.AppConfig
import com.leafmash.app.core.network.ApiException
import com.leafmash.app.core.upload.ImageProcessor
import com.leafmash.app.core.upload.ImageUploader
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PostImageUploader @Inject constructor(
    private val processor: ImageProcessor,
    private val uploader: ImageUploader
) {

    suspend fun upload(uris: List<Uri>): Result<List<String>> {
        if (uris.isEmpty()) return Result.success(emptyList())
        val encoded = ArrayList<ByteArray>(uris.size)
        for (uri in uris) {
            val bitmap = processor.decode(uri, MAX_DIMENSION)
                ?: return Result.failure(ApiException("Couldn't read one of the photos."))
            encoded.add(processor.encodeJpeg(bitmap, JPEG_QUALITY))
            bitmap.recycle()
        }
        return uploader.uploadJpegs(encoded, AppConfig.POST_FOLDER, "post")
    }

    private companion object {
        const val MAX_DIMENSION = 1600
        const val JPEG_QUALITY = 78
    }
}
