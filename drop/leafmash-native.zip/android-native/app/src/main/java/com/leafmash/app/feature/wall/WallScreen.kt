package com.leafmash.app.feature.wall

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.leafmash.app.R
import com.leafmash.app.ui.components.PlaceholderScreen

@Composable
fun WallScreen() {
    PlaceholderScreen(
        title = stringResource(R.string.nav_wall),
        icon = Icons.Filled.Home,
        phase = 2
    )
}
