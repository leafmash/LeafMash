package com.leafmash.app.feature.wall

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leafmash.app.R
import com.leafmash.app.core.data.Post
import com.leafmash.app.core.data.UserSummary
import com.leafmash.app.core.data.authorFallback
import com.leafmash.app.core.data.badge
import com.leafmash.app.core.data.displayName
import com.leafmash.app.core.util.asString
import com.leafmash.app.feature.wall.data.PendingPost
import com.leafmash.app.feature.wall.data.PendingStatus
import com.leafmash.app.ui.components.CollectSnackbars
import com.leafmash.app.feature.notifications.NotificationBadgeViewModel
import com.leafmash.app.ui.components.ProfileBadgeIcon
import com.leafmash.app.ui.components.RichText
import com.leafmash.app.ui.components.SkeletonPost
import com.leafmash.app.ui.components.UserAvatar

fun postCallbacks(
    viewModel: PostActionsViewModel,
    post: Post,
    saved: Boolean,
    onOpenPost: (String, Boolean) -> Unit,
    onEditPost: (String) -> Unit,
    onOpenHashtag: (String) -> Unit,
    onViewReactions: (Post) -> Unit,
    onDeleted: () -> Unit = {}
): PostCardCallbacks = PostCardCallbacks(
    onOpen = { onOpenPost(post.id, false) },
    onReact = { viewModel.reactToPost(post, it) },
    onVote = { viewModel.vote(post, it) },
    onComment = { onOpenPost(post.id, true) },
    onBookmark = { viewModel.toggleSaved(post.id, saved) },
    onEdit = { onEditPost(post.id) },
    onPin = { viewModel.togglePin(post) },
    onDelete = { viewModel.deletePost(post, onDeleted) },
    onReport = { viewModel.report(post, it) },
    onHashtag = onOpenHashtag,
    onViewReactions = { onViewReactions(post) }
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WallScreen(
    onOpenPost: (String, Boolean) -> Unit,
    onCompose: () -> Unit,
    onEditPost: (String) -> Unit,
    onOpenHashtag: (String) -> Unit,
    onOpenSaved: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenSearch: () -> Unit,
    viewModel: WallViewModel = hiltViewModel(),
    badges: NotificationBadgeViewModel = hiltViewModel()
) {
    val feed by viewModel.feed.collectAsStateWithLifecycle()
    val unreadNotifications by badges.unread.collectAsStateWithLifecycle()
    val pending by viewModel.pending.collectAsStateWithLifecycle()
    val savedIds by viewModel.savedIds.collectAsStateWithLifecycle()
    val counts by viewModel.commentCounts.collectAsStateWithLifecycle()
    val users by viewModel.users.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val listState = rememberLazyListState()
    var reactionsFor by remember { mutableStateOf<Map<String, String>?>(null) }
    val myUid = viewModel.myUid
    val isAdmin = viewModel.isAdmin

    CollectSnackbars(viewModel.allEvents, snackbar)

    val nearEnd by remember {
        derivedStateOf {
            val info = listState.layoutInfo
            val last = info.visibleItemsInfo.lastOrNull()?.index ?: 0
            info.totalItemsCount > 0 && last >= info.totalItemsCount - 3
        }
    }
    LaunchedEffect(nearEnd, feed.posts.size) {
        if (nearEnd) viewModel.loadMore()
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(stringResource(R.string.wall_title)) },
                actions = {
                    IconButton(onClick = onOpenSearch) {
                        Icon(Icons.Filled.Search, contentDescription = stringResource(R.string.search_title))
                    }
                    IconButton(onClick = onOpenNotifications) {
                        BadgedBox(
                            badge = {
                                if (unreadNotifications > 0) {
                                    Badge { Text(if (unreadNotifications > 9) "9+" else unreadNotifications.toString()) }
                                }
                            }
                        ) {
                            Icon(
                                Icons.Outlined.Notifications,
                                contentDescription = stringResource(R.string.notif_title)
                            )
                        }
                    }
                    IconButton(onClick = onOpenSaved) {
                        Icon(Icons.Outlined.BookmarkBorder, contentDescription = stringResource(R.string.saved_title))
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { inner ->
        Box(Modifier.fillMaxSize().padding(inner)) {
            when {
                feed.loading -> Column {
                    repeat(3) { SkeletonPost() }
                }
                feed.error != null && feed.posts.isEmpty() -> WallError(
                    message = feed.error!!.asString(),
                    onRetry = viewModel::retry
                )
                else -> PullToRefreshBox(
                    isRefreshing = feed.refreshing,
                    onRefresh = viewModel::refresh,
                    modifier = Modifier.fillMaxSize()
                ) {
                    LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
                        item(key = "composer") {
                            ComposerPrompt(
                                author = users[myUid],
                                onClick = onCompose
                            )
                        }
                        items(pending, key = { "pending_${it.clientId}" }) { item ->
                            PendingPostCard(
                                item = item,
                                author = users[myUid],
                                onRetry = { viewModel.retryPending(item.clientId) },
                                onDiscard = { viewModel.discardPending(item.clientId) }
                            )
                        }
                        if (feed.posts.isEmpty() && pending.isEmpty()) {
                            item(key = "empty") {
                                Text(
                                    text = stringResource(R.string.wall_empty),
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth().padding(32.dp)
                                )
                            }
                        }
                        items(feed.posts, key = { it.id }) { post ->
                            val saved = post.id in savedIds
                            PostCard(
                                post = post,
                                author = users[post.authorUid] ?: post.authorFallback(),
                                commentCount = post.commentCount ?: counts[post.id],
                                saved = saved,
                                myUid = myUid,
                                isAdmin = isAdmin,
                                callbacks = postCallbacks(
                                    viewModel = viewModel,
                                    post = post,
                                    saved = saved,
                                    onOpenPost = onOpenPost,
                                    onEditPost = onEditPost,
                                    onOpenHashtag = onOpenHashtag,
                                    onViewReactions = { reactionsFor = it.reactions }
                                )
                            )
                        }
                        item(key = "footer") {
                            Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                                when {
                                    feed.loadingMore || (feed.hasMore && feed.posts.isNotEmpty()) ->
                                        CircularProgressIndicator(Modifier.height(28.dp).width(28.dp), strokeWidth = 3.dp)
                                    feed.posts.isNotEmpty() -> Text(
                                        text = stringResource(R.string.wall_end),
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    val shown = reactionsFor
    if (shown != null) {
        LaunchedEffect(shown) { viewModel.ensureUsers(shown.keys) }
        ReactionsSheet(reactions = shown, users = users, onDismiss = { reactionsFor = null })
    }
}

@Composable
private fun WallError(message: String, onRetry: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = stringResource(R.string.wall_error_title),
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = onRetry) { Text(stringResource(R.string.action_retry)) }
    }
}

@Composable
private fun ComposerPrompt(author: UserSummary?, onClick: () -> Unit) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onClick)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            UserAvatar(
                name = author?.displayName.orEmpty(),
                seed = author?.uid.orEmpty(),
                photoUrl = author?.photoUrl.orEmpty(),
                size = 40.dp
            )
            Spacer(Modifier.width(12.dp))
            Surface(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Add, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.wall_composer_prompt),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
    }
}

@Composable
private fun PendingPostCard(
    item: PendingPost,
    author: UserSummary?,
    onRetry: () -> Unit,
    onDiscard: () -> Unit
) {
    Column(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                UserAvatar(
                    name = author?.displayName.orEmpty(),
                    seed = author?.uid.orEmpty(),
                    photoUrl = author?.photoUrl.orEmpty(),
                    size = 40.dp
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = author?.displayName.orEmpty(),
                            style = MaterialTheme.typography.titleSmall
                        )
                        if (author != null) ProfileBadgeIcon(author.badge, Modifier.padding(start = 4.dp), 16.dp)
                    }
                    Text(
                        text = stringResource(
                            if (item.status == PendingStatus.SENDING) R.string.pending_sending else R.string.pending_failed
                        ),
                        style = MaterialTheme.typography.labelMedium,
                        color = if (item.status == PendingStatus.FAILED) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            RichText(text = item.text, mentions = item.mentions, maxLines = 6)
            if (item.imageUris.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = androidx.compose.ui.platform.LocalContext.current.resources
                        .getQuantityString(R.plurals.photos_count, item.imageUris.size, item.imageUris.size),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (item.status == PendingStatus.SENDING) {
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(Modifier.fillMaxWidth())
            } else {
                val error = item.error
                if (error != null) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = error.asString(),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onRetry) { Text(stringResource(R.string.action_retry)) }
                    OutlinedButton(onClick = onDiscard) { Text(stringResource(R.string.action_discard)) }
                }
            }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
    }
}
