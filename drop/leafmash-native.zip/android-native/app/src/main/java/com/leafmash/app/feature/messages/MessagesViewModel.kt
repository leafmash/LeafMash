package com.leafmash.app.feature.messages

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leafmash.app.core.auth.AuthRepository
import com.leafmash.app.core.data.UserRepository
import com.leafmash.app.core.data.UserSummary
import com.leafmash.app.core.data.authorFallbackFor
import com.leafmash.app.core.util.UiText
import com.leafmash.app.core.util.safeCall
import com.leafmash.app.core.util.toUiText
import com.leafmash.app.feature.messages.data.Conversation
import com.leafmash.app.feature.messages.data.MessagesRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ConversationRow(
    val id: String,
    val otherUid: String,
    val user: UserSummary,
    val preview: String,
    val previewIsMine: Boolean,
    val timeMs: Long,
    val unread: Boolean,
    val lastActiveMs: Long
)

data class MessagesUiState(
    val loading: Boolean = true,
    val rows: List<ConversationRow> = emptyList(),
    val classUnread: Int = 0
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class MessagesViewModel @Inject constructor(
    private val repository: MessagesRepository,
    private val userRepository: UserRepository,
    auth: AuthRepository
) : ViewModel() {

    private val myUid = auth.currentUid.orEmpty()

    private val conversations: StateFlow<List<Conversation>?> = repository.conversations()
        .map { list -> list.filter { it.hasMessages() && !it.isHiddenFor(myUid) }.sortedByDescending { it.lastMessageAtMs } }
        .onEach { list -> userRepository.ensure(list.mapNotNull { it.otherUid(myUid) }) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    private val presence: Flow<Map<String, Long>> = conversations
        .filterNotNull()
        .map { list -> list.mapNotNull { it.otherUid(myUid) } }
        .distinctUntilChanged()
        .flatMapLatest { uids -> repository.lastActive(uids).onStart { emit(emptyMap()) } }

    val state: StateFlow<MessagesUiState> = combine(
        conversations,
        repository.classUnread().onStart { emit(0) },
        userRepository.users,
        presence
    ) { list, classUnread, users, active ->
        if (list == null) {
            MessagesUiState(loading = true, classUnread = classUnread)
        } else {
            MessagesUiState(
                loading = false,
                classUnread = classUnread,
                rows = list.mapNotNull { conversation ->
                    val other = conversation.otherUid(myUid) ?: return@mapNotNull null
                    ConversationRow(
                        id = conversation.id,
                        otherUid = other,
                        user = users[other] ?: authorFallbackFor(other),
                        preview = conversation.lastMessageText,
                        previewIsMine = conversation.lastSenderUid == myUid,
                        timeMs = conversation.lastMessageAtMs,
                        unread = conversation.isUnreadFor(myUid),
                        lastActiveMs = active[other] ?: 0L
                    )
                }
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), MessagesUiState())

    private val eventChannel = Channel<UiText>(Channel.BUFFERED)
    val events: Flow<UiText> = eventChannel.receiveAsFlow()

    fun deleteConversation(id: String) {
        viewModelScope.launch {
            safeCall { repository.deleteConversationForMe(id) }
                .onFailure { eventChannel.send(it.toUiText()) }
        }
    }
}
