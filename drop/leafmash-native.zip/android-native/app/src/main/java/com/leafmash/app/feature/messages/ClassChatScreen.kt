package com.leafmash.app.feature.messages

import androidx.compose.ui.graphics.Color
import com.leafmash.app.ui.components.LeafTopAppBar
import android.net.Uri
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leafmash.app.R
import com.leafmash.app.ui.components.CollectSnackbars

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClassChatScreen(
    onBack: () -> Unit,
    viewModel: ClassChatViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val users by viewModel.users.collectAsStateWithLifecycle()
    val playback by viewModel.playback.collectAsStateWithLifecycle()
    val recorderState by viewModel.recorder.state.collectAsStateWithLifecycle()
    val isAdmin by viewModel.isAdmin.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    CollectSnackbars(viewModel.events, snackbar)

    LifecycleResumeEffect(Unit) {
        viewModel.setScreenActive(true)
        onPauseOrDispose { viewModel.setScreenActive(false) }
    }

    Scaffold(
        topBar = {
            LeafTopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.chat_class_title))
                        Text(
                            text = stringResource(R.string.chat_class_subtitle),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            ChatComposer(
                text = viewModel.text,
                onTextChange = viewModel::onTextChange,
                onSend = viewModel::submit,
                recorder = viewModel.recorder,
                recorderState = recorderState,
                onMicDenied = viewModel::permissionDenied,
                editing = viewModel.editingId != null,
                onCancelEdit = viewModel::cancelEdit,
                allowVoice = true
            )
        }
    ) { inner ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(inner)
        ) {
            when {
                state.loading -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                state.messages.isEmpty() -> Text(
                    text = stringResource(R.string.chat_class_empty),
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .fillMaxWidth()
                        .padding(32.dp)
                )
                else -> ChatMessageList(
                    messages = state.messages,
                    myUid = viewModel.myUid,
                    showSender = true,
                    users = users,
                    receiptFor = { Receipt.NONE },
                    playback = playback,
                    canEdit = { message ->
                        message.senderUid == viewModel.myUid && !message.isVoice && !message.pending && !message.failed
                    },
                    canDelete = { message ->
                        message.failed || ((message.senderUid == viewModel.myUid || isAdmin) && !message.pending)
                    },
                    onTogglePlay = { message ->
                        viewModel.togglePlay(message.id, Uri.parse(message.audioUrl), message.audioDurationSec)
                    },
                    onSeek = { message, position -> viewModel.seekVoice(message.id, position) },
                    onCycleSpeed = viewModel::cycleSpeed,
                    onRetry = { message -> viewModel.retry(message.id) },
                    onEdit = viewModel::startEdit,
                    onDelete = viewModel::delete,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}
