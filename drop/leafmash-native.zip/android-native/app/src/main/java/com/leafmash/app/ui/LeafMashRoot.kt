package com.leafmash.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.leafmash.app.ui.splash.AnimatedSplash
import com.leafmash.app.ui.theme.LeafPalette
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leafmash.app.AppViewModel
import com.leafmash.app.core.session.SessionState
import com.leafmash.app.core.settings.ThemePreference
import com.leafmash.app.core.util.asString
import com.leafmash.app.feature.auth.AuthScreen
import com.leafmash.app.feature.profile.EditProfileScreen
import com.leafmash.app.ui.components.ErrorScreen
import com.leafmash.app.ui.components.LoadingScreen
import com.leafmash.app.ui.components.UpdateGate
import com.leafmash.app.ui.navigation.LeafMashNavHost
import com.leafmash.app.ui.theme.LeafMashTheme

@Composable
fun LeafMashRoot(viewModel: AppViewModel, onSplashShown: () -> Unit = {}) {
    val preference by viewModel.themePreference.collectAsStateWithLifecycle()
    val session by viewModel.session.collectAsStateWithLifecycle()
    val ready by viewModel.isReady.collectAsStateWithLifecycle()
    val resolved = preference ?: ThemePreference.SYSTEM
    val themeLoaded = preference != null
    var introDone by rememberSaveable { mutableStateOf(false) }
    var splashDone by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(introDone, ready) {
        if (introDone && ready) splashDone = true
    }
    LeafMashTheme(preference = resolved) {
        Box(Modifier.fillMaxSize()) {
            if (themeLoaded) UpdateGate {
                when (val state = session) {
                    SessionState.Loading -> if (splashDone) {
                        LoadingScreen()
                    } else {
                        Box(Modifier.fillMaxSize().background(LeafPalette.Forest900))
                    }
                    is SessionState.SignedOut -> AuthScreen(notice = state.message)
                    is SessionState.NeedsProfile -> EditProfileScreen(
                        firstTime = true,
                        onBack = {},
                        onSignOut = viewModel::signOut
                    )
                    is SessionState.Ready -> LeafMashNavHost()
                    is SessionState.Error -> ErrorScreen(
                        message = state.message.asString(),
                        onRetry = viewModel::retry,
                        onSignOut = viewModel::signOut
                    )
                }
            }
            AnimatedVisibility(
                visible = !splashDone,
                enter = EnterTransition.None,
                exit = fadeOut(tween(SPLASH_EXIT_MILLIS)) + scaleOut(tween(SPLASH_EXIT_MILLIS), targetScale = 1.05f)
            ) {
                AnimatedSplash(
                    showLoader = introDone,
                    onIntroFinished = { introDone = true },
                    onFirstFrame = onSplashShown
                )
            }
        }
    }
}

private const val SPLASH_EXIT_MILLIS = 380
