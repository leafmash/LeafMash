package com.leafmash.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leafmash.app.AppViewModel
import com.leafmash.app.core.session.SessionState
import com.leafmash.app.core.util.asString
import com.leafmash.app.feature.auth.AuthScreen
import com.leafmash.app.feature.profile.EditProfileScreen
import com.leafmash.app.ui.components.ErrorScreen
import com.leafmash.app.ui.components.LoadingScreen
import com.leafmash.app.ui.components.UpdateGate
import com.leafmash.app.ui.navigation.LeafMashNavHost
import com.leafmash.app.ui.theme.LeafMashTheme

@Composable
fun LeafMashRoot(viewModel: AppViewModel) {
    val preference by viewModel.themePreference.collectAsStateWithLifecycle()
    val session by viewModel.session.collectAsStateWithLifecycle()
    val resolved = preference ?: return
    LeafMashTheme(preference = resolved) {
        UpdateGate {
            when (val state = session) {
                SessionState.Loading -> LoadingScreen()
                is SessionState.SignedOut -> AuthScreen(notice = state.message)
                is SessionState.NeedsProfile -> EditProfileScreen(
                    firstTime = true,
                    onBack = {},
                    onSignOut = viewModel::signOut
                )
                is SessionState.Ready -> LeafMashNavHost()
                is SessionState.Error -> ErrorScreen(
                    message = state.message.asString(),
                    onRetry = viewModel::retry,
                    onSignOut = viewModel::signOut
                )
            }
        }
    }
}
