package com.leafmash.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leafmash.app.AppViewModel
import com.leafmash.app.ui.navigation.LeafMashNavHost
import com.leafmash.app.ui.theme.LeafMashTheme

@Composable
fun LeafMashRoot(viewModel: AppViewModel) {
    val preference by viewModel.themePreference.collectAsStateWithLifecycle()
    val resolved = preference ?: return
    LeafMashTheme(preference = resolved) {
        LeafMashNavHost()
    }
}
