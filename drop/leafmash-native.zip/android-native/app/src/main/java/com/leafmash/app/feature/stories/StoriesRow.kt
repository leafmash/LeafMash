package com.leafmash.app.feature.stories

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.leafmash.app.R
import com.leafmash.app.core.data.StoryGroup
import com.leafmash.app.core.data.UserSummary
import com.leafmash.app.core.data.authorFallbackFor
import com.leafmash.app.core.data.displayName
import com.leafmash.app.feature.stories.data.StoryRepository
import com.leafmash.app.ui.components.RingAvatar

private val StoryAvatarSize = 58.dp
private val StoryTileWidth = 74.dp

@Composable
fun StoriesRow(
    groups: List<StoryGroup>,
    users: Map<String, UserSummary>,
    myUid: String,
    uploading: Boolean,
    onAdd: () -> Unit,
    onOpen: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val mineIndex = groups.indexOfFirst { it.authorUid == myUid }
    LazyRow(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        item(key = "mine") {
            val me = users[myUid] ?: authorFallbackFor(myUid)
            StoryTile(
                label = stringResource(R.string.story_your),
                user = me,
                ring = mineIndex >= 0,
                badge = {
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surface)
                            .padding(2.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                            .clickable(enabled = !uploading, onClick = onAdd),
                        contentAlignment = Alignment.Center
                    ) {
                        if (uploading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(12.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.Add,
                                contentDescription = stringResource(R.string.story_add),
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                },
                onClick = { if (mineIndex >= 0) onOpen(mineIndex) else onAdd() }
            )
        }
        items(groups.filter { it.authorUid != myUid }, key = { it.authorUid }) { group ->
            val user = users[group.authorUid] ?: authorFallbackFor(group.authorUid)
            StoryTile(
                label = user.displayName.substringBefore(' '),
                user = user,
                ring = group.hasUnseen(myUid),
                badge = null,
                onClick = { onOpen(groups.indexOf(group)) }
            )
        }
    }
}

@Composable
private fun StoryTile(
    label: String,
    user: UserSummary,
    ring: Boolean,
    badge: (@Composable () -> Unit)?,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .width(StoryTileWidth)
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box {
            RingAvatar(
                name = user.displayName,
                seed = user.uid,
                photoUrl = user.photoUrl,
                size = StoryAvatarSize,
                ring = ring
            )
            if (badge != null) {
                Box(Modifier.align(Alignment.BottomEnd)) { badge() }
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = if (ring) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun StoryComposeDialog(
    uri: Uri,
    uploading: Boolean,
    onCancel: () -> Unit,
    onShare: (String) -> Unit
) {
    var caption by rememberSaveable { mutableStateOf("") }
    Dialog(
        onDismissRequest = { if (!uploading) onCancel() },
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Column(Modifier.fillMaxSize().background(Color.Black).imePadding()) {
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 4.dp, vertical = 4.dp)) {
                IconButton(onClick = onCancel, enabled = !uploading) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = stringResource(R.string.action_close),
                        tint = Color.White
                    )
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                AsyncImage(
                    model = uri,
                    contentDescription = stringResource(R.string.story_cd),
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                color = MaterialTheme.colorScheme.surface
            ) {
                Column(Modifier.navigationBarsPadding().padding(16.dp)) {
                    OutlinedTextField(
                        value = caption,
                        onValueChange = { if (it.length <= StoryRepository.CAPTION_LIMIT) caption = it },
                        placeholder = { Text(stringResource(R.string.story_caption_hint)) },
                        maxLines = 3,
                        enabled = !uploading,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = { onShare(caption) },
                        enabled = !uploading,
                        modifier = Modifier.fillMaxWidth().height(52.dp)
                    ) {
                        if (uploading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(stringResource(R.string.story_posting))
                        } else {
                            Text(stringResource(R.string.story_share))
                        }
                    }
                }
            }
        }
    }
}
