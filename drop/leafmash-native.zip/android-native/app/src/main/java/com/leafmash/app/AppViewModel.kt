package com.leafmash.app

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leafmash.app.core.auth.AuthRepository
import com.leafmash.app.core.data.UserProfile
import com.leafmash.app.core.presence.PresenceRepository
import com.leafmash.app.core.profile.ProfileRepository
import com.leafmash.app.core.push.PushSession
import com.leafmash.app.core.profile.ResolveResult
import com.leafmash.app.core.session.SessionState
import com.leafmash.app.core.settings.SettingsRepository
import com.leafmash.app.core.settings.ThemePreference
import com.leafmash.app.core.util.UiText
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@HiltViewModel
class AppViewModel @Inject constructor(
    settings: SettingsRepository,
    private val authRepository: AuthRepository,
    private val profiles: ProfileRepository,
    private val presence: PresenceRepository,
    private val pushSession: PushSession
) : ViewModel() {

    val themePreference: StateFlow<ThemePreference?> = settings.themePreference
        .map<ThemePreference, ThemePreference?> { it }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private val sessionState = MutableStateFlow<SessionState>(SessionState.Loading)
    val session: StateFlow<SessionState> = sessionState.asStateFlow()

    private val splashTimedOut = MutableStateFlow(false)

    val isReady: StateFlow<Boolean> = combine(themePreference, sessionState, splashTimedOut) { theme, state, timedOut ->
        theme != null && (state !is SessionState.Loading || timedOut)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, false)

    private var pendingMessage: UiText? = null
    private var retryJob: Job? = null

    init {
        viewModelScope.launch {
            delay(SPLASH_TIMEOUT_MS)
            splashTimedOut.value = true
        }
        viewModelScope.launch {
            authRepository.authState.collectLatest { user -> handleUser(user?.uid) }
        }
        viewModelScope.launch {
            sessionState.collect { state ->
                if (state is SessionState.Ready) pushSession.start()
            }
        }
        viewModelScope.launch {
            profiles.current.filterNotNull().collect { profile ->
                val state = sessionState.value
                if (state is SessionState.Ready || state is SessionState.NeedsProfile) {
                    sessionState.value = stateFor(profile)
                }
            }
        }
    }

    fun retry() {
        val uid = authRepository.currentUid
        retryJob?.cancel()
        retryJob = viewModelScope.launch { handleUser(uid) }
    }

    fun signOut() {
        viewModelScope.launch { authRepository.signOut() }
    }

    suspend fun runPresence() {
        while (true) {
            val state = sessionState.value
            if (state is SessionState.Ready || state is SessionState.NeedsProfile) {
                presence.ping()
            }
            delay(PRESENCE_INTERVAL_MS)
        }
    }

    private suspend fun handleUser(uid: String?) {
        if (uid == null) {
            profiles.clearCurrent()
            sessionState.value = SessionState.SignedOut(pendingMessage)
            pendingMessage = null
            return
        }
        if (!authRepository.awaitPendingSignUp()) return
        val cached = profiles.loadCached(uid)
        if (cached != null) {
            profiles.setCurrent(cached, persist = false)
            sessionState.value = stateFor(cached)
        } else {
            sessionState.value = SessionState.Loading
        }
        when (val result = profiles.resolve(uid)) {
            is ResolveResult.Loaded -> {
                profiles.setCurrent(result.profile)
                sessionState.value = stateFor(result.profile)
            }
            is ResolveResult.Rejected -> rejectAndSignOut(result.message)
            is ResolveResult.Failed -> when {
                result.error.statusCode == HTTP_CONFLICT -> rejectAndSignOut(result.error.message)
                cached != null -> Unit
                else -> sessionState.value = SessionState.Error(UiText.Plain(result.error.message))
            }
        }
    }

    private suspend fun rejectAndSignOut(message: String) {
        pendingMessage = UiText.Plain(message)
        authRepository.signOut()
    }

    private fun stateFor(profile: UserProfile): SessionState =
        if (profile.profileIncomplete) SessionState.NeedsProfile(profile) else SessionState.Ready(profile)

    private companion object {
        const val SPLASH_TIMEOUT_MS = 2_500L
        const val PRESENCE_INTERVAL_MS = 25_000L
        const val HTTP_CONFLICT = 409
    }
}
