package com.leafmash.app

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leafmash.app.core.settings.SettingsRepository
import com.leafmash.app.core.settings.ThemePreference
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

@HiltViewModel
class AppViewModel @Inject constructor(
    settings: SettingsRepository
) : ViewModel() {

    val themePreference: StateFlow<ThemePreference?> = settings.themePreference
        .map<ThemePreference, ThemePreference?> { it }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val isReady: StateFlow<Boolean> = themePreference
        .map { it != null }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)
}
