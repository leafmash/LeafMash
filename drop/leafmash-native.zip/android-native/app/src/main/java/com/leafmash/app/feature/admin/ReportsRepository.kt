package com.leafmash.app.feature.admin

import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.leafmash.app.core.util.retryWithBackoff
import com.leafmash.app.core.util.snapshotFlow
import com.leafmash.app.feature.wall.data.PostActions
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

data class Report(
    val id: String,
    val postId: String,
    val postText: String,
    val reason: String,
    val reportedByName: String,
    val createdAtMs: Long
)

private fun DocumentSnapshot.toReport(): Report = Report(
    id = id,
    postId = getString("postId").orEmpty(),
    postText = getString("postText").orEmpty(),
    reason = getString("reason").orEmpty(),
    reportedByName = getString("reportedByName").orEmpty(),
    createdAtMs = getTimestamp("createdAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0L
)

@Singleton
class ReportsRepository @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val postActions: PostActions
) {

    fun observeOpen(): Flow<List<Report>> =
        firestore.collection("reports")
            .whereEqualTo("resolved", false)
            .snapshotFlow()
            .map { snapshot ->
                snapshot.documents.map { it.toReport() }.sortedByDescending { it.createdAtMs }
            }
            .retryWithBackoff()

    suspend fun dismiss(reportId: String) {
        firestore.collection("reports").document(reportId).update("resolved", true).await()
    }

    suspend fun removePost(report: Report) {
        if (report.postId.isNotEmpty()) postActions.delete(report.postId).getOrThrow()
        dismiss(report.id)
    }
}
