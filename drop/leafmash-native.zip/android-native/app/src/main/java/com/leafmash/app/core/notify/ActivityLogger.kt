package com.leafmash.app.core.notify

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.leafmash.app.core.profile.ProfileRepository
import com.leafmash.app.core.util.AppScope
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

@Singleton
class ActivityLogger @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth,
    private val profiles: ProfileRepository,
    private val appScope: AppScope
) {

    fun log(
        type: String,
        text: String = "",
        targetUid: String? = null,
        postId: String? = null,
        resourceId: String? = null,
        noticeId: String? = null,
        deadlineId: String? = null
    ) {
        val user = auth.currentUser ?: return
        val actorName = profiles.current.value?.name?.ifBlank { null } ?: user.email ?: "Someone"
        val data = hashMapOf<String, Any?>(
            "type" to type,
            "text" to text,
            "targetUid" to targetUid,
            "postId" to postId,
            "resourceId" to resourceId,
            "noticeId" to noticeId,
            "deadlineId" to deadlineId,
            "actorUid" to user.uid,
            "actorName" to actorName,
            "actorEmail" to user.email,
            "createdAt" to FieldValue.serverTimestamp()
        )
        appScope.scope.launch {
            try {
                firestore.collection("activity").add(data).await()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Unit
            }
        }
    }

    fun deleteForPost(postId: String) = deleteWhere("postId", postId)

    fun deleteForResource(resourceId: String) = deleteWhere("resourceId", resourceId)

    fun deleteForNotice(noticeId: String) = deleteWhere("noticeId", noticeId)

    fun deleteForDeadline(deadlineId: String) = deleteWhere("deadlineId", deadlineId)

    private fun deleteWhere(field: String, value: String) {
        appScope.scope.launch {
            try {
                val snapshot = firestore.collection("activity").whereEqualTo(field, value).get().await()
                snapshot.documents.forEach { it.reference.delete().await() }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Unit
            }
        }
    }
}
