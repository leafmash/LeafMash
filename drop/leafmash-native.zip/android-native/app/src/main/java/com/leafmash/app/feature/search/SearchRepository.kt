package com.leafmash.app.feature.search

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.leafmash.app.core.data.Post
import com.leafmash.app.core.data.toPost
import com.leafmash.app.feature.deadlines.Deadline
import com.leafmash.app.feature.deadlines.toDeadline
import com.leafmash.app.feature.directory.data.Classmate
import com.leafmash.app.feature.directory.data.DirectoryRepository
import com.leafmash.app.feature.notifications.data.Notice
import com.leafmash.app.feature.notifications.data.toNotice
import com.leafmash.app.feature.resources.data.Resource
import com.leafmash.app.feature.resources.data.toResource
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.tasks.await

data class SearchData(
    val posts: List<Post>,
    val resources: List<Resource>,
    val notices: List<Notice>,
    val deadlines: List<Deadline>,
    val classmates: List<Classmate>
)

@Singleton
class SearchRepository @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val directory: DirectoryRepository
) {

    suspend fun load(): SearchData = coroutineScope {
        val posts = async {
            firestore.collection("posts").orderBy("createdAt", Query.Direction.DESCENDING).limit(FETCH_CAP)
                .get().await().documents.mapNotNull { it.toPost() }
        }
        val resources = async {
            firestore.collection("resources").orderBy("createdAt", Query.Direction.DESCENDING).limit(FETCH_CAP)
                .get().await().documents.map { it.toResource() }
        }
        val notices = async {
            firestore.collection("notices").orderBy("createdAt", Query.Direction.DESCENDING).limit(FETCH_CAP)
                .get().await().documents.map { it.toNotice() }
        }
        val deadlines = async {
            firestore.collection("deadlines").orderBy("dueAt", Query.Direction.DESCENDING).limit(FETCH_CAP)
                .get().await().documents.map { it.toDeadline() }
        }
        val classmates = async { directory.loadAll() }
        SearchData(posts.await(), resources.await(), notices.await(), deadlines.await(), classmates.await())
    }

    private companion object {
        const val FETCH_CAP = 300L
    }
}
