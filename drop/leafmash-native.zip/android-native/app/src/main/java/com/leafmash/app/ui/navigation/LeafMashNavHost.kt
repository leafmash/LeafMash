package com.leafmash.app.ui.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.getValue
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.leafmash.app.core.push.DeepLinkTarget
import com.leafmash.app.core.push.DeepLinkViewModel
import com.leafmash.app.feature.admin.ReportsScreen
import com.leafmash.app.feature.admin.VerifiedScreen
import com.leafmash.app.feature.directory.DirectoryScreen
import com.leafmash.app.feature.search.SearchScreen
import com.leafmash.app.feature.userprofile.UserProfileScreen
import com.leafmash.app.feature.messages.ClassChatScreen
import com.leafmash.app.feature.messages.DmThreadScreen
import com.leafmash.app.feature.messages.MessagesScreen
import com.leafmash.app.feature.messages.NavBadgesViewModel
import com.leafmash.app.feature.messages.NewChatScreen
import com.leafmash.app.feature.notifications.NotificationSetupHost
import com.leafmash.app.feature.notifications.NotificationsScreen
import com.leafmash.app.feature.profile.EditProfileScreen
import com.leafmash.app.feature.profile.ProfileScreen
import com.leafmash.app.feature.deadlines.DeadlinesScreen
import com.leafmash.app.feature.resources.ResourcesScreen
import com.leafmash.app.feature.routine.RoutineScreen
import com.leafmash.app.feature.settings.SettingsScreen
import com.leafmash.app.feature.wall.ComposerScreen
import com.leafmash.app.feature.wall.HashtagScreen
import com.leafmash.app.feature.wall.PostDetailScreen
import com.leafmash.app.feature.wall.SavedScreen
import com.leafmash.app.feature.wall.WallScreen

@Composable
fun LeafMashNavHost(
    badges: NavBadgesViewModel = hiltViewModel(),
    deepLinkModel: DeepLinkViewModel = hiltViewModel()
) {
    val messagesBadge by badges.messagesBadge.collectAsStateWithLifecycle()
    val navController = rememberNavController()
    val pendingLink by deepLinkModel.handler.pending.collectAsStateWithLifecycle()

    LaunchedEffect(pendingLink) {
        val target = pendingLink ?: return@LaunchedEffect
        navController.openDeepLink(target)
        deepLinkModel.handler.consume(target)
    }
    NotificationSetupHost()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination
    val showBottomBar = TopLevelDestination.entries.any { destination ->
        currentDestination?.hierarchy?.any { it.route == destination.route } == true
    }

    val openUser: (String) -> Unit = { uid ->
        if (uid.isNotEmpty() && uid == badges.myUid) {
            navController.openTopLevel(TopLevelDestination.PROFILE.route)
        } else {
            navController.navigate(Routes.userProfile(uid))
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (showBottomBar) {
                LeafBottomBar(
                    isSelected = { destination ->
                        currentDestination?.hierarchy?.any { it.route == destination.route } == true
                    },
                    messagesBadge = messagesBadge,
                    onSelect = { destination ->
                        navController.navigate(destination.route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
        }
    ) { padding ->
        CompositionLocalProvider(
            LocalOpenProfile provides openUser,
            LocalOpenMenu provides {
                if (navController.currentDestination?.route != Routes.SETTINGS) navController.navigate(Routes.SETTINGS)
            }
        ) {
            NavHost(
                navController = navController,
                startDestination = TopLevelDestination.WALL.route,
                modifier = Modifier.padding(padding).consumeWindowInsets(padding),
                enterTransition = { pushEnter() },
                exitTransition = { pushExit() },
                popEnterTransition = { popEnter() },
                popExitTransition = { popExit() }
            ) {
                composable(TopLevelDestination.WALL.route) {
                    WallScreen(
                        onOpenPost = { id, focus -> navController.navigate(Routes.postDetail(id, focus)) },
                        onCompose = { navController.navigate(Routes.compose()) },
                        onEditPost = { id -> navController.navigate(Routes.compose(id)) },
                        onOpenHashtag = { tag -> navController.navigate(Routes.hashtag(tag)) },
                        onOpenSaved = { navController.navigate(Routes.SAVED) },
                        onOpenNotifications = { navController.navigate(Routes.notifications()) },
                        onOpenSearch = { navController.navigate(Routes.SEARCH) }
                    )
                }
                composable(TopLevelDestination.RESOURCES.route) { ResourcesScreen() }
                composable(TopLevelDestination.MESSAGES.route) {
                    MessagesScreen(
                        onOpenClassChat = { navController.navigate(Routes.CLASS_CHAT) },
                        onOpenThread = { uid -> navController.navigate(Routes.dmThread(uid)) },
                        onNewChat = { navController.navigate(Routes.NEW_CHAT) }
                    )
                }
                composable(Routes.CLASS_CHAT) {
                    ClassChatScreen(onBack = { navController.popBackStack() })
                }
                composable(Routes.NEW_CHAT) {
                    NewChatScreen(
                        onBack = { navController.popBackStack() },
                        onOpenThread = { uid ->
                            navController.navigate(Routes.dmThread(uid)) {
                                popUpTo(Routes.NEW_CHAT) { inclusive = true }
                            }
                        }
                    )
                }
                composable(
                    route = Routes.DM_THREAD,
                    arguments = listOf(navArgument("uid") { type = NavType.StringType })
                ) {
                    DmThreadScreen(onBack = { navController.popBackStack() })
                }
                composable(TopLevelDestination.DIRECTORY.route) {
                    DirectoryScreen(
                        onOpenProfile = openUser,
                        onMessage = { uid -> navController.openDm(uid) }
                    )
                }
                composable(
                    route = Routes.USER_PROFILE,
                    arguments = listOf(navArgument("uid") { type = NavType.StringType })
                ) {
                    UserProfileScreen(
                        onBack = { navController.popBackStack() },
                        onMessage = { uid -> navController.openDm(uid) },
                        onOpenPost = { id, focus -> navController.navigate(Routes.postDetail(id, focus)) },
                        onEditPost = { id -> navController.navigate(Routes.compose(id)) },
                        onOpenHashtag = { tag -> navController.navigate(Routes.hashtag(tag)) }
                    )
                }
                composable(Routes.SEARCH) {
                    SearchScreen(
                        onBack = { navController.popBackStack() },
                        onOpenPost = { id -> navController.navigate(Routes.postDetail(id, false)) },
                        onOpenProfile = openUser,
                        onOpenResources = { navController.openTopLevel(TopLevelDestination.RESOURCES.route) },
                        onOpenNotices = { navController.navigate(Routes.notifications(0)) },
                        onOpenDeadlines = { navController.navigate(Routes.DEADLINES) }
                    )
                }
                composable(Routes.REPORTS) {
                    ReportsScreen(
                        onBack = { navController.popBackStack() },
                        onOpenPost = { id -> navController.navigate(Routes.postDetail(id, false)) }
                    )
                }
                composable(Routes.VERIFIED) {
                    VerifiedScreen(onBack = { navController.popBackStack() })
                }
                composable(TopLevelDestination.PROFILE.route) {
                    ProfileScreen(
                        onOpenSettings = { navController.navigate(Routes.SETTINGS) },
                        onEditProfile = { navController.navigate(Routes.EDIT_PROFILE) },
                        onOpenPost = { id, focus -> navController.navigate(Routes.postDetail(id, focus)) },
                        onEditPost = { id -> navController.navigate(Routes.compose(id)) },
                        onOpenHashtag = { tag -> navController.navigate(Routes.hashtag(tag)) }
                    )
                }
                composable(Routes.EDIT_PROFILE) {
                    EditProfileScreen(
                        firstTime = false,
                        onBack = { navController.popBackStack() },
                        onSaved = { navController.popBackStack() }
                    )
                }
                composable(
                    route = Routes.POST_DETAIL,
                    arguments = listOf(
                        navArgument("postId") { type = NavType.StringType },
                        navArgument("focus") {
                            type = NavType.BoolType
                            defaultValue = false
                        }
                    )
                ) {
                    PostDetailScreen(
                        onBack = { navController.popBackStack() },
                        onEditPost = { id -> navController.navigate(Routes.compose(id)) },
                        onOpenHashtag = { tag -> navController.navigate(Routes.hashtag(tag)) }
                    )
                }
                composable(
                    route = Routes.COMPOSE,
                    arguments = listOf(
                        navArgument("postId") {
                            type = NavType.StringType
                            nullable = true
                            defaultValue = null
                        }
                    )
                ) {
                    ComposerScreen(onClose = { navController.popBackStack() })
                }
                composable(Routes.SAVED) {
                    SavedScreen(
                        onBack = { navController.popBackStack() },
                        onOpenPost = { id, focus -> navController.navigate(Routes.postDetail(id, focus)) },
                        onEditPost = { id -> navController.navigate(Routes.compose(id)) },
                        onOpenHashtag = { tag -> navController.navigate(Routes.hashtag(tag)) }
                    )
                }
                composable(
                    route = Routes.HASHTAG,
                    arguments = listOf(navArgument("tag") { type = NavType.StringType })
                ) {
                    HashtagScreen(
                        onBack = { navController.popBackStack() },
                        onOpenPost = { id, focus -> navController.navigate(Routes.postDetail(id, focus)) }
                    )
                }
                composable(
                    route = Routes.NOTIFICATIONS,
                    arguments = listOf(
                        navArgument("tab") {
                            type = NavType.IntType
                            defaultValue = 0
                        }
                    )
                ) { entry ->
                    NotificationsScreen(
                        initialTab = entry.arguments?.getInt("tab") ?: 0,
                        onBack = { navController.popBackStack() },
                        onOpenPost = { id, focus -> navController.navigate(Routes.postDetail(id, focus)) },
                        onOpenResources = { navController.openTopLevel(TopLevelDestination.RESOURCES.route) },
                        onOpenRoutine = { navController.navigate(Routes.ROUTINE) },
                        onOpenDeadlines = { navController.navigate(Routes.DEADLINES) }
                    )
                }
                composable(Routes.ROUTINE) {
                    RoutineScreen(onBack = { navController.popBackStack() })
                }
                composable(Routes.DEADLINES) {
                    DeadlinesScreen(onBack = { navController.popBackStack() })
                }
                composable(Routes.SETTINGS) {
                    SettingsScreen(
                        onBack = { navController.popBackStack() },
                        onOpenRoutine = { navController.navigate(Routes.ROUTINE) },
                        onOpenDeadlines = { navController.navigate(Routes.DEADLINES) },
                        onOpenReports = { navController.navigate(Routes.REPORTS) },
                        onOpenVerified = { navController.navigate(Routes.VERIFIED) }
                    )
                }
            }
        }
    }
}

private val TopLevelRoutes: Set<String> = TopLevelDestination.entries.map { it.route }.toSet()

private fun NavBackStackEntry.isTopLevel(): Boolean = destination.route in TopLevelRoutes

private fun AnimatedContentTransitionScope<NavBackStackEntry>.betweenTabs(): Boolean =
    initialState.isTopLevel() && targetState.isTopLevel()

private const val PushMillis = 240
private const val FadeMillis = 160

private fun AnimatedContentTransitionScope<NavBackStackEntry>.pushEnter(): EnterTransition =
    if (betweenTabs()) EnterTransition.None
    else slideInHorizontally(tween(PushMillis, easing = FastOutSlowInEasing)) { it / 4 } +
        fadeIn(tween(FadeMillis))

private fun AnimatedContentTransitionScope<NavBackStackEntry>.pushExit(): ExitTransition =
    if (betweenTabs()) ExitTransition.None
    else slideOutHorizontally(tween(PushMillis, easing = FastOutSlowInEasing)) { -it / 10 } +
        fadeOut(tween(FadeMillis))

private fun AnimatedContentTransitionScope<NavBackStackEntry>.popEnter(): EnterTransition =
    if (betweenTabs()) EnterTransition.None
    else slideInHorizontally(tween(PushMillis, easing = FastOutSlowInEasing)) { -it / 10 } +
        fadeIn(tween(FadeMillis))

private fun AnimatedContentTransitionScope<NavBackStackEntry>.popExit(): ExitTransition =
    if (betweenTabs()) ExitTransition.None
    else slideOutHorizontally(tween(PushMillis, easing = FastOutSlowInEasing)) { it / 4 } +
        fadeOut(tween(FadeMillis))

private fun NavHostController.openTopLevel(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

private fun NavHostController.openDm(uid: String) {
    navigate(Routes.dmThread(uid))
}

private fun NavHostController.openDeepLink(target: DeepLinkTarget) {
    when (target) {
        is DeepLinkTarget.Post -> navigate(Routes.postDetail(target.postId, target.focusComment))
        is DeepLinkTarget.Dm -> {
            openTopLevel(TopLevelDestination.MESSAGES.route)
            navigate(Routes.dmThread(target.uid))
        }
        DeepLinkTarget.ClassChat -> {
            openTopLevel(TopLevelDestination.MESSAGES.route)
            navigate(Routes.CLASS_CHAT)
        }
        DeepLinkTarget.Messages -> openTopLevel(TopLevelDestination.MESSAGES.route)
        DeepLinkTarget.Resources -> openTopLevel(TopLevelDestination.RESOURCES.route)
        DeepLinkTarget.Notices -> navigate(Routes.notifications(0))
        DeepLinkTarget.Routine -> navigate(Routes.ROUTINE)
        DeepLinkTarget.Deadlines -> navigate(Routes.DEADLINES)
        DeepLinkTarget.Reports -> navigate(Routes.REPORTS)
        DeepLinkTarget.Home -> openTopLevel(TopLevelDestination.WALL.route)
    }
}
