package com.leafmash.app.ui.navigation

import androidx.compose.runtime.getValue
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.leafmash.app.feature.directory.DirectoryScreen
import com.leafmash.app.feature.messages.ClassChatScreen
import com.leafmash.app.feature.messages.DmThreadScreen
import com.leafmash.app.feature.messages.MessagesScreen
import com.leafmash.app.feature.messages.NavBadgesViewModel
import com.leafmash.app.feature.messages.NewChatScreen
import com.leafmash.app.feature.profile.EditProfileScreen
import com.leafmash.app.feature.profile.ProfileScreen
import com.leafmash.app.feature.resources.ResourcesScreen
import com.leafmash.app.feature.settings.SettingsScreen
import com.leafmash.app.feature.wall.ComposerScreen
import com.leafmash.app.feature.wall.HashtagScreen
import com.leafmash.app.feature.wall.PostDetailScreen
import com.leafmash.app.feature.wall.SavedScreen
import com.leafmash.app.feature.wall.WallScreen

@Composable
fun LeafMashNavHost(badges: NavBadgesViewModel = hiltViewModel()) {
    val messagesBadge by badges.messagesBadge.collectAsStateWithLifecycle()
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination
    val showBottomBar = TopLevelDestination.entries.any { destination ->
        currentDestination?.hierarchy?.any { it.route == destination.route } == true
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    TopLevelDestination.entries.forEach { destination ->
                        val selected = currentDestination?.hierarchy
                            ?.any { it.route == destination.route } == true
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(destination.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                val badgeCount = if (destination == TopLevelDestination.MESSAGES) messagesBadge else 0
                                BadgedBox(
                                    badge = {
                                        if (badgeCount > 0) {
                                            Badge { Text(if (badgeCount > 99) "99+" else badgeCount.toString()) }
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = if (selected) destination.selectedIcon else destination.icon,
                                        contentDescription = null
                                    )
                                }
                            },
                            label = { Text(stringResource(destination.label)) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = TopLevelDestination.WALL.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(TopLevelDestination.WALL.route) {
                WallScreen(
                    onOpenPost = { id, focus -> navController.navigate(Routes.postDetail(id, focus)) },
                    onCompose = { navController.navigate(Routes.compose()) },
                    onEditPost = { id -> navController.navigate(Routes.compose(id)) },
                    onOpenHashtag = { tag -> navController.navigate(Routes.hashtag(tag)) },
                    onOpenSaved = { navController.navigate(Routes.SAVED) }
                )
            }
            composable(TopLevelDestination.RESOURCES.route) { ResourcesScreen() }
            composable(TopLevelDestination.MESSAGES.route) {
                MessagesScreen(
                    onOpenClassChat = { navController.navigate(Routes.CLASS_CHAT) },
                    onOpenThread = { uid -> navController.navigate(Routes.dmThread(uid)) },
                    onNewChat = { navController.navigate(Routes.NEW_CHAT) }
                )
            }
            composable(Routes.CLASS_CHAT) {
                ClassChatScreen(onBack = { navController.popBackStack() })
            }
            composable(Routes.NEW_CHAT) {
                NewChatScreen(
                    onBack = { navController.popBackStack() },
                    onOpenThread = { uid ->
                        navController.navigate(Routes.dmThread(uid)) {
                            popUpTo(Routes.NEW_CHAT) { inclusive = true }
                        }
                    }
                )
            }
            composable(
                route = Routes.DM_THREAD,
                arguments = listOf(navArgument("uid") { type = NavType.StringType })
            ) {
                DmThreadScreen(onBack = { navController.popBackStack() })
            }
            composable(TopLevelDestination.DIRECTORY.route) { DirectoryScreen() }
            composable(TopLevelDestination.PROFILE.route) {
                ProfileScreen(
                    onOpenSettings = { navController.navigate(Routes.SETTINGS) },
                    onEditProfile = { navController.navigate(Routes.EDIT_PROFILE) },
                    onOpenSaved = { navController.navigate(Routes.SAVED) }
                )
            }
            composable(Routes.EDIT_PROFILE) {
                EditProfileScreen(
                    firstTime = false,
                    onBack = { navController.popBackStack() },
                    onSaved = { navController.popBackStack() }
                )
            }
            composable(
                route = Routes.POST_DETAIL,
                arguments = listOf(
                    navArgument("postId") { type = NavType.StringType },
                    navArgument("focus") {
                        type = NavType.BoolType
                        defaultValue = false
                    }
                )
            ) {
                PostDetailScreen(
                    onBack = { navController.popBackStack() },
                    onEditPost = { id -> navController.navigate(Routes.compose(id)) },
                    onOpenHashtag = { tag -> navController.navigate(Routes.hashtag(tag)) }
                )
            }
            composable(
                route = Routes.COMPOSE,
                arguments = listOf(
                    navArgument("postId") {
                        type = NavType.StringType
                        nullable = true
                        defaultValue = null
                    }
                )
            ) {
                ComposerScreen(onClose = { navController.popBackStack() })
            }
            composable(Routes.SAVED) {
                SavedScreen(
                    onBack = { navController.popBackStack() },
                    onOpenPost = { id, focus -> navController.navigate(Routes.postDetail(id, focus)) },
                    onEditPost = { id -> navController.navigate(Routes.compose(id)) },
                    onOpenHashtag = { tag -> navController.navigate(Routes.hashtag(tag)) }
                )
            }
            composable(
                route = Routes.HASHTAG,
                arguments = listOf(navArgument("tag") { type = NavType.StringType })
            ) {
                HashtagScreen(
                    onBack = { navController.popBackStack() },
                    onOpenPost = { id, focus -> navController.navigate(Routes.postDetail(id, focus)) }
                )
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(onBack = { navController.popBackStack() })
            }
        }
    }
}
