package com.leafmash.app.core.settings

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "settings")

@Singleton
class SettingsRepository @Inject constructor(
    @ApplicationContext context: Context
) {
    private val store = context.settingsDataStore

    val themePreference: Flow<ThemePreference> = store.data.map { prefs ->
        ThemePreference.fromKey(prefs[THEME_KEY])
    }

    suspend fun setThemePreference(preference: ThemePreference) {
        store.edit { prefs -> prefs[THEME_KEY] = preference.key }
    }

    private companion object {
        val THEME_KEY = stringPreferencesKey("theme")
    }
}
