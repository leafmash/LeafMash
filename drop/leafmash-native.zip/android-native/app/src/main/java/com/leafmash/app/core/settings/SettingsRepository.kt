package com.leafmash.app.core.settings

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "settings")

@Singleton
class SettingsRepository @Inject constructor(
    @ApplicationContext context: Context
) {
    private val store = context.settingsDataStore

    val themePreference: Flow<ThemePreference> = store.data.map { prefs ->
        ThemePreference.fromKey(prefs[THEME_KEY])
    }

    suspend fun setThemePreference(preference: ThemePreference) {
        store.edit { prefs -> prefs[THEME_KEY] = preference.key }
    }

    suspend fun isNotificationRationaleShown(): Boolean = store.data.first()[RATIONALE_KEY] == true

    suspend fun setNotificationRationaleShown() {
        store.edit { prefs -> prefs[RATIONALE_KEY] = true }
    }

    suspend fun isBatteryPrompted(): Boolean = store.data.first()[BATTERY_KEY] == true

    suspend fun setBatteryPrompted() {
        store.edit { prefs -> prefs[BATTERY_KEY] = true }
    }

    suspend fun isAutostartPrompted(): Boolean = store.data.first()[AUTOSTART_KEY] == true

    suspend fun setAutostartPrompted() {
        store.edit { prefs -> prefs[AUTOSTART_KEY] = true }
    }

    private companion object {
        val THEME_KEY = stringPreferencesKey("theme")
        val RATIONALE_KEY = booleanPreferencesKey("notif_rationale_shown")
        val BATTERY_KEY = booleanPreferencesKey("battery_prompted")
        val AUTOSTART_KEY = booleanPreferencesKey("autostart_prompted")
    }
}
