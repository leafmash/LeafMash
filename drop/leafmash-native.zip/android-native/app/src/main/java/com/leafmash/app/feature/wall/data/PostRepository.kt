package com.leafmash.app.feature.wall.data

import com.google.firebase.firestore.AggregateSource
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.leafmash.app.core.data.Comment
import com.leafmash.app.core.data.CommentResult
import com.leafmash.app.core.data.MentionRef
import com.leafmash.app.core.data.Post
import com.leafmash.app.core.data.toComment
import com.leafmash.app.core.data.toPost
import com.leafmash.app.core.network.ApiClient
import com.leafmash.app.core.network.ApiException
import com.leafmash.app.core.util.safeCall
import com.leafmash.app.core.util.snapshotFlow
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.put

@Singleton
class PostRepository @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val api: ApiClient
) {

    private fun posts() = firestore.collection("posts")

    private fun feedQuery(limit: Int): Query =
        posts().orderBy("createdAt", Query.Direction.DESCENDING).limit(limit.toLong())

    fun observePosts(limit: Int): Flow<List<Post>> =
        feedQuery(limit).snapshotFlow().map { snapshot -> snapshot.documents.mapNotNull { it.toPost() } }

    suspend fun fetchFirstPage(limit: Int): Result<Unit> = safeCall {
        feedQuery(limit).get().await()
        Unit
    }

    fun observePost(postId: String): Flow<Post?> =
        posts().document(postId).snapshotFlow().map { it.toPost() }

    fun observeComments(postId: String): Flow<List<Comment>> =
        posts().document(postId).collection("comments")
            .orderBy("createdAt", Query.Direction.ASCENDING)
            .snapshotFlow()
            .map { snapshot -> snapshot.documents.mapNotNull { it.toComment() } }

    suspend fun getPost(postId: String): Result<Post?> = safeCall {
        posts().document(postId).get().await().toPost()
    }

    suspend fun countComments(postId: String): Int = try {
        posts().document(postId).collection("comments").count().get(AggregateSource.SERVER).await().count.toInt()
    } catch (e: kotlin.coroutines.cancellation.CancellationException) {
        throw e
    } catch (e: Exception) {
        0
    }

    suspend fun postsWithTag(tag: String): Result<List<Post>> = safeCall {
        posts().whereArrayContains("hashtags", tag).get().await()
            .documents.mapNotNull { it.toPost() }
            .sortedByDescending { it.createdAtMs }
    }

    suspend fun postsByAuthor(uid: String): Result<List<Post>> = safeCall {
        posts().whereEqualTo("authorUid", uid).get().await()
            .documents.mapNotNull { it.toPost() }
            .sortedByDescending { it.createdAtMs }
    }

    suspend fun setPostReaction(postId: String, uid: String, emoji: String?): Result<Unit> = safeCall {
        val updates = hashMapOf<String, Any>(
            "likes" to (if (emoji != null) FieldValue.arrayUnion(uid) else FieldValue.arrayRemove(uid)),
            "reactions.$uid" to (emoji ?: FieldValue.delete())
        )
        posts().document(postId).update(updates).await()
        Unit
    }

    suspend fun setCommentReaction(postId: String, commentId: String, uid: String, emoji: String?): Result<Unit> = safeCall {
        val updates = hashMapOf<String, Any>("reactions.$uid" to (emoji ?: FieldValue.delete()))
        posts().document(postId).collection("comments").document(commentId).update(updates).await()
        Unit
    }

    suspend fun setPollVote(postId: String, uid: String, optionId: String?): Result<Unit> = safeCall {
        val updates = hashMapOf<String, Any>("poll.votes.$uid" to (optionId ?: FieldValue.delete()))
        posts().document(postId).update(updates).await()
        Unit
    }

    suspend fun setPinned(postId: String, pinned: Boolean): Result<Unit> = safeCall {
        val updates = hashMapOf<String, Any>(
            "pinned" to pinned,
            "pinnedAt" to (if (pinned) FieldValue.serverTimestamp() else FieldValue.delete())
        )
        posts().document(postId).update(updates).await()
        Unit
    }

    suspend fun deletePost(postId: String): Result<Unit> = safeCall {
        val ref = posts().document(postId)
        val comments = ref.collection("comments").get().await()
        coroutineScope {
            comments.documents.map { doc -> async { doc.reference.delete().await() } }.awaitAll()
        }
        ref.delete().await()
        Unit
    }

    suspend fun addReport(
        postId: String,
        postAuthorUid: String,
        postText: String,
        reason: String,
        reporterUid: String,
        reporterName: String
    ): Result<String> = safeCall {
        val data = hashMapOf<String, Any>(
            "postId" to postId,
            "postAuthorUid" to postAuthorUid,
            "postText" to postText.take(REPORT_TEXT_LIMIT),
            "reason" to reason,
            "reportedByUid" to reporterUid,
            "reportedByName" to reporterName,
            "createdAt" to FieldValue.serverTimestamp(),
            "resolved" to false
        )
        firestore.collection("reports").add(data).await().id
    }

    suspend fun createPost(
        text: String,
        images: List<String>,
        mentions: List<MentionRef>,
        pollOptions: List<String>,
        skipCooldown: Boolean
    ): Result<String> {
        val payload = buildJsonObject {
            put("text", text)
            put("images", JsonArray(images.map { JsonPrimitive(it) }))
            put("mentions", mentionsJson(mentions))
            if (pollOptions.size >= MIN_POLL_OPTIONS) {
                put("poll", buildJsonObject {
                    put("options", JsonArray(pollOptions.mapIndexed { index, option ->
                        buildJsonObject {
                            put("id", "opt$index")
                            put("text", option)
                        }
                    }))
                    put("votes", JsonObject(emptyMap()))
                })
            }
        }
        return api.call("create-post", payload, skipCooldown).mapCatching { body ->
            body.text("id").ifEmpty { throw ApiException("Unexpected response from the server.") }
        }
    }

    suspend fun editPost(postId: String, text: String, images: List<String>, mentions: List<MentionRef>): Result<Unit> {
        val payload = buildJsonObject {
            put("postId", postId)
            put("text", text)
            put("images", JsonArray(images.map { JsonPrimitive(it) }))
            put("mentions", mentionsJson(mentions))
        }
        return api.call("edit-post", payload).map { }
    }

    suspend fun createComment(
        postId: String,
        text: String,
        mentions: List<MentionRef>,
        replyToId: String?
    ): Result<CommentResult> {
        val payload = buildJsonObject {
            put("postId", postId)
            put("text", text)
            put("mentions", mentionsJson(mentions))
            if (replyToId != null) {
                put("replyTo", buildJsonObject { put("id", replyToId) })
            }
        }
        return api.call("create-comment", payload).map { body ->
            CommentResult(
                id = body.text("id"),
                postAuthorUid = body.text("postAuthorUid"),
                replyTargetUid = body.text("replyTargetUid")
            )
        }
    }

    suspend fun editComment(postId: String, commentId: String, text: String, mentions: List<MentionRef>): Result<Unit> {
        val payload = buildJsonObject {
            put("postId", postId)
            put("commentId", commentId)
            put("text", text)
            put("mentions", mentionsJson(mentions))
        }
        return api.call("edit-comment", payload).map { }
    }

    suspend fun deleteComment(postId: String, commentId: String): Result<Unit> {
        val payload = buildJsonObject {
            put("postId", postId)
            put("commentId", commentId)
        }
        return api.call("delete-comment", payload).map { }
    }

    private fun mentionsJson(mentions: List<MentionRef>): JsonArray = JsonArray(
        mentions.map { mention ->
            buildJsonObject {
                put("uid", mention.uid)
                put("name", mention.name)
            }
        }
    )

    private fun JsonObject.text(key: String): String = (this[key] as? JsonPrimitive)?.contentOrNull.orEmpty()

    private companion object {
        const val REPORT_TEXT_LIMIT = 300
        const val MIN_POLL_OPTIONS = 2
    }
}
