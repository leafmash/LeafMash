package com.leafmash.app.feature.stories.data

import com.google.firebase.Timestamp
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.leafmash.app.core.data.Story
import com.leafmash.app.core.data.toStory
import com.leafmash.app.core.util.safeCall
import com.leafmash.app.core.util.snapshotFlow
import java.util.Date
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

@Singleton
class StoryRepository @Inject constructor(
    private val firestore: FirebaseFirestore
) {

    private fun stories() = firestore.collection("stories")

    fun observeActive(): Flow<List<Story>> =
        stories()
            .whereGreaterThan("expiresAt", Timestamp.now())
            .orderBy("expiresAt", Query.Direction.ASCENDING)
            .snapshotFlow()
            .map { snapshot -> snapshot.documents.mapNotNull { it.toStory() } }

    suspend fun publish(uid: String, imageUrl: String, caption: String): Result<Unit> = safeCall {
        val data = hashMapOf<String, Any>(
            "authorUid" to uid,
            "imageUrl" to imageUrl,
            "caption" to caption,
            "createdAt" to FieldValue.serverTimestamp(),
            "expiresAt" to Timestamp(Date(System.currentTimeMillis() + LIFETIME_MS)),
            "viewedBy" to emptyList<String>()
        )
        stories().add(data).await()
        Unit
    }

    suspend fun markViewed(storyId: String, uid: String): Result<Unit> = safeCall {
        stories().document(storyId).update("viewedBy", FieldValue.arrayUnion(uid)).await()
        Unit
    }

    suspend fun delete(storyId: String): Result<Unit> = safeCall {
        stories().document(storyId).delete().await()
        Unit
    }

    companion object {
        const val LIFETIME_MS = 24L * 60L * 60L * 1000L
        const val CAPTION_LIMIT = 140
    }
}
