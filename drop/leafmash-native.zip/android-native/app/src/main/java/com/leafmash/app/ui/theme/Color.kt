package com.leafmash.app.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val LightColors: ColorScheme = lightColorScheme(
    primary = Color(0xFF1B5E3A),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFD7EBDD),
    onPrimaryContainer = Color(0xFF0B2A19),
    secondary = Color(0xFFB85C2C),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFFBE6D6),
    onSecondaryContainer = Color(0xFF5A2A10),
    tertiary = Color(0xFF9C7526),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFF8EFD3),
    onTertiaryContainer = Color(0xFF3F2E08),
    background = Color(0xFFF1F5EF),
    onBackground = Color(0xFF16231A),
    surface = Color(0xFFF1F5EF),
    onSurface = Color(0xFF16231A),
    surfaceVariant = Color(0xFFE4EBE1),
    onSurfaceVariant = Color(0xFF4A5A4E),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF8FBF6),
    surfaceContainer = Color(0xFFEDF2EA),
    surfaceContainerHigh = Color(0xFFE6EDE3),
    surfaceContainerHighest = Color(0xFFDEE7DA),
    outline = Color(0xFF86948A),
    outlineVariant = Color(0xFFD9E3D6),
    error = Color(0xFFB4402D),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFF6DDD7),
    onErrorContainer = Color(0xFF5C1A10)
)

val DarkColors: ColorScheme = darkColorScheme(
    primary = Color(0xFF63BD8B),
    onPrimary = Color(0xFF0B2015),
    primaryContainer = Color(0xFF1F3A2B),
    onPrimaryContainer = Color(0xFFD6E2C8),
    secondary = Color(0xFFE08A54),
    onSecondary = Color(0xFF2C1608),
    secondaryContainer = Color(0xFF3A2416),
    onSecondaryContainer = Color(0xFFF5E3D3),
    tertiary = Color(0xFFD9AB52),
    onTertiary = Color(0xFF2A1E04),
    tertiaryContainer = Color(0xFF3A2F16),
    onTertiaryContainer = Color(0xFFF4ECD4),
    background = Color(0xFF0C120F),
    onBackground = Color(0xFFEEF2EC),
    surface = Color(0xFF0C120F),
    onSurface = Color(0xFFEEF2EC),
    surfaceVariant = Color(0xFF223027),
    onSurfaceVariant = Color(0xFFB7C2B8),
    surfaceContainerLowest = Color(0xFF111915),
    surfaceContainerLow = Color(0xFF151E19),
    surfaceContainer = Color(0xFF1A241E),
    surfaceContainerHigh = Color(0xFF202B24),
    surfaceContainerHighest = Color(0xFF28352C),
    outline = Color(0xFF7F8C80),
    outlineVariant = Color(0xFF2A332B),
    error = Color(0xFFE17762),
    onError = Color(0xFF3A0F08),
    errorContainer = Color(0xFF3A1D16),
    onErrorContainer = Color(0xFFF6DDD7)
)

val AvatarPalette: List<Color> = listOf(
    Color(0xFFE11D48), Color(0xFFDB2777), Color(0xFFC026D3), Color(0xFF9333EA),
    Color(0xFF7C3AED), Color(0xFF4F46E5), Color(0xFF2563EB), Color(0xFF0EA5E9),
    Color(0xFF0891B2), Color(0xFF0D9488), Color(0xFF059669), Color(0xFF65A30D),
    Color(0xFFCA8A04), Color(0xFFD97706), Color(0xFFEA580C), Color(0xFFDC2626)
)

object LeafPalette {
    val Forest950 = Color(0xFF0B2015)
    val Forest900 = Color(0xFF0F2E1D)
    val Forest800 = Color(0xFF143A25)
    val Forest700 = Color(0xFF1A4C30)
    val Forest600 = Color(0xFF226241)
    val Forest500 = Color(0xFF2D7A51)
    val Gold500 = Color(0xFFBB9138)
    val Clay500 = Color(0xFFB85C2C)
    val Danger500 = Color(0xFFB4402D)
    val Verified = Color(0xFF1D9BF0)

    val GoldSoft = Color(0xFFF3D27A)

    val TopBarBrush: Brush = Brush.linearGradient(listOf(Forest900, Forest700, Forest600))
    val ButtonBrush: Brush = Brush.linearGradient(listOf(Forest600, Forest800))
    val FabBrush: Brush = Brush.linearGradient(listOf(Forest500, Forest800))
    val HeroBrush: Brush = Brush.linearGradient(listOf(Forest500, Forest800, Forest950))

    val SlotAccents: List<Color> = listOf(
        Color(0xFF2D7A51), Color(0xFFBB9138), Color(0xFFB85C2C), Color(0xFF2F7FC1), Color(0xFF7B4FB5)
    )
    val SlotAccentsOnDark: List<Color> = listOf(
        Color(0xFF8EE0B0), Color(0xFFF3D27A), Color(0xFFF4A77C), Color(0xFF8CC8F2), Color(0xFFCDB2F0)
    )
}
