package com.leafmash.app.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

val LightColors: ColorScheme = lightColorScheme(
    primary = Color(0xFF1A4C30),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFD6E2C8),
    onPrimaryContainer = Color(0xFF0F2E1D),
    secondary = Color(0xFFB85C2C),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFF5E3D3),
    onSecondaryContainer = Color(0xFF5A2A10),
    tertiary = Color(0xFF9C7526),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFF4ECD4),
    onTertiaryContainer = Color(0xFF3F2E08),
    background = Color(0xFFF5F1E3),
    onBackground = Color(0xFF1C2A1E),
    surface = Color(0xFFF5F1E3),
    onSurface = Color(0xFF1C2A1E),
    surfaceVariant = Color(0xFFECE4CD),
    onSurfaceVariant = Color(0xFF4D5C4A),
    surfaceContainerLowest = Color(0xFFFFFDF6),
    surfaceContainerLow = Color(0xFFFAF6E9),
    surfaceContainer = Color(0xFFF2EDDC),
    surfaceContainerHigh = Color(0xFFECE4CD),
    surfaceContainerHighest = Color(0xFFE6DDC1),
    outline = Color(0xFF8B9682),
    outlineVariant = Color(0xFFE1D7B8),
    error = Color(0xFFB4402D),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFF6DDD7),
    onErrorContainer = Color(0xFF5C1A10)
)

val DarkColors: ColorScheme = darkColorScheme(
    primary = Color(0xFF63BD8B),
    onPrimary = Color(0xFF0B2015),
    primaryContainer = Color(0xFF1F3A2B),
    onPrimaryContainer = Color(0xFFD6E2C8),
    secondary = Color(0xFFE08A54),
    onSecondary = Color(0xFF2C1608),
    secondaryContainer = Color(0xFF3A2416),
    onSecondaryContainer = Color(0xFFF5E3D3),
    tertiary = Color(0xFFD9AB52),
    onTertiary = Color(0xFF2A1E04),
    tertiaryContainer = Color(0xFF3A2F16),
    onTertiaryContainer = Color(0xFFF4ECD4),
    background = Color(0xFF0F1512),
    onBackground = Color(0xFFEEF2EC),
    surface = Color(0xFF0F1512),
    onSurface = Color(0xFFEEF2EC),
    surfaceVariant = Color(0xFF223027),
    onSurfaceVariant = Color(0xFFB7C2B8),
    surfaceContainerLowest = Color(0xFF0A0E0B),
    surfaceContainerLow = Color(0xFF131A15),
    surfaceContainer = Color(0xFF182019),
    surfaceContainerHigh = Color(0xFF1E2820),
    surfaceContainerHighest = Color(0xFF263128),
    outline = Color(0xFF7F8C80),
    outlineVariant = Color(0xFF2A332B),
    error = Color(0xFFE17762),
    onError = Color(0xFF3A0F08),
    errorContainer = Color(0xFF3A1D16),
    onErrorContainer = Color(0xFFF6DDD7)
)

val AvatarPalette: List<Color> = listOf(
    Color(0xFFE11D48), Color(0xFFDB2777), Color(0xFFC026D3), Color(0xFF9333EA),
    Color(0xFF7C3AED), Color(0xFF4F46E5), Color(0xFF2563EB), Color(0xFF0EA5E9),
    Color(0xFF0891B2), Color(0xFF0D9488), Color(0xFF059669), Color(0xFF65A30D),
    Color(0xFFCA8A04), Color(0xFFD97706), Color(0xFFEA580C), Color(0xFFDC2626)
)
