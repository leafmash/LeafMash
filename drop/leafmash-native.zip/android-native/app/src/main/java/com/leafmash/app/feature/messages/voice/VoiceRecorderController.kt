package com.leafmash.app.feature.messages.voice

import android.content.Context
import kotlin.math.min
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class RecorderUiState(
    val recording: Boolean = false,
    val elapsedSec: Int = 0,
    val levels: List<Float> = emptyList()
)

class VoiceRecorderController(
    context: Context,
    private val scope: CoroutineScope,
    private val onRecorded: (VoiceRecorder.Recording) -> Unit,
    private val onFailed: () -> Unit
) {

    private val recorder = VoiceRecorder(context)
    private val uiState = MutableStateFlow(RecorderUiState())
    val state: StateFlow<RecorderUiState> = uiState.asStateFlow()

    private var ticker: Job? = null

    fun start() {
        if (recorder.isRecording) return
        if (!recorder.start()) {
            onFailed()
            return
        }
        uiState.value = RecorderUiState(recording = true)
        ticker = scope.launch {
            while (recorder.isRecording) {
                val level = min(1f, recorder.amplitude() / FULL_SCALE)
                val elapsedMs = recorder.elapsedMs()
                uiState.value = uiState.value.copy(
                    elapsedSec = (elapsedMs / 1000L).toInt(),
                    levels = (uiState.value.levels + level).takeLast(BARS)
                )
                if (elapsedMs >= VoiceRecorder.MAX_SECONDS * 1000L) {
                    send()
                    return@launch
                }
                delay(TICK_MS)
            }
        }
    }

    fun send() {
        ticker?.cancel()
        ticker = null
        val recording = recorder.finish()
        uiState.value = RecorderUiState()
        if (recording != null) onRecorded(recording) else onFailed()
    }

    fun cancel() {
        ticker?.cancel()
        ticker = null
        recorder.cancel()
        uiState.value = RecorderUiState()
    }

    fun release() {
        cancel()
    }

    private companion object {
        const val FULL_SCALE = 12_000f
        const val BARS = 24
        const val TICK_MS = 100L
    }
}
