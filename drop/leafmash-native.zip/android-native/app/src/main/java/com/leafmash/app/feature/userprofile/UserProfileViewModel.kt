package com.leafmash.app.feature.userprofile

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.leafmash.app.core.data.UserRepository
import com.leafmash.app.feature.profile.observeByAuthor
import com.leafmash.app.feature.wall.PostActionsViewModel
import com.leafmash.app.feature.wall.data.BookmarkRepository
import com.leafmash.app.feature.wall.data.PostActions
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import com.leafmash.app.R
import com.leafmash.app.core.data.Post
import com.leafmash.app.core.data.UserProfile
import com.leafmash.app.core.util.UiText
import com.leafmash.app.core.util.safeCall
import com.leafmash.app.core.util.toUiText
import com.leafmash.app.feature.directory.data.DirectoryRepository
import com.leafmash.app.feature.messages.data.MessagesRepository
import com.leafmash.app.feature.resources.data.Resource
import com.leafmash.app.feature.resources.data.ResourceRepository
import com.leafmash.app.feature.wall.data.PostRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

sealed interface ListLoad<out T> {
    data object Idle : ListLoad<Nothing>
    data object Loading : ListLoad<Nothing>
    data class Loaded<T>(val items: List<T>) : ListLoad<T>
    data object Failed : ListLoad<Nothing>
}

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class UserProfileViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val directory: DirectoryRepository,
    private val postRepository: PostRepository,
    private val resourceRepository: ResourceRepository,
    private val messages: MessagesRepository,
    bookmarks: BookmarkRepository,
    actions: PostActions,
    userRepository: UserRepository,
    firebaseAuth: FirebaseAuth
) : PostActionsViewModel(actions, userRepository, firebaseAuth) {

    val uid: String = savedStateHandle.get<String>("uid").orEmpty()

    var profile by mutableStateOf<UserProfile?>(null)
        private set

    var loading by mutableStateOf(true)
        private set

    var failed by mutableStateOf(false)
        private set

    var blockedByMe by mutableStateOf(false)
        private set

    var blockBusy by mutableStateOf(false)
        private set

    private val postsRequested = MutableStateFlow(false)

    val posts: StateFlow<List<Post>?> = postsRequested
        .flatMapLatest { requested ->
            if (requested) {
                postRepository.observeByAuthor(uid).map<List<Post>, List<Post>?> { it }
            } else {
                emptyFlow<List<Post>?>()
            }
        }
        .onEach { list -> ensureUsers(list.orEmpty().map { it.authorUid }) }
        .catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val savedIds: StateFlow<Set<String>> = bookmarks.observe()
        .map { list -> list.filter { it.type == "post" }.map { it.postId }.toSet() }
        .catch { emit(emptySet()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptySet())

    var notes by mutableStateOf<ListLoad<Resource>>(ListLoad.Idle)
        private set

    init {
        load()
    }

    fun load() {
        loading = true
        failed = false
        viewModelScope.launch {
            safeCall { directory.fetchProfile(uid) }
                .onSuccess { loaded ->
                    profile = loaded
                    failed = loaded == null
                }
                .onFailure { failed = true }
            loading = false
        }
        if (uid != myUid && myUid.isNotEmpty()) {
            viewModelScope.launch {
                safeCall { messages.conversation(messages.conversationId(myUid, uid)).first() }
                    .onSuccess { blockedByMe = it?.blockedBy?.contains(myUid) == true }
            }
        }
    }

    fun loadPosts() {
        postsRequested.value = true
    }

    fun loadNotes() {
        if (notes != ListLoad.Idle) return
        notes = ListLoad.Loading
        viewModelScope.launch {
            safeCall { resourceRepository.byContributor(uid) }
                .onSuccess { notes = ListLoad.Loaded(it) }
                .onFailure { notes = ListLoad.Failed }
        }
    }

    fun toggleBlock() {
        if (blockBusy) return
        val next = !blockedByMe
        blockBusy = true
        viewModelScope.launch {
            safeCall { messages.setBlocked(uid, next) }
                .onSuccess { blockedByMe = next }
                .onFailure { emit(it.toUiText()) }
            blockBusy = false
        }
    }

    fun showHiddenPhoneNotice() {
        emit(UiText.Res(R.string.user_phone_hidden_toast))
    }
}
