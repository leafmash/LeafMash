package com.leafmash.app.feature.userprofile

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leafmash.app.R
import com.leafmash.app.core.auth.AuthRepository
import com.leafmash.app.core.data.Post
import com.leafmash.app.core.data.UserProfile
import com.leafmash.app.core.util.UiText
import com.leafmash.app.core.util.safeCall
import com.leafmash.app.core.util.toUiText
import com.leafmash.app.feature.directory.data.DirectoryRepository
import com.leafmash.app.feature.messages.data.MessagesRepository
import com.leafmash.app.feature.resources.data.Resource
import com.leafmash.app.feature.resources.data.ResourceRepository
import com.leafmash.app.feature.wall.data.PostRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch

sealed interface ListLoad<out T> {
    data object Idle : ListLoad<Nothing>
    data object Loading : ListLoad<Nothing>
    data class Loaded<T>(val items: List<T>) : ListLoad<T>
    data object Failed : ListLoad<Nothing>
}

@HiltViewModel
class UserProfileViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val directory: DirectoryRepository,
    private val postRepository: PostRepository,
    private val resourceRepository: ResourceRepository,
    private val messages: MessagesRepository,
    auth: AuthRepository
) : ViewModel() {

    val uid: String = savedStateHandle.get<String>("uid").orEmpty()
    val myUid: String = auth.currentUid.orEmpty()

    private val eventChannel = Channel<UiText>(Channel.BUFFERED)
    val events: Flow<UiText> = eventChannel.receiveAsFlow()

    var profile by mutableStateOf<UserProfile?>(null)
        private set

    var loading by mutableStateOf(true)
        private set

    var failed by mutableStateOf(false)
        private set

    var blockedByMe by mutableStateOf(false)
        private set

    var blockBusy by mutableStateOf(false)
        private set

    var posts by mutableStateOf<ListLoad<Post>>(ListLoad.Idle)
        private set

    var notes by mutableStateOf<ListLoad<Resource>>(ListLoad.Idle)
        private set

    init {
        load()
    }

    fun load() {
        loading = true
        failed = false
        viewModelScope.launch {
            safeCall { directory.fetchProfile(uid) }
                .onSuccess { loaded ->
                    profile = loaded
                    failed = loaded == null
                }
                .onFailure { failed = true }
            loading = false
        }
        if (uid != myUid && myUid.isNotEmpty()) {
            viewModelScope.launch {
                safeCall { messages.conversation(messages.conversationId(myUid, uid)).first() }
                    .onSuccess { blockedByMe = it?.blockedBy?.contains(myUid) == true }
            }
        }
    }

    fun loadPosts() {
        if (posts != ListLoad.Idle) return
        posts = ListLoad.Loading
        viewModelScope.launch {
            postRepository.postsByAuthor(uid)
                .onSuccess { posts = ListLoad.Loaded(it) }
                .onFailure { posts = ListLoad.Failed }
        }
    }

    fun loadNotes() {
        if (notes != ListLoad.Idle) return
        notes = ListLoad.Loading
        viewModelScope.launch {
            safeCall { resourceRepository.byContributor(uid) }
                .onSuccess { notes = ListLoad.Loaded(it) }
                .onFailure { notes = ListLoad.Failed }
        }
    }

    fun toggleBlock() {
        if (blockBusy) return
        val next = !blockedByMe
        blockBusy = true
        viewModelScope.launch {
            safeCall { messages.setBlocked(uid, next) }
                .onSuccess { blockedByMe = next }
                .onFailure { eventChannel.send(it.toUiText()) }
            blockBusy = false
        }
    }

    fun showHiddenPhoneNotice() {
        eventChannel.trySend(UiText.Res(R.string.user_phone_hidden_toast))
    }
}
