package com.leafmash.app.core.network

import kotlinx.serialization.json.JsonObject
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Path

interface LeafMashApi {

    @POST("api/{action}")
    suspend fun call(
        @Path("action") action: String,
        @Body payload: JsonObject
    ): JsonObject
}
