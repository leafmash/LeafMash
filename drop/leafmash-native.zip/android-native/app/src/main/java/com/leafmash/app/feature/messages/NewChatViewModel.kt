package com.leafmash.app.feature.messages

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leafmash.app.core.auth.AuthRepository
import com.leafmash.app.core.data.UserRepository
import com.leafmash.app.core.data.UserSummary
import com.leafmash.app.core.data.displayName
import com.leafmash.app.core.util.UiText
import com.leafmash.app.core.util.safeCall
import com.leafmash.app.core.util.toUiText
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.launch

@HiltViewModel
class NewChatViewModel @Inject constructor(
    private val userRepository: UserRepository,
    auth: AuthRepository
) : ViewModel() {

    private val myUid = auth.currentUid.orEmpty()

    var query by mutableStateOf("")
        private set

    var students by mutableStateOf<List<UserSummary>?>(null)
        private set

    var error by mutableStateOf<UiText?>(null)
        private set

    init {
        load()
    }

    fun load() {
        error = null
        viewModelScope.launch {
            safeCall { userRepository.loadStudents() }
                .onSuccess { list ->
                    students = list.filter { it.uid != myUid }.sortedBy { it.displayName.lowercase() }
                }
                .onFailure { error = it.toUiText() }
        }
    }

    fun onQueryChange(value: String) {
        query = value
    }

    fun filtered(): List<UserSummary> {
        val list = students.orEmpty()
        val needle = query.trim().lowercase()
        if (needle.isEmpty()) return list
        return list.filter { it.displayName.lowercase().contains(needle) }
    }
}
