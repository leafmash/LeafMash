package com.leafmash.app.feature.wall

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.leafmash.app.core.data.ProfileBadge
import com.leafmash.app.R
import com.leafmash.app.core.data.Comment
import com.leafmash.app.core.data.PendingComment
import com.leafmash.app.core.data.Reactions
import com.leafmash.app.core.data.UserSummary
import com.leafmash.app.core.data.badge
import com.leafmash.app.core.data.displayName
import com.leafmash.app.ui.components.ProfileBadgeIcon
import com.leafmash.app.ui.components.RichText
import com.leafmash.app.ui.components.UserAvatar
import com.leafmash.app.ui.navigation.LocalOpenProfile
import com.leafmash.app.ui.components.rememberTimeAgo

private val BubbleShape = RoundedCornerShape(topStart = 6.dp, topEnd = 20.dp, bottomEnd = 20.dp, bottomStart = 20.dp)

data class CommentCallbacks(
    val onReact: (String) -> Unit,
    val onReply: () -> Unit,
    val onEdit: () -> Unit,
    val onDelete: () -> Unit,
    val onViewReactions: () -> Unit,
    val onHashtag: (String) -> Unit
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun CommentItem(
    comment: Comment,
    author: UserSummary,
    isReply: Boolean,
    myUid: String,
    canDelete: Boolean,
    parentAuthorUid: String?,
    callbacks: CommentCallbacks,
    modifier: Modifier = Modifier
) {
    var menuOpen by remember { mutableStateOf(false) }
    val openProfile = LocalOpenProfile.current
    val clipboard = LocalClipboardManager.current
    val haptics = LocalHapticFeedback.current
    val avatarSize = if (isReply) 28.dp else 36.dp
    val myReaction = comment.reactions[myUid]
    val replyTag = comment.replyTo
    val showReplyTag = isReply && replyTag != null && replyTag.authorUid.isNotEmpty() && replyTag.authorUid != parentAuthorUid
    val timeAgo = rememberTimeAgo(comment.createdAtMs)
    val edited = stringResource(R.string.post_edited)
    val subtitle = if (comment.edited) "$timeAgo · $edited" else timeAgo

    val own = comment.authorUid == myUid
    val hairline = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    val hasReactions = comment.reactions.isNotEmpty()

    Row(modifier.fillMaxWidth().padding(top = 12.dp)) {
        UserAvatar(
            name = author.displayName,
            seed = author.uid,
            photoUrl = author.photoUrl,
            size = avatarSize,
            modifier = Modifier.clickable { openProfile(author.uid) },
            badge = author.badge
        )
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Box(Modifier.padding(bottom = if (hasReactions) 10.dp else 0.dp)) {
                Surface(
                    shape = BubbleShape,
                    color = if (own) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                    else MaterialTheme.colorScheme.surfaceContainerLowest,
                    border = hairline,
                    modifier = Modifier
                        .clip(BubbleShape)
                        .combinedClickable(
                            onClick = {},
                            onLongClick = {
                                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                menuOpen = true
                            }
                        )
                ) {
                    Column(Modifier.padding(start = 14.dp, end = 14.dp, top = 9.dp, bottom = if (hasReactions) 14.dp else 10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = author.displayName,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = androidx.compose.ui.text.font.FontWeight.ExtraBold,
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            ProfileBadgeIcon(author.badge, Modifier.padding(start = 4.dp), 14.dp)
                            Text(
                                text = " · $subtitle",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                        if (showReplyTag && replyTag != null) {
                            Text(
                                text = stringResource(R.string.comment_replying_to, replyTag.authorName),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        RichText(
                            text = comment.text,
                            mentions = comment.mentions,
                            style = MaterialTheme.typography.bodyMedium,
                            onHashtagClick = callbacks.onHashtag
                        )
                    }
                }
                if (hasReactions) {
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(end = 10.dp)
                            .offset(y = 10.dp)
                            .clip(RoundedCornerShape(50))
                            .background(MaterialTheme.colorScheme.surfaceContainerLowest)
                            .border(hairline, RoundedCornerShape(50))
                            .clickable(onClick = callbacks.onViewReactions)
                            .padding(horizontal = 8.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Reactions.top(comment.reactions, 1).forEach { ReactionGlyph(it, size = 14.dp) }
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = comment.reactions.size.toString(),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.comment_copy)) },
                        leadingIcon = { Icon(Icons.Outlined.ContentCopy, null) },
                        onClick = {
                            menuOpen = false
                            clipboard.setText(AnnotatedString(comment.text))
                        }
                    )
                    if (own) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.comment_edit)) },
                            leadingIcon = { Icon(Icons.Outlined.Edit, null) },
                            onClick = {
                                menuOpen = false
                                callbacks.onEdit()
                            }
                        )
                    }
                    if (canDelete) {
                        DropdownMenuItem(
                            text = { Text(stringResource(if (own) R.string.comment_delete else R.string.comment_remove)) },
                            leadingIcon = { Icon(Icons.Outlined.Delete, null, tint = MaterialTheme.colorScheme.error) },
                            onClick = {
                                menuOpen = false
                                callbacks.onDelete()
                            }
                        )
                    }
                }
            }
            Row(
                modifier = Modifier.padding(start = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                ReactionButton(myReaction = myReaction, onReact = callbacks.onReact, compact = true)
                Text(
                    text = stringResource(R.string.comment_reply),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .clickable(onClick = callbacks.onReply)
                        .heightIn(min = 32.dp)
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
fun PendingCommentItem(item: PendingComment, me: UserSummary?, modifier: Modifier = Modifier) {
    val isReply = item.replyTo != null
    Row(modifier.fillMaxWidth().padding(top = 10.dp)) {
        UserAvatar(
            name = me?.displayName.orEmpty(),
            seed = me?.uid.orEmpty(),
            photoUrl = me?.photoUrl.orEmpty(),
            size = if (isReply) 28.dp else 36.dp,
            badge = me?.badge ?: ProfileBadge.NONE
        )
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Surface(
                shape = BubbleShape,
                color = MaterialTheme.colorScheme.surfaceContainerLowest.copy(alpha = 0.7f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Text(text = me?.displayName.orEmpty(), style = MaterialTheme.typography.labelLarge)
                    Text(text = item.text, style = MaterialTheme.typography.bodyMedium)
                }
            }
            LinearProgressIndicator(Modifier.padding(start = 4.dp, top = 6.dp).width(64.dp))
        }
    }
}
