package com.leafmash.app.feature.notifications

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PriorityHigh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leafmash.app.R
import com.leafmash.app.core.data.badge
import com.leafmash.app.core.data.displayName
import com.leafmash.app.feature.notifications.data.ActivityItem
import com.leafmash.app.ui.components.CollectSnackbars
import com.leafmash.app.ui.components.ProfileBadgeIcon
import com.leafmash.app.ui.components.UserAvatar
import com.leafmash.app.ui.components.rememberTimeAgo

private const val QUOTE_LIMIT = 90
private const val TITLE_LIMIT = 70

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsScreen(
    initialTab: Int,
    onBack: () -> Unit,
    onOpenPost: (String, Boolean) -> Unit,
    onOpenResources: () -> Unit,
    viewModel: NotificationsViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var tab by rememberSaveable { mutableIntStateOf(initialTab) }
    var noticeDetailId by rememberSaveable { mutableStateOf<String?>(null) }

    CollectSnackbars(viewModel.events, snackbar)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.notif_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                },
                actions = {
                    if (tab == 1 && state.unreadActivity > 0) {
                        IconButton(onClick = viewModel::markAllRead) {
                            Icon(Icons.Filled.DoneAll, contentDescription = stringResource(R.string.notif_mark_all))
                        }
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { inner ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(inner)
        ) {
            TabRow(selectedTabIndex = tab) {
                Tab(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    text = { TabLabel(stringResource(R.string.notif_tab_notices), state.unreadNotices) }
                )
                Tab(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    text = { TabLabel(stringResource(R.string.notif_tab_activity), state.unreadActivity) }
                )
            }
            if (tab == 0) {
                NoticesList(
                    state = state,
                    onOpen = { id ->
                        viewModel.markNoticeRead(id)
                        noticeDetailId = id
                    }
                )
            } else {
                ActivityList(
                    state = state,
                    onOpen = { item ->
                        viewModel.markActivityRead(item.id)
                        when (item.type) {
                            "post", "like", "comment", "reply", "comment-like", "mention" ->
                                item.postId?.let { onOpenPost(it, item.type == "comment") }
                            "resource" -> onOpenResources()
                            "notice" -> {
                                tab = 0
                                item.noticeId?.let { id ->
                                    viewModel.markNoticeRead(id)
                                    noticeDetailId = id
                                }
                            }
                        }
                    },
                    onDismiss = viewModel::dismissActivity
                )
            }
        }
    }

    val detail = noticeDetailId?.let { id -> state.notices.firstOrNull { it.notice.id == id } }
    if (detail != null) {
        AlertDialog(
            onDismissRequest = { noticeDetailId = null },
            title = {
                Column {
                    Text(detail.poster.displayName, style = MaterialTheme.typography.titleMedium)
                    Text(
                        text = rememberTimeAgo(detail.notice.createdAtMs),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            text = {
                Column {
                    if (detail.notice.urgent) {
                        Text(
                            text = stringResource(R.string.notif_urgent),
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.error
                        )
                        Spacer(Modifier.size(6.dp))
                    }
                    Text(detail.notice.text, style = MaterialTheme.typography.bodyLarge)
                }
            },
            confirmButton = {
                TextButton(onClick = { noticeDetailId = null }) { Text(stringResource(R.string.action_close)) }
            }
        )
    }
}

@Composable
private fun TabLabel(label: String, unread: Int) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label)
        if (unread > 0) {
            Spacer(Modifier.width(6.dp))
            Badge { Text(if (unread > 9) "9+" else unread.toString()) }
        }
    }
}

@Composable
private fun NoticesList(state: NotificationsUiState, onOpen: (String) -> Unit) {
    when {
        !state.noticesLoaded -> CenterLoading()
        state.notices.isEmpty() -> CenterMessage(stringResource(R.string.notif_notices_empty))
        else -> LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(state.notices, key = { it.notice.id }) { row ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpen(row.notice.id) }
                        .background(if (row.unread) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f) else MaterialTheme.colorScheme.surface)
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        UserAvatar(
                            name = row.poster.displayName,
                            seed = row.poster.uid,
                            photoUrl = row.poster.photoUrl,
                            size = 36.dp
                        )
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = row.poster.displayName.ifBlank { stringResource(R.string.notif_admin_fallback) },
                                    style = MaterialTheme.typography.titleSmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                                ProfileBadgeIcon(
                                    badge = row.poster.badge,
                                    modifier = Modifier.padding(start = 4.dp),
                                    size = 16.dp
                                )
                            }
                            Text(
                                text = rememberTimeAgo(row.notice.createdAtMs),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (row.notice.urgent) {
                            Icon(
                                imageVector = Icons.Filled.PriorityHigh,
                                contentDescription = stringResource(R.string.notif_urgent),
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                    Spacer(Modifier.size(8.dp))
                    Text(
                        text = row.notice.text,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = if (row.unread) FontWeight.SemiBold else FontWeight.Normal,
                        maxLines = 4,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                HorizontalDivider()
            }
        }
    }
}

@Composable
private fun ActivityList(
    state: NotificationsUiState,
    onOpen: (ActivityItem) -> Unit,
    onDismiss: (String) -> Unit
) {
    val context = LocalContext.current
    when {
        !state.activityLoaded -> CenterLoading()
        state.activity.isEmpty() -> CenterMessage(stringResource(R.string.notif_activity_empty))
        else -> LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(state.activity, key = { it.item.id }) { row ->
                var menuOpen by remember { mutableStateOf(false) }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpen(row.item) }
                        .background(if (row.unread) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f) else MaterialTheme.colorScheme.surface)
                        .padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 4.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    UserAvatar(
                        name = row.actor.displayName,
                        seed = row.actor.uid,
                        photoUrl = row.actor.photoUrl,
                        size = 40.dp
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = row.item.actorName.ifBlank { row.actor.displayName },
                                style = MaterialTheme.typography.titleSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            ProfileBadgeIcon(
                                badge = row.actor.badge,
                                modifier = Modifier.padding(start = 4.dp),
                                size = 16.dp
                            )
                            if (row.unread) {
                                Spacer(Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primary)
                                )
                            }
                        }
                        Text(
                            text = activityLine(context, row.item),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = if (row.unread) FontWeight.SemiBold else FontWeight.Normal
                        )
                        Text(
                            text = rememberTimeAgo(row.item.createdAtMs),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Filled.MoreVert, contentDescription = stringResource(R.string.post_more))
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.notif_delete)) },
                                onClick = {
                                    menuOpen = false
                                    onDismiss(row.item.id)
                                }
                            )
                        }
                    }
                }
                HorizontalDivider()
            }
        }
    }
}

private fun String.ellipsize(max: Int): String = if (length > max) take(max) + "…" else this

private fun activityLine(context: Context, item: ActivityItem): String {
    val quote = if (item.text.isBlank()) "" else " " + context.getString(R.string.notif_quote, item.text.ellipsize(QUOTE_LIMIT))
    val title = if (item.text.isBlank()) "" else context.getString(R.string.notif_title_suffix, item.text.ellipsize(TITLE_LIMIT))
    return when (item.type) {
        "post" -> context.getString(R.string.notif_activity_post) + quote
        "resource" -> context.getString(R.string.notif_activity_resource) + title
        "comment" -> context.getString(R.string.notif_activity_comment) + quote
        "reply" -> context.getString(R.string.notif_activity_reply) + quote
        "like" -> context.getString(R.string.notif_activity_like)
        "comment-like" -> context.getString(R.string.notif_activity_comment_like) + quote
        "mention" -> context.getString(R.string.notif_activity_mention) + quote
        "notice" -> context.getString(R.string.notif_activity_notice) + quote
        "routine" -> context.getString(R.string.notif_activity_routine) + quote
        "deadline" -> context.getString(R.string.notif_activity_deadline) + title
        else -> item.text.ifBlank { context.getString(R.string.notif_activity_default) }
    }
}

@Composable
private fun CenterLoading() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
    }
}

@Composable
private fun CenterMessage(text: String) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            text = text,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(32.dp)
        )
    }
}
