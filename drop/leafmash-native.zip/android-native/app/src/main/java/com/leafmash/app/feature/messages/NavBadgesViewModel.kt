package com.leafmash.app.feature.messages

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leafmash.app.core.auth.AuthRepository
import com.leafmash.app.feature.messages.data.MessagesRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

@HiltViewModel
class NavBadgesViewModel @Inject constructor(
    repository: MessagesRepository,
    auth: AuthRepository
) : ViewModel() {
    val myUid: String = auth.currentUid.orEmpty()

    val messagesBadge: StateFlow<Int> = repository.unreadTotal()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)
}
