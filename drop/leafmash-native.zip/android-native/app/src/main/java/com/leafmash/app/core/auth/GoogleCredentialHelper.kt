package com.leafmash.app.core.auth

import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import kotlin.coroutines.cancellation.CancellationException

object GoogleCredentialHelper {

    suspend fun fetchIdToken(context: Context): Result<String> {
        val clientId = webClientId(context)
        if (clientId.isEmpty()) {
            return Result.failure(GoogleSignInException(GoogleSignInException.Reason.NOT_CONFIGURED))
        }
        val option = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(clientId)
            .setAutoSelectEnabled(false)
            .build()
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        return try {
            val response = CredentialManager.create(context).getCredential(context, request)
            val credential = response.credential
            if (credential is CustomCredential &&
                credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
            ) {
                Result.success(GoogleIdTokenCredential.createFrom(credential.data).idToken)
            } else {
                Result.failure(GoogleSignInException(GoogleSignInException.Reason.FAILED))
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: GetCredentialCancellationException) {
            Result.failure(GoogleSignInException(GoogleSignInException.Reason.CANCELLED))
        } catch (e: NoCredentialException) {
            Result.failure(GoogleSignInException(GoogleSignInException.Reason.NO_ACCOUNT))
        } catch (e: GetCredentialException) {
            Result.failure(GoogleSignInException(GoogleSignInException.Reason.FAILED))
        } catch (e: GoogleIdTokenParsingException) {
            Result.failure(GoogleSignInException(GoogleSignInException.Reason.FAILED))
        }
    }

    @Suppress("DiscouragedApi")
    private fun webClientId(context: Context): String {
        val id = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
        return if (id == 0) "" else context.getString(id)
    }
}
