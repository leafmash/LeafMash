package com.leafmash.app.feature.messages

import android.content.Context
import androidx.lifecycle.ViewModel
import com.leafmash.app.R
import com.leafmash.app.core.util.UiText
import com.leafmash.app.feature.messages.data.ChatTarget
import com.leafmash.app.feature.messages.data.MessageSender
import com.leafmash.app.feature.messages.voice.VoicePlayer
import com.leafmash.app.feature.messages.voice.VoiceRecorderController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.channels.Channel

fun newRecorderController(
    context: Context,
    scope: CoroutineScope,
    sender: MessageSender,
    target: ChatTarget,
    events: Channel<UiText>
): VoiceRecorderController = VoiceRecorderController(
    context = context,
    scope = scope,
    onRecorded = { recording -> sender.sendVoice(target, recording.file, recording.durationSec) },
    onFailed = { events.trySend(UiText.Res(R.string.chat_record_failed)) }
)

abstract class ChatViewModelBase(protected val player: VoicePlayer) : ViewModel() {
    val playback = player.state

    fun togglePlay(id: String, uri: android.net.Uri, durationSec: Int) {
        player.toggle(id, uri, durationSec * 1000L)
    }

    fun seekVoice(id: String, positionMs: Long) = player.seekTo(id, positionMs)

    fun cycleSpeed() = player.cycleSpeed()

    override fun onCleared() {
        player.stop()
        super.onCleared()
    }
}
