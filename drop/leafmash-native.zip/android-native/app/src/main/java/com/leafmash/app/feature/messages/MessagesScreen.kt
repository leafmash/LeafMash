package com.leafmash.app.feature.messages

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.leafmash.app.R
import com.leafmash.app.ui.components.PlaceholderScreen

@Composable
fun MessagesScreen() {
    PlaceholderScreen(
        title = stringResource(R.string.nav_messages),
        icon = Icons.Filled.ChatBubble,
        phase = 3
    )
}
