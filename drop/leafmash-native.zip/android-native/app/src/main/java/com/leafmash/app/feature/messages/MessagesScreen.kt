package com.leafmash.app.feature.messages

import com.leafmash.app.ui.components.FlatItem
import com.leafmash.app.ui.theme.LeafPalette
import com.leafmash.app.ui.components.LeafCard
import com.leafmash.app.ui.components.EmptyCard
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.PaddingValues
import com.leafmash.app.ui.components.LeafTopAppBar
import com.leafmash.app.ui.components.RingAvatar
import androidx.compose.material3.HorizontalDivider
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material3.Badge
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leafmash.app.R
import com.leafmash.app.core.data.badge
import com.leafmash.app.core.data.displayName
import com.leafmash.app.ui.components.CollectSnackbars
import com.leafmash.app.ui.components.ProfileBadgeIcon
import com.leafmash.app.ui.components.UserAvatar
import com.leafmash.app.ui.components.rememberTimeAgo

private val OnlineGreen = Color(0xFF2E9E5B)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MessagesScreen(
    onOpenClassChat: () -> Unit,
    onOpenThread: (String) -> Unit,
    onNewChat: () -> Unit,
    viewModel: MessagesViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var deleteMenuFor by remember { mutableStateOf<String?>(null) }

    CollectSnackbars(viewModel.events, snackbar)

    Scaffold(
        topBar = {
            LeafTopAppBar(
                title = { Text(stringResource(R.string.nav_messages)) },
                actions = {
                    IconButton(onClick = onNewChat) {
                        Icon(Icons.Filled.Edit, contentDescription = stringResource(R.string.chat_new))
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { inner ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(inner)
        ) {
            LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(0.dp)) {
                item(key = "class-chat") {
                    ClassChatCard(unread = state.classUnread, onClick = onOpenClassChat)
                }
                if (state.loading) {
                    item(key = "loading") {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) { CircularProgressIndicator() }
                    }
                } else if (state.rows.isEmpty()) {
                    item(key = "empty") {
                        EmptyCard(
                            title = stringResource(R.string.chat_empty),
                            icon = Icons.Outlined.ChatBubbleOutline,
                            modifier = Modifier
                        )
                    }
                } else {
                    items(state.rows, key = { it.id }) { row ->
                        Box {
                            ConversationItem(
                                row = row,
                                onClick = { onOpenThread(row.otherUid) },
                                onLongClick = { deleteMenuFor = row.id }
                            )
                            DropdownMenu(
                                expanded = deleteMenuFor == row.id,
                                onDismissRequest = { deleteMenuFor = null }
                            ) {
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.chat_delete_conversation)) },
                                    onClick = {
                                        deleteMenuFor = null
                                        viewModel.deleteConversation(row.id)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ClassChatCard(unread: Int, onClick: () -> Unit) {
    FlatItem(onClick = onClick) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Groups,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(28.dp)
                )
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.chat_class_title),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = stringResource(R.string.chat_class_subtitle),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (unread > 0) {
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary)
                        .padding(horizontal = 9.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (unread > 99) "99+" else unread.toString(),
                        color = MaterialTheme.colorScheme.onPrimary,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ConversationItem(row: ConversationRow, onClick: () -> Unit, onLongClick: () -> Unit) {
    val context = LocalContext.current
    val scheme = MaterialTheme.colorScheme
    val online = isOnline(row.lastActiveMs)
    val time = if (row.timeMs > 0L) rememberTimeAgo(row.timeMs) else ""
    Column(Modifier.fillMaxWidth().background(scheme.surfaceContainerLowest)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .combinedClickable(onClick = onClick, onLongClick = onLongClick)
                .padding(start = 12.dp, end = 16.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RingAvatar(
                name = row.user.displayName,
                seed = row.user.uid,
                photoUrl = row.user.photoUrl,
                size = 48.dp,
                ring = row.unread,
                onlineDot = online,
                badge = row.user.badge
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = row.user.displayName,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontWeight = if (row.unread) FontWeight.ExtraBold else FontWeight.SemiBold,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    ProfileBadgeIcon(badge = row.user.badge, modifier = Modifier.padding(start = 4.dp), size = 16.dp)
                }
                val prefix = if (row.previewIsMine) context.getString(R.string.chat_you_prefix) else ""
                Text(
                    text = prefix + row.preview,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (row.unread) scheme.onSurface else scheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontWeight = if (row.unread) FontWeight.SemiBold else FontWeight.Normal
                )
            }
            Spacer(Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = time,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (row.unread) scheme.primary else scheme.onSurfaceVariant
                )
                if (row.unread) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(scheme.primary)
                    )
                }
            }
        }
        HorizontalDivider(
            modifier = Modifier.padding(start = 72.dp),
            color = scheme.outlineVariant.copy(alpha = 0.7f)
        )
    }
}
