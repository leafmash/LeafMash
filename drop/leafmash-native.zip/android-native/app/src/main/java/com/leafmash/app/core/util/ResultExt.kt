package com.leafmash.app.core.util

import com.google.firebase.firestore.FirebaseFirestoreException
import com.leafmash.app.R
import com.leafmash.app.core.network.ApiException
import kotlin.coroutines.cancellation.CancellationException

suspend inline fun <T> safeCall(block: suspend () -> T): Result<T> = try {
    Result.success(block())
} catch (e: CancellationException) {
    throw e
} catch (e: Exception) {
    Result.failure(e)
}

fun Throwable.toUiText(): UiText = when (this) {
    is ApiException -> UiText.Plain(message)
    is FirebaseFirestoreException ->
        if (code == FirebaseFirestoreException.Code.UNAVAILABLE) UiText.Res(R.string.err_network) else UiText.Res(R.string.err_generic)
    else -> UiText.Res(R.string.err_generic)
}
