-keepattributes *Annotation*, InnerClasses, Signature, Exceptions
-dontnote kotlinx.serialization.**
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.leafmash.app.**$$serializer { *; }
-keepclassmembers class com.leafmash.app.** {
    *** Companion;
}
-keepclasseswithmembers class com.leafmash.app.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-dontwarn org.codehaus.mojo.animal_sniffer.IgnoreJRERequirement
