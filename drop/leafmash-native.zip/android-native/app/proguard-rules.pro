-keepattributes *Annotation*, InnerClasses, Signature, Exceptions
-dontnote kotlinx.serialization.**
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.leafmash.app.**$$serializer { *; }
-keepclassmembers class com.leafmash.app.** {
    *** Companion;
}
-keepclasseswithmembers class com.leafmash.app.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-dontwarn org.codehaus.mojo.animal_sniffer.IgnoreJRERequirement
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
-keep interface com.leafmash.app.core.network.LeafMashApi { *; }
-keepclassmembers enum com.leafmash.app.** {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}
-keep class * extends androidx.work.ListenableWorker {
    <init>(android.content.Context, androidx.work.WorkerParameters);
}
-keep class com.leafmash.app.core.push.LeafMashMessagingService { *; }
-keep class com.leafmash.app.core.push.NotificationActionReceiver { *; }
-dontwarn javax.annotation.**
-dontwarn org.checkerframework.**
-dontwarn com.google.errorprone.annotations.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
-dontwarn kotlinx.serialization.**
-dontwarn okhttp3.internal.platform.**
