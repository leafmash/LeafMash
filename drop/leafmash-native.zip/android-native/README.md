# LeafMash Native (Android)

Native Kotlin + Jetpack Compose rewrite of LeafMash. The backend (Firebase Auth, Firestore, FCM, Vercel `/api/*`, Cloudinary) is shared with the web app.

## Setup

1. Place `google-services.json` in `app/` (git-ignored; CI writes it from the `GOOGLE_SERVICES_JSON_BASE64` secret).
2. Open `android-native/` in Android Studio (JDK 17) and run the `app` configuration.
3. For a signed release build, put `release.keystore` in `app/` and export `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`. Use the same keystore as the Capacitor build so the native app can update it in place.

## Phases

| Phase | Scope | Status |
|---|---|---|
| 0 | Foundation: theme, navigation shell, Firebase, API client, settings, CI | done |
| 1 | Auth and profile | done |
| 2 | Wall | |
| 3 | Messaging | Done (not build-verified) |
| 4 | Notifications | Done (not build-verified) |
| 5 | Routine, deadlines, resources, notices | Done (not build-verified) |
| 6 | Directory, search, reports, admin | |
| 7 | Polish and release | |

## Structure

- `core/` network (Retrofit + Firebase ID token), DI (Hilt), settings (DataStore)
- `ui/` theme, navigation, shared components
- `feature/` one package per screen area
